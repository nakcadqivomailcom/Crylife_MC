import express from 'express';
import { DatabaseSync } from 'node:sqlite';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import QRCode from 'qrcode';

const PORT = 3000;
const DATA_DIR = path.resolve(process.env.DATA_DIR || './data');
const DB_FILE = path.join(DATA_DIR, 'ravan.db');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initialize SQLite database
const db = new DatabaseSync(DB_FILE);

// Initialize tables with distinct panel_users, config_users, api_keys, api_logs
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;

  -- 1. Administrative staff accounts (Access to Dashboard)
  CREATE TABLE IF NOT EXISTS panel_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid TEXT UNIQUE NOT NULL,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE DEFAULT '',
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'Admin', -- Owner, Admin, Operator, Support, ReadOnly
    status TEXT NOT NULL DEFAULT 'Active', -- Active, Disabled
    permissions TEXT DEFAULT '[]',
    two_factor_enabled INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    last_login_at TEXT
  );

  -- 2. Client accounts (Proxy service consumers ONLY, NO access to Dashboard)
  CREATE TABLE IF NOT EXISTS config_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid TEXT UNIQUE NOT NULL,
    username TEXT UNIQUE NOT NULL,
    status TEXT NOT NULL DEFAULT 'Active', -- Active, Disabled, Expired, QuotaExceeded
    traffic_quota_bytes INTEGER NOT NULL DEFAULT 0,
    traffic_used_bytes INTEGER NOT NULL DEFAULT 0,
    upload_bytes INTEGER NOT NULL DEFAULT 0,
    download_bytes INTEGER NOT NULL DEFAULT 0,
    device_limit INTEGER NOT NULL DEFAULT 2,
    user_group TEXT DEFAULT 'Default',
    notes TEXT DEFAULT '',
    tags TEXT DEFAULT '[]',
    expires_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  -- 3. API Keys bound to Panel Users
  CREATE TABLE IF NOT EXISTS api_keys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    panel_user_id INTEGER NOT NULL REFERENCES panel_users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    key_prefix TEXT NOT NULL, -- e.g. rpn_7a2b
    key_hash TEXT NOT NULL,   -- SHA-256 hash of full secret
    permissions TEXT NOT NULL DEFAULT '[]',
    last_used_at TEXT,
    created_at TEXT NOT NULL,
    revoked_at TEXT
  );

  -- 4. API Request Execution Logs
  CREATE TABLE IF NOT EXISTS api_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    panel_user_id INTEGER,
    key_prefix TEXT DEFAULT '',
    method TEXT NOT NULL,
    endpoint TEXT NOT NULL,
    status_code INTEGER NOT NULL,
    ip_address TEXT NOT NULL,
    duration_ms INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
  );

  -- 5. Config User Subscriptions
  CREATE TABLE IF NOT EXISTS subscriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    config_user_id INTEGER NOT NULL REFERENCES config_users(id) ON DELETE CASCADE,
    token TEXT UNIQUE NOT NULL,
    status TEXT NOT NULL DEFAULT 'Active',
    created_at TEXT NOT NULL,
    revoked_at TEXT
  );

  -- 6. Config User Client Configurations
  CREATE TABLE IF NOT EXISTS config_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    config_user_id INTEGER NOT NULL REFERENCES config_users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    protocol TEXT NOT NULL DEFAULT 'vless',
    port INTEGER NOT NULL DEFAULT 443,
    settings TEXT DEFAULT '{}',
    created_at TEXT NOT NULL
  );

  -- 7. Daily Traffic Aggregations
  CREATE TABLE IF NOT EXISTS daily_traffic (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    config_user_id INTEGER NOT NULL REFERENCES config_users(id) ON DELETE CASCADE,
    date_str TEXT NOT NULL,
    upload_bytes INTEGER NOT NULL DEFAULT 0,
    download_bytes INTEGER NOT NULL DEFAULT 0,
    total_bytes INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL,
    UNIQUE (config_user_id, date_str)
  );

  -- 8. Nodes
  CREATE TABLE IF NOT EXISTS nodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    port INTEGER NOT NULL DEFAULT 443,
    status TEXT NOT NULL DEFAULT 'Online',
    version TEXT DEFAULT 'v0.1.0',
    cpu_usage REAL DEFAULT 0.0,
    ram_usage REAL DEFAULT 0.0,
    disk_usage REAL DEFAULT 0.0,
    uptime_seconds INTEGER DEFAULT 0,
    last_seen_at TEXT NOT NULL,
    is_local INTEGER NOT NULL DEFAULT 0
  );

  -- 9. Security Audit Logs
  CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    target TEXT NOT NULL,
    ip_address TEXT NOT NULL,
    metadata TEXT DEFAULT '{}',
    created_at TEXT NOT NULL
  );

  -- 10. Blocklists
  CREATE TABLE IF NOT EXISTS blocklists (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL,
    value TEXT UNIQUE NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    comment TEXT DEFAULT '',
    created_at TEXT NOT NULL
  );

  -- 11. System Settings
  CREATE TABLE IF NOT EXISTS system_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
`);

// Password hashing
function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 10000, 32, 'sha256').toString('hex');
  return `${salt}$${hash}`;
}

function verifyPassword(password: string, stored: string): boolean {
  const [salt, expectedHash] = stored.split('$');
  if (!salt || !expectedHash) return false;
  const computedHash = crypto.pbkdf2Sync(password, salt, 10000, 32, 'sha256').toString('hex');
  return crypto.timingSafeEqual(Buffer.from(computedHash), Buffer.from(expectedHash));
}

// In-Memory Sessions & Brute-Force Tracker
interface SessionData {
  panelUserId: number;
  username: string;
  role: string;
  permissions: string[];
  expiresAt: number;
}
const activeSessions = new Map<string, SessionData>();
const failedLoginAttempts = new Map<string, { count: number; lockedUntil: number }>();

function recordAudit(actor: string, action: string, target: string, ip: string, metadata: Record<string, any> = {}) {
  const clean: Record<string, any> = {};
  for (const [k, v] of Object.entries(metadata)) {
    if (/password|token|secret|key/i.test(k)) {
      clean[k] = '[REDACTED]';
    } else {
      clean[k] = v;
    }
  }
  const stmt = db.prepare(`
    INSERT INTO audit_logs (actor, action, target, ip_address, metadata, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  stmt.run(actor, action, target, ip, JSON.stringify(clean), new Date().toISOString());
}

// Seed initial settings & sample data if empty
const panelCountStmt = db.prepare('SELECT COUNT(*) as count FROM panel_users');
const { count: initialPanelCount } = panelCountStmt.get() as { count: number };

if (initialPanelCount === 0) {
  const now = new Date().toISOString();
  const ownerHash = hashPassword('Admin@2026');

  // Seed Owner
  db.prepare(`
    INSERT INTO panel_users (uuid, username, email, password_hash, role, status, permissions, two_factor_enabled, created_at, updated_at)
    VALUES (?, 'owner', 'owner@ravanpanel.local', ?, 'Owner', 'Active', '["*"]', 0, ?, ?)
  `).run(crypto.randomUUID(), ownerHash, now, now);

  // Seed sample Config Users (Clients)
  const configUserStmt = db.prepare(`
    INSERT INTO config_users (uuid, username, status, traffic_quota_bytes, traffic_used_bytes, upload_bytes, download_bytes, device_limit, user_group, notes, tags, expires_at, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const expiry30d = new Date(Date.now() + 30 * 86400000).toISOString();

  const c1 = configUserStmt.run(
    crypto.randomUUID(), 'matin', 'Active',
    50 * 1024 * 1024 * 1024, 13200000000, 3100000000, 10100000000, 3, 'VIP', 'Direct Customer', '["fast","vip"]',
    expiry30d, now, now
  );

  const c2 = configUserStmt.run(
    crypto.randomUUID(), 'sara_mobile', 'Active',
    100 * 1024 * 1024 * 1024, 8500000000, 1800000000, 6700000000, 2, 'Default', 'Family mobile plan', '["standard"]',
    expiry30d, now, now
  );

  const c3 = configUserStmt.run(
    crypto.randomUUID(), 'sina_expired', 'Expired',
    20 * 1024 * 1024 * 1024, 20480000000, 5000000000, 15480000000, 1, 'Standard', 'Expired 3 days ago', '["expired"]',
    new Date(Date.now() - 3 * 86400000).toISOString(), now, now
  );

  // Seed Subscriptions for Config Users
  const subStmt = db.prepare(`
    INSERT INTO subscriptions (config_user_id, token, status, created_at)
    VALUES (?, ?, 'Active', ?)
  `);
  subStmt.run(c1.lastInsertRowid, crypto.randomBytes(24).toString('hex'), now);
  subStmt.run(c2.lastInsertRowid, crypto.randomBytes(24).toString('hex'), now);

  // Seed Config Items
  const configItemStmt = db.prepare(`
    INSERT INTO config_items (config_user_id, name, protocol, port, settings, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  configItemStmt.run(c1.lastInsertRowid, 'Tehran VLESS Reality', 'vless', 443, JSON.stringify({ flow: 'xtls-rprx-vision' }), now);
  configItemStmt.run(c1.lastInsertRowid, 'Frankfurt VMess WS', 'vmess', 8443, JSON.stringify({ path: '/ravan' }), now);
  configItemStmt.run(c2.lastInsertRowid, 'Direct Trojan TLS', 'trojan', 443, JSON.stringify({}), now);

  // Seed Nodes
  const nodeStmt = db.prepare(`
    INSERT INTO nodes (name, address, port, status, version, cpu_usage, ram_usage, disk_usage, uptime_seconds, last_seen_at, is_local)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  nodeStmt.run('Tehran-Master-01', '127.0.0.1', 443, 'Online', 'v0.1.0', 2.1, 24.5, 12.0, 482000, now, 1);
  nodeStmt.run('Frankfurt-Edge-02', '198.51.100.32', 443, 'Online', 'v0.1.0', 1.6, 18.2, 9.4, 894000, now, 0);

  // Seed Blocklist
  const blockStmt = db.prepare(`
    INSERT INTO blocklists (type, value, enabled, comment, created_at)
    VALUES (?, ?, 1, ?, ?)
  `);
  blockStmt.run('Domain', 'ads.tracking-service.com', 'Internal block rule', now);
  blockStmt.run('IP', '198.51.100.99', 'Abusive scanner IP', now);

  // Seed Default Settings
  const settingStmt = db.prepare(`
    INSERT OR REPLACE INTO system_settings (key, value, updated_at) VALUES (?, ?, ?)
  `);
  settingStmt.run('allow_registration', 'true', now);
  settingStmt.run('brand_accent', 'cyan', now);
  settingStmt.run('brand_theme', 'dark', now);

  // Seed Audit
  db.prepare(`
    INSERT INTO audit_logs (actor, action, target, ip_address, metadata, created_at)
    VALUES ('system', 'InitialSetup', 'RavanPanel Cluster', '127.0.0.1', '{"owner":"owner"}', ?)
  `).run(now);
}

const app = express();
app.use(express.json());

// API Key / Session Authentication & API Logger Middleware
app.use((req, res, next) => {
  const start = Date.now();
  const authHeader = req.headers.authorization;
  const apiKeyHeader = req.headers['x-api-key'] as string;
  const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : (apiKeyHeader || (req.query.token as string));

  let authenticatedUser: any = null;
  let keyPrefixUsed = '';

  if (token) {
    if (token.startsWith('rpn_')) {
      // API Key Auth
      keyPrefixUsed = token.slice(0, 10);
      const hash = crypto.createHash('sha256').update(token).digest('hex');
      const keyRecord = db.prepare(`
        SELECT k.*, p.username, p.role, p.status as panel_status
        FROM api_keys k
        JOIN panel_users p ON k.panel_user_id = p.id
        WHERE k.key_hash = ? AND k.revoked_at IS NULL
      `).get(hash) as any;

      if (keyRecord && keyRecord.panel_status === 'Active') {
        authenticatedUser = {
          panelUserId: keyRecord.panel_user_id,
          username: keyRecord.username,
          role: keyRecord.role,
          permissions: JSON.parse(keyRecord.permissions || '[]'),
          isApiKey: true,
          keyId: keyRecord.id,
        };
        // Update key last used
        db.prepare('UPDATE api_keys SET last_used_at = ? WHERE id = ?').run(new Date().toISOString(), keyRecord.id);
      }
    } else {
      // Standard Session Auth
      const sess = activeSessions.get(token);
      if (sess && Date.now() <= sess.expiresAt) {
        authenticatedUser = sess;
      }
    }
  }

  (req as any).user = authenticatedUser;
  (req as any).keyPrefix = keyPrefixUsed;

  // Intercept response finish for API Logging
  res.on('finish', () => {
    // Only log /api/ endpoints to prevent cluttering static/Vite logs
    if (req.originalUrl.startsWith('/api/')) {
      const duration = Date.now() - start;
      const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
      try {
        db.prepare(`
          INSERT INTO api_logs (panel_user_id, key_prefix, method, endpoint, status_code, ip_address, duration_ms, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
          authenticatedUser?.panelUserId || null,
          keyPrefixUsed ? `${keyPrefixUsed}****` : '',
          req.method,
          req.originalUrl.split('?')[0],
          res.statusCode,
          ip,
          duration,
          new Date().toISOString()
        );
      } catch (e) {
        // silent fail for logging
      }
    }
  });

  next();
});

function requireAuth(req: express.Request, res: express.Response, next: express.NextFunction) {
  if (!(req as any).user) {
    res.status(401).json({ error: { code: 'UNAUTHORIZED', message: 'Authentication required. Panel user credentials or valid API Key needed.' } });
    return;
  }
  next();
}

function requireRole(allowedRoles: string[]) {
  return (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const role = (req as any).user?.role;
    if (!allowedRoles.includes(role)) {
      res.status(403).json({ error: { code: 'FORBIDDEN', message: 'Insufficient role permissions' } });
      return;
    }
    next();
  };
}

// --- Setup Status & First Launch Wizard ---
app.get('/api/v1/system/setup-status', (req, res) => {
  const { count } = db.prepare('SELECT COUNT(*) as count FROM panel_users').get() as { count: number };
  const regRow = db.prepare("SELECT value FROM system_settings WHERE key = 'allow_registration'").get() as any;
  const allowRegistration = regRow ? regRow.value === 'true' : true;

  res.json({
    needs_setup: count === 0,
    allow_registration: allowRegistration,
    panel_user_count: count,
  });
});

app.post('/api/v1/system/setup-owner', (req, res) => {
  const { count } = db.prepare('SELECT COUNT(*) as count FROM panel_users').get() as { count: number };
  if (count > 0) {
    res.status(400).json({ error: { code: 'SETUP_ALREADY_COMPLETED', message: 'Setup wizard already executed.' } });
    return;
  }

  const { username, email, password } = req.body;
  if (!username || !password) {
    res.status(400).json({ error: { code: 'INVALID_INPUT', message: 'Username and password required.' } });
    return;
  }

  const now = new Date().toISOString();
  const ownerHash = hashPassword(password);
  const uuid = crypto.randomUUID();

  db.prepare(`
    INSERT INTO panel_users (uuid, username, email, password_hash, role, status, permissions, two_factor_enabled, created_at, updated_at)
    VALUES (?, ?, ?, ?, 'Owner', 'Active', '["*"]', 0, ?, ?)
  `).run(uuid, username, email || `${username}@ravanpanel.local`, ownerHash, now, now);

  recordAudit(username, 'OwnerCreated', username, req.ip || '127.0.0.1');
  res.json({ success: true, message: 'Owner account provisioned successfully.' });
});

// --- Authentication (Panel Users ONLY) ---
app.post('/api/v1/auth/login', (req, res) => {
  const { username, password } = req.body || {};
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';

  if (!username || !password) {
    res.status(400).json({ error: { code: 'INVALID_INPUT', message: 'Username and password required.' } });
    return;
  }

  // Brute force check
  const failData = failedLoginAttempts.get(username);
  if (failData && Date.now() < failData.lockedUntil) {
    const remainingMins = Math.ceil((failData.lockedUntil - Date.now()) / 60000);
    res.status(429).json({
      error: { code: 'ACCOUNT_LOCKED', message: `Too many failed attempts. Try again in ${remainingMins} minutes.` }
    });
    return;
  }

  // STRICT RULE: Search strictly in panel_users!
  // If someone exists in config_users, they cannot login to the admin dashboard.
  const panelUser = db.prepare('SELECT * FROM panel_users WHERE username = ?').get(username) as any;

  if (!panelUser || !verifyPassword(password, panelUser.password_hash)) {
    const current = failData || { count: 0, lockedUntil: 0 };
    current.count += 1;
    if (current.count >= 5) {
      current.lockedUntil = Date.now() + 15 * 60 * 1000;
    }
    failedLoginAttempts.set(username, current);
    recordAudit('anonymous', 'LoginFailed', username, ip);
    res.status(401).json({ error: { code: 'INVALID_CREDENTIALS', message: 'Invalid panel username or password.' } });
    return;
  }

  if (panelUser.status === 'Disabled') {
    res.status(403).json({ error: { code: 'ACCOUNT_DISABLED', message: 'This panel account has been disabled.' } });
    return;
  }

  failedLoginAttempts.delete(username);

  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = Date.now() + 72 * 3600 * 1000;
  const permissions = JSON.parse(panelUser.permissions || '["*"]');

  activeSessions.set(token, {
    panelUserId: panelUser.id,
    username: panelUser.username,
    role: panelUser.role,
    permissions,
    expiresAt,
  });

  const now = new Date().toISOString();
  db.prepare('UPDATE panel_users SET last_login_at = ? WHERE id = ?').run(now, panelUser.id);
  recordAudit(panelUser.username, 'LoginSuccess', panelUser.username, ip);

  res.json({
    token,
    user: {
      id: panelUser.id,
      uuid: panelUser.uuid,
      username: panelUser.username,
      email: panelUser.email,
      role: panelUser.role,
      status: panelUser.status,
      permissions,
    }
  });
});

app.post('/api/v1/auth/register', (req, res) => {
  const regRow = db.prepare("SELECT value FROM system_settings WHERE key = 'allow_registration'").get() as any;
  const allowRegistration = regRow ? regRow.value === 'true' : true;
  if (!allowRegistration) {
    res.status(403).json({ error: { code: 'REGISTRATION_DISABLED', message: 'Public panel registration is disabled by the administrator.' } });
    return;
  }

  const { username, email, password } = req.body;
  if (!username || !password) {
    res.status(400).json({ error: { code: 'INVALID_INPUT', message: 'Username and password required.' } });
    return;
  }

  try {
    const now = new Date().toISOString();
    const hash = hashPassword(password);
    const uuid = crypto.randomUUID();

    db.prepare(`
      INSERT INTO panel_users (uuid, username, email, password_hash, role, status, permissions, two_factor_enabled, created_at, updated_at)
      VALUES (?, ?, ?, ?, 'Admin', 'Active', '["dashboard.read","users.read"]', 0, ?, ?)
    `).run(uuid, username, email || `${username}@ravanpanel.local`, hash, now, now);

    recordAudit(username, 'PanelUserRegistered', username, req.ip || '127.0.0.1');
    res.status(201).json({ success: true, message: 'Account registered. Please proceed to login.' });
  } catch (err: any) {
    if (err.message?.includes('UNIQUE constraint failed')) {
      res.status(409).json({ error: { code: 'USER_EXISTS', message: 'Username or email already registered.' } });
      return;
    }
    res.status(500).json({ error: { code: 'DATABASE_ERROR', message: err.message } });
  }
});

app.post('/api/v1/auth/logout', requireAuth, (req, res) => {
  const token = req.headers.authorization?.slice(7);
  if (token) activeSessions.delete(token);
  res.json({ success: true });
});

app.get('/api/v1/auth/me', requireAuth, (req, res) => {
  const session = (req as any).user;
  const panelUser = db.prepare('SELECT id, uuid, username, email, role, status, permissions, two_factor_enabled FROM panel_users WHERE id = ?')
    .get(session.panelUserId) as any;
  if (!panelUser) {
    res.status(404).json({ error: { code: 'USER_NOT_FOUND', message: 'Panel user not found.' } });
    return;
  }
  panelUser.permissions = JSON.parse(panelUser.permissions || '[]');
  res.json({ user: panelUser });
});

// --- Panel Users Management ---
app.get('/api/v1/panel-users', requireAuth, (req, res) => {
  const users = db.prepare(`
    SELECT id, uuid, username, email, role, status, permissions, two_factor_enabled, created_at, last_login_at
    FROM panel_users
    ORDER BY id ASC
  `).all() as any[];

  res.json({
    panel_users: users.map(u => ({ ...u, permissions: JSON.parse(u.permissions || '[]') }))
  });
});

app.post('/api/v1/panel-users', requireAuth, requireRole(['Owner', 'Admin']), (req, res) => {
  const { username, email, password, role = 'Operator', permissions = [] } = req.body;
  if (!username || !password) {
    res.status(400).json({ error: { code: 'INVALID_INPUT', message: 'Username and password required.' } });
    return;
  }

  try {
    const now = new Date().toISOString();
    const hash = hashPassword(password);
    const uuid = crypto.randomUUID();

    const result = db.prepare(`
      INSERT INTO panel_users (uuid, username, email, password_hash, role, status, permissions, two_factor_enabled, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, 'Active', ?, 0, ?, ?)
    `).run(uuid, username, email || '', hash, role, JSON.stringify(permissions), now, now);

    recordAudit((req as any).user.username, 'PanelUserCreated', username, req.ip || '127.0.0.1', { role });
    res.status(201).json({ id: result.lastInsertRowid, username, role, status: 'Active' });
  } catch (err: any) {
    res.status(409).json({ error: { code: 'EXISTS', message: 'Username already taken.' } });
  }
});

app.put('/api/v1/panel-users/:id', requireAuth, requireRole(['Owner', 'Admin']), (req, res) => {
  const id = parseInt(req.params.id, 10);
  const target = db.prepare('SELECT * FROM panel_users WHERE id = ?').get(id) as any;
  if (!target) {
    res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Panel user not found.' } });
    return;
  }

  const { role, status, permissions, password } = req.body;
  const updates: string[] = ['updated_at = ?'];
  const params: any[] = [new Date().toISOString()];

  if (role) { updates.push('role = ?'); params.push(role); }
  if (status) { updates.push('status = ?'); params.push(status); }
  if (permissions) { updates.push('permissions = ?'); params.push(JSON.stringify(permissions)); }
  if (password) {
    updates.push('password_hash = ?');
    params.push(hashPassword(password));
    // Revoke target active sessions
    for (const [t, s] of activeSessions.entries()) {
      if (s.panelUserId === id) activeSessions.delete(t);
    }
  }

  params.push(id);
  db.prepare(`UPDATE panel_users SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  recordAudit((req as any).user.username, 'PanelUserUpdated', target.username, req.ip || '127.0.0.1');
  res.json({ success: true });
});

app.delete('/api/v1/panel-users/:id', requireAuth, requireRole(['Owner']), (req, res) => {
  const id = parseInt(req.params.id, 10);
  const target = db.prepare('SELECT username, role FROM panel_users WHERE id = ?').get(id) as any;
  if (!target) {
    res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Panel user not found.' } });
    return;
  }
  if (target.role === 'Owner') {
    res.status(400).json({ error: { code: 'CANNOT_DELETE_OWNER', message: 'Primary Owner account cannot be deleted.' } });
    return;
  }

  db.prepare('DELETE FROM panel_users WHERE id = ?').run(id);
  // Invalidate sessions
  for (const [t, s] of activeSessions.entries()) {
    if (s.panelUserId === id) activeSessions.delete(t);
  }
  recordAudit((req as any).user.username, 'PanelUserDeleted', target.username, req.ip || '127.0.0.1');
  res.json({ success: true });
});

// --- Config Users Management (Client consumers) ---
app.get('/api/v1/config-users', requireAuth, (req, res) => {
  const page = parseInt(req.query.page as string || '1', 10);
  const limit = parseInt(req.query.limit as string || '20', 10);
  const search = (req.query.search as string || '').trim().toLowerCase();
  const statusFilter = req.query.status as string;
  const offset = (page - 1) * limit;

  let query = 'SELECT * FROM config_users WHERE 1=1';
  const params: any[] = [];

  if (search) {
    query += ' AND (LOWER(username) LIKE ? OR notes LIKE ? OR user_group LIKE ?)';
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }

  if (statusFilter && statusFilter !== 'All') {
    query += ' AND status = ?';
    params.push(statusFilter);
  }

  const countQuery = query.replace('SELECT *', 'SELECT COUNT(*) as total');
  const { total } = db.prepare(countQuery).get(...params) as { total: number };

  query += ' ORDER BY id DESC LIMIT ? OFFSET ?';
  params.push(limit, offset);

  const users = db.prepare(query).all(...params) as any[];

  // Attach subscription & configs summary
  const subStmt = db.prepare('SELECT id, token, status FROM subscriptions WHERE config_user_id = ? ORDER BY id DESC LIMIT 1');
  const configsStmt = db.prepare('SELECT id, name, protocol, port FROM config_items WHERE config_user_id = ?');

  const enriched = users.map(u => ({
    ...u,
    subscription: subStmt.get(u.id) || null,
    configs: configsStmt.all(u.id) || [],
    tags: JSON.parse(u.tags || '[]'),
  }));

  res.json({
    config_users: enriched,
    pagination: {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit) || 1,
    }
  });
});

app.post('/api/v1/config-users', requireAuth, (req, res) => {
  const {
    username, traffic_quota_bytes = 0, device_limit = 2,
    user_group = 'Default', notes = '', tags = [], expires_at,
    inbound_protocols = ['vless', 'vmess']
  } = req.body;

  if (!username) {
    res.status(400).json({ error: { code: 'INVALID_INPUT', message: 'Username required.' } });
    return;
  }

  try {
    const now = new Date().toISOString();
    const uuid = crypto.randomUUID();

    const insert = db.prepare(`
      INSERT INTO config_users (
        uuid, username, status, traffic_quota_bytes, traffic_used_bytes,
        upload_bytes, download_bytes, device_limit, user_group, notes, tags,
        expires_at, created_at, updated_at
      ) VALUES (?, ?, 'Active', ?, 0, 0, 0, ?, ?, ?, ?, ?, ?, ?)
    `);

    const result = insert.run(
      uuid, username, traffic_quota_bytes, device_limit,
      user_group, notes, JSON.stringify(tags), expires_at || null, now, now
    );
    const configUserId = Number(result.lastInsertRowid);

    // Auto-create active subscription token
    const subToken = crypto.randomBytes(24).toString('hex');
    db.prepare("INSERT INTO subscriptions (config_user_id, token, status, created_at) VALUES (?, ?, 'Active', ?)")
      .run(configUserId, subToken, now);

    // Auto-create initial configs for selected protocols
    const configItemInsert = db.prepare(`
      INSERT INTO config_items (config_user_id, name, protocol, port, settings, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `);

    for (const proto of inbound_protocols) {
      const port = proto === 'vmess' ? 8443 : 443;
      configItemInsert.run(configUserId, `${username}-${proto.toUpperCase()}`, proto, port, '{}', now);
    }

    recordAudit((req as any).user.username, 'ConfigUserCreated', username, req.ip || '127.0.0.1', { configUserId });

    res.status(201).json({
      id: configUserId,
      uuid,
      username,
      status: 'Active',
      subscription_token: subToken,
    });
  } catch (err: any) {
    res.status(409).json({ error: { code: 'USER_EXISTS', message: 'Config username already in use.' } });
  }
});

app.get('/api/v1/config-users/:id', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const user = db.prepare('SELECT * FROM config_users WHERE id = ?').get(id) as any;
  if (!user) {
    res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Config user not found.' } });
    return;
  }
  const subs = db.prepare('SELECT * FROM subscriptions WHERE config_user_id = ? ORDER BY id DESC').all(id);
  const configs = db.prepare('SELECT * FROM config_items WHERE config_user_id = ?').all(id);
  res.json({
    config_user: {
      ...user,
      tags: JSON.parse(user.tags || '[]'),
      subscriptions: subs,
      configs,
    }
  });
});

app.put('/api/v1/config-users/:id', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const user = db.prepare('SELECT * FROM config_users WHERE id = ?').get(id) as any;
  if (!user) {
    res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Config user not found.' } });
    return;
  }

  const { status, traffic_quota_bytes, device_limit, user_group, notes, tags, expires_at } = req.body;
  const updates: string[] = ['updated_at = ?'];
  const params: any[] = [new Date().toISOString()];

  if (status) { updates.push('status = ?'); params.push(status); }
  if (traffic_quota_bytes !== undefined) { updates.push('traffic_quota_bytes = ?'); params.push(traffic_quota_bytes); }
  if (device_limit !== undefined) { updates.push('device_limit = ?'); params.push(device_limit); }
  if (user_group !== undefined) { updates.push('user_group = ?'); params.push(user_group); }
  if (notes !== undefined) { updates.push('notes = ?'); params.push(notes); }
  if (tags !== undefined) { updates.push('tags = ?'); params.push(JSON.stringify(tags)); }
  if (expires_at !== undefined) { updates.push('expires_at = ?'); params.push(expires_at); }

  params.push(id);
  db.prepare(`UPDATE config_users SET ${updates.join(', ')} WHERE id = ?`).run(...params);

  // If status disabled, also mark active subscriptions or vice versa
  if (status === 'Disabled') {
    db.prepare("UPDATE subscriptions SET status = 'Revoked' WHERE config_user_id = ?").run(id);
  }

  recordAudit((req as any).user.username, 'ConfigUserUpdated', user.username, req.ip || '127.0.0.1');
  res.json({ success: true });
});

app.delete('/api/v1/config-users/:id', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const user = db.prepare('SELECT username FROM config_users WHERE id = ?').get(id) as any;
  if (!user) {
    res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Config user not found.' } });
    return;
  }
  db.prepare('DELETE FROM config_users WHERE id = ?').run(id);
  recordAudit((req as any).user.username, 'ConfigUserDeleted', user.username, req.ip || '127.0.0.1');
  res.json({ success: true });
});

app.post('/api/v1/config-users/:id/traffic/reset', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  db.prepare(`
    UPDATE config_users SET
      traffic_used_bytes = 0,
      upload_bytes = 0,
      download_bytes = 0,
      status = CASE WHEN status = 'QuotaExceeded' THEN 'Active' ELSE status END,
      updated_at = ?
    WHERE id = ?
  `).run(new Date().toISOString(), id);
  res.json({ success: true });
});

app.post('/api/v1/config-users/:id/traffic/add', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const { upload_mb = 10, download_mb = 40 } = req.body;
  const user = db.prepare('SELECT * FROM config_users WHERE id = ?').get(id) as any;
  if (!user) {
    res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Config user not found.' } });
    return;
  }

  const addUpload = Math.round(upload_mb * 1024 * 1024);
  const addDownload = Math.round(download_mb * 1024 * 1024);
  const addTotal = addUpload + addDownload;

  const newUsed = Number(user.traffic_used_bytes) + addTotal;
  const newUpload = Number(user.upload_bytes) + addUpload;
  const newDownload = Number(user.download_bytes) + addDownload;
  const isExceeded = user.traffic_quota_bytes > 0 && newUsed >= user.traffic_quota_bytes;
  const newStatus = isExceeded ? 'QuotaExceeded' : user.status;

  db.prepare(`
    UPDATE config_users SET
      traffic_used_bytes = ?,
      upload_bytes = ?,
      download_bytes = ?,
      status = ?,
      updated_at = ?
    WHERE id = ?
  `).run(newUsed, newUpload, newDownload, newStatus, new Date().toISOString(), id);

  const todayStr = new Date().toISOString().slice(0, 10);
  db.prepare(`
    INSERT INTO daily_traffic (config_user_id, date_str, upload_bytes, download_bytes, total_bytes, updated_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(config_user_id, date_str) DO UPDATE SET
      upload_bytes = upload_bytes + excluded.upload_bytes,
      download_bytes = download_bytes + excluded.download_bytes,
      total_bytes = total_bytes + excluded.total_bytes,
      updated_at = excluded.updated_at
  `).run(id, todayStr, addUpload, addDownload, addTotal, new Date().toISOString());

  res.json({ success: true, traffic_used_bytes: newUsed, status: newStatus });
});

// --- API Keys Management ---
app.get('/api/v1/api-keys', requireAuth, (req, res) => {
  const panelUserId = (req as any).user.panelUserId;
  const keys = db.prepare(`
    SELECT id, name, key_prefix, permissions, last_used_at, created_at, revoked_at
    FROM api_keys
    WHERE panel_user_id = ?
    ORDER BY id DESC
  `).all(panelUserId) as any[];

  res.json({
    api_keys: keys.map(k => ({
      ...k,
      permissions: JSON.parse(k.permissions || '[]'),
      masked: `${k.key_prefix}****`,
    }))
  });
});

app.post('/api/v1/api-keys', requireAuth, (req, res) => {
  const panelUserId = (req as any).user.panelUserId;
  const { name, permissions = ['dashboard.read', 'users.read'] } = req.body;

  if (!name) {
    res.status(400).json({ error: { code: 'INVALID_INPUT', message: 'API Key name required.' } });
    return;
  }

  // Generate high-entropy secret with prefix
  const rawBytes = crypto.randomBytes(24).toString('hex');
  const secretKey = `rpn_${rawBytes}`;
  const keyPrefix = secretKey.slice(0, 8);
  const keyHash = crypto.createHash('sha256').update(secretKey).digest('hex');
  const now = new Date().toISOString();

  const result = db.prepare(`
    INSERT INTO api_keys (panel_user_id, name, key_prefix, key_hash, permissions, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(panelUserId, name, keyPrefix, keyHash, JSON.stringify(permissions), now);

  recordAudit((req as any).user.username, 'ApiKeyCreated', name, req.ip || '127.0.0.1');

  // Return full secret ONLY ONCE
  res.status(201).json({
    id: result.lastInsertRowid,
    name,
    key_prefix: keyPrefix,
    masked: `${keyPrefix}****`,
    secret_key: secretKey,
    permissions,
    created_at: now,
  });
});

app.post('/api/v1/api-keys/:id/revoke', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const panelUserId = (req as any).user.panelUserId;
  db.prepare('UPDATE api_keys SET revoked_at = ? WHERE id = ? AND panel_user_id = ?')
    .run(new Date().toISOString(), id, panelUserId);
  res.json({ success: true });
});

app.delete('/api/v1/api-keys/:id', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const panelUserId = (req as any).user.panelUserId;
  db.prepare('DELETE FROM api_keys WHERE id = ? AND panel_user_id = ?').run(id, panelUserId);
  res.json({ success: true });
});

// --- API Logs Endpoint ---
app.get('/api/v1/api-logs', requireAuth, (req, res) => {
  const page = parseInt(req.query.page as string || '1', 10);
  const limit = parseInt(req.query.limit as string || '30', 10);
  const offset = (page - 1) * limit;

  const { total } = db.prepare('SELECT COUNT(*) as total FROM api_logs').get() as { total: number };
  const logs = db.prepare(`
    SELECT l.*, p.username as panel_username
    FROM api_logs l
    LEFT JOIN panel_users p ON l.panel_user_id = p.id
    ORDER BY l.id DESC
    LIMIT ? OFFSET ?
  `).all(limit, offset) as any[];

  res.json({
    api_logs: logs,
    pagination: {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit) || 1,
    }
  });
});

// --- Dashboard Endpoint ---
app.get('/api/v1/dashboard', requireAuth, (req, res) => {
  const panelCount = (db.prepare('SELECT COUNT(*) as c FROM panel_users').get() as any).c;
  const configUsers = db.prepare('SELECT status, traffic_used_bytes, upload_bytes, download_bytes FROM config_users').all() as any[];

  const totalConfigUsers = configUsers.length;
  const activeUsers = configUsers.filter(u => u.status === 'Active').length;
  const expiredUsers = configUsers.filter(u => u.status === 'Expired').length;
  const disabledUsers = configUsers.filter(u => u.status === 'Disabled').length;

  let totalTraffic = 0;
  let totalUpload = 0;
  let totalDownload = 0;
  for (const u of configUsers) {
    totalTraffic += Number(u.traffic_used_bytes || 0);
    totalUpload += Number(u.upload_bytes || 0);
    totalDownload += Number(u.download_bytes || 0);
  }

  const todayStr = new Date().toISOString().slice(0, 10);
  const todayRow = db.prepare('SELECT SUM(total_bytes) as today_total FROM daily_traffic WHERE date_str = ?').get(todayStr) as any;
  const todayTraffic = Number(todayRow?.today_total || Math.round(totalTraffic * 0.12));

  const nodes = db.prepare('SELECT * FROM nodes').all() as any[];

  const trafficHistory = [
    { date: '5 days ago', upload: Math.round(totalUpload * 0.14), download: Math.round(totalDownload * 0.14) },
    { date: '4 days ago', upload: Math.round(totalUpload * 0.16), download: Math.round(totalDownload * 0.16) },
    { date: '3 days ago', upload: Math.round(totalUpload * 0.18), download: Math.round(totalDownload * 0.19) },
    { date: '2 days ago', upload: Math.round(totalUpload * 0.22), download: Math.round(totalDownload * 0.21) },
    { date: 'Yesterday', upload: Math.round(totalUpload * 0.24), download: Math.round(totalDownload * 0.25) },
    { date: 'Today', upload: Math.round(totalUpload * 0.06), download: Math.round(totalDownload * 0.05) },
  ];

  res.json({
    total_panel_users: panelCount,
    total_config_users: totalConfigUsers,
    active_users: activeUsers,
    expired_users: expiredUsers,
    disabled_users: disabledUsers,
    total_traffic: totalTraffic,
    total_upload: totalUpload,
    total_download: totalDownload,
    today_traffic: todayTraffic,
    online_users: Math.max(1, Math.round(activeUsers * 0.6)),
    nodes_count: nodes.length,
    cpu_usage: 2.1,
    ram_usage: 28.5,
    disk_usage: 12.4,
    uptime_seconds: 482000,
    xray_status: 'Running',
    database_status: 'Online',
    nodes,
    traffic_history: trafficHistory,
  });
});

// --- Subscriptions & QR ---
app.get('/api/v1/subscriptions', requireAuth, (req, res) => {
  const subs = db.prepare(`
    SELECT s.*, c.username as config_username, c.status as user_status
    FROM subscriptions s
    JOIN config_users c ON s.config_user_id = c.id
    ORDER BY s.id DESC
  `).all();
  res.json({ subscriptions: subs });
});

app.post('/api/v1/subscriptions', requireAuth, (req, res) => {
  const { config_user_id } = req.body;
  if (!config_user_id) {
    res.status(400).json({ error: { code: 'INVALID_INPUT', message: 'config_user_id required.' } });
    return;
  }
  const token = crypto.randomBytes(24).toString('hex');
  const now = new Date().toISOString();
  const result = db.prepare("INSERT INTO subscriptions (config_user_id, token, status, created_at) VALUES (?, ?, 'Active', ?)")
    .run(config_user_id, token, now);

  res.status(201).json({ id: result.lastInsertRowid, token, status: 'Active' });
});

app.post('/api/v1/subscriptions/:id/revoke', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  db.prepare("UPDATE subscriptions SET status = 'Revoked', revoked_at = ? WHERE id = ?")
    .run(new Date().toISOString(), id);
  res.json({ success: true });
});

app.get('/api/v1/subscriptions/:id/qr', requireAuth, async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const sub = db.prepare('SELECT token FROM subscriptions WHERE id = ?').get(id) as any;
  if (!sub) {
    res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Subscription not found.' } });
    return;
  }

  const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'http';
  const host = req.headers['x-forwarded-host'] || req.get('host') || 'localhost:3000';
  const subUrl = `${protocol}://${host}/sub/${sub.token}`;

  try {
    const qrDataUrl = await QRCode.toDataURL(subUrl, {
      errorCorrectionLevel: 'H',
      margin: 2,
      width: 320,
      color: { dark: '#020617', light: '#ffffff' }
    });
    res.json({ url: subUrl, qr: qrDataUrl });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'QR_ERROR', message: err.message } });
  }
});

// Public subscription endpoint (checks if config_user is active)
app.get('/sub/:token', (req, res) => {
  const token = req.params.token;
  const sub = db.prepare(`
    SELECT s.*, c.status as user_status, c.username
    FROM subscriptions s
    JOIN config_users c ON s.config_user_id = c.id
    WHERE s.token = ? AND s.status = 'Active'
  `).get(token) as any;

  if (!sub || sub.user_status !== 'Active') {
    res.status(404).send('Subscription link disabled or expired.');
    return;
  }

  const configs = [
    `vless://${sub.token}@127.0.0.1:443?security=reality&type=tcp&headerType=none#RavanPanel-${sub.username}`,
    `vmess://${Buffer.from(JSON.stringify({ v: "2", ps: `RavanPanel-${sub.username}-Edge`, add: "127.0.0.1", port: 443, id: sub.token, aid: 0, scy: "auto", net: "ws", type: "none", host: "", path: "/ravan", tls: "tls" })).toString('base64')}`
  ];

  const payload = Buffer.from(configs.join('\n')).toString('base64');
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.send(payload);
});

// --- Nodes, Blocklist, Backups, Audit, Telegram, Health, Settings ---
app.get('/api/v1/nodes', requireAuth, (req, res) => {
  const nodes = db.prepare('SELECT * FROM nodes ORDER BY is_local DESC, id ASC').all();
  res.json({ nodes });
});

app.post('/api/v1/nodes', requireAuth, (req, res) => {
  const { name, address, port = 443 } = req.body;
  const now = new Date().toISOString();
  const result = db.prepare(`
    INSERT INTO nodes (name, address, port, status, version, cpu_usage, ram_usage, disk_usage, uptime_seconds, last_seen_at, is_local)
    VALUES (?, ?, ?, 'Online', 'v0.1.0', 1.2, 18.0, 9.0, 0, ?, 0)
  `).run(name, address, port, now);
  res.status(201).json({ id: result.lastInsertRowid, name, address, port });
});

app.post('/api/v1/nodes/:id/restart', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  res.json({ success: true, message: `Node #${id} restart dispatched.` });
});

app.get('/api/v1/blocklist', requireAuth, (req, res) => {
  const rules = db.prepare('SELECT * FROM blocklists ORDER BY id DESC').all();
  res.json({ rules });
});

app.post('/api/v1/blocklist', requireAuth, (req, res) => {
  const { type, value, comment = '' } = req.body;
  try {
    const result = db.prepare('INSERT INTO blocklists (type, value, enabled, comment, created_at) VALUES (?, ?, 1, ?, ?)')
      .run(type, value.trim(), comment, new Date().toISOString());
    res.status(201).json({ id: result.lastInsertRowid, type, value, comment });
  } catch {
    res.status(409).json({ error: { code: 'EXISTS', message: 'Rule already exists.' } });
  }
});

app.delete('/api/v1/blocklist/:id', requireAuth, (req, res) => {
  db.prepare('DELETE FROM blocklists WHERE id = ?').run(parseInt(req.params.id, 10));
  res.json({ success: true });
});

app.put('/api/v1/blocklist/:id/toggle', requireAuth, (req, res) => {
  db.prepare('UPDATE blocklists SET enabled = CASE WHEN enabled = 1 THEN 0 ELSE 1 END WHERE id = ?')
    .run(parseInt(req.params.id, 10));
  res.json({ success: true });
});

// Backups
const BACKUP_DIR = path.resolve(process.env.BACKUP_DIR || './backups');
if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

app.get('/api/v1/backups', requireAuth, (req, res) => {
  const files = fs.readdirSync(BACKUP_DIR).filter(f => f.endsWith('.json'));
  const snapshots = files.map(file => {
    const stat = fs.statSync(path.join(BACKUP_DIR, file));
    return { name: file, size_bytes: stat.size, created_at: stat.mtime.toISOString() };
  }).sort((a, b) => b.created_at.localeCompare(a.created_at));
  res.json({ backups: snapshots });
});

app.post('/api/v1/backups', requireAuth, (req, res) => {
  const pUsers = db.prepare('SELECT * FROM panel_users').all();
  const cUsers = db.prepare('SELECT * FROM config_users').all();
  const subs = db.prepare('SELECT * FROM subscriptions').all();
  const blocks = db.prepare('SELECT * FROM blocklists').all();

  const manifest = {
    version: 'v0.1.0',
    created_at: new Date().toISOString(),
    panel_user_count: pUsers.length,
    config_user_count: cUsers.length,
    sub_count: subs.length,
  };

  const payload = { manifest, panel_users: pUsers, config_users: cUsers, subscriptions: subs, blocklists: blocks };
  const fileName = `backup_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
  fs.writeFileSync(path.join(BACKUP_DIR, fileName), JSON.stringify(payload, null, 2), 'utf-8');

  recordAudit((req as any).user.username, 'BackupCreated', fileName, req.ip || '127.0.0.1');
  res.status(201).json({ success: true, backup: fileName, manifest });
});

app.post('/api/v1/backups/:name/restore', requireAuth, requireRole(['Owner']), (req, res) => {
  const filePath = path.join(BACKUP_DIR, req.params.name);
  if (!fs.existsSync(filePath)) {
    res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Backup file not found.' } });
    return;
  }
  try {
    const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    // Restore config users
    if (Array.isArray(data.config_users)) {
      db.exec('DELETE FROM subscriptions; DELETE FROM config_users;');
      const insert = db.prepare(`
        INSERT INTO config_users (id, uuid, username, status, traffic_quota_bytes, traffic_used_bytes, upload_bytes, download_bytes, device_limit, user_group, notes, tags, expires_at, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      for (const u of data.config_users) {
        insert.run(u.id, u.uuid, u.username, u.status, u.traffic_quota_bytes, u.traffic_used_bytes, u.upload_bytes, u.download_bytes, u.device_limit, u.user_group, u.notes, u.tags, u.expires_at, u.created_at, u.updated_at);
      }
    }
    recordAudit((req as any).user.username, 'BackupRestored', req.params.name, req.ip || '127.0.0.1');
    res.json({ success: true, message: 'Restore completed successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'RESTORE_ERROR', message: err.message } });
  }
});

app.delete('/api/v1/backups/:name', requireAuth, requireRole(['Owner']), (req, res) => {
  const filePath = path.join(BACKUP_DIR, req.params.name);
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  res.json({ success: true });
});

app.get('/api/v1/audit', requireAuth, (req, res) => {
  const page = parseInt(req.query.page as string || '1', 10);
  const limit = parseInt(req.query.limit as string || '30', 10);
  const offset = (page - 1) * limit;

  const { total } = db.prepare('SELECT COUNT(*) as total FROM audit_logs').get() as { total: number };
  const logs = db.prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT ? OFFSET ?').all(limit, offset) as any[];

  res.json({
    logs: logs.map(l => ({ ...l, metadata: JSON.parse(l.metadata || '{}') })),
    pagination: { page, limit, total, pages: Math.ceil(total / limit) || 1 }
  });
});

app.post('/api/v1/telegram/command', requireAuth, (req, res) => {
  const { command } = req.body;
  if (!command) {
    res.status(400).json({ error: { code: 'INVALID', message: 'Command required.' } });
    return;
  }
  const parts = command.trim().split(/\s+/);
  const cmd = parts[0].toLowerCase();

  if (cmd === '/start' || cmd === '/help') {
    res.json({ reply: '🤖 RavanPanel Telegram Bot\nدستورات:\n• /status\n• /users\n• /user <username>\n• /traffic <username>\n• /disable <username>\n• /enable <username>' });
    return;
  }
  if (cmd === '/status') {
    const cUsers = db.prepare('SELECT status, traffic_used_bytes FROM config_users').all() as any[];
    const active = cUsers.filter(u => u.status === 'Active').length;
    res.json({ reply: `📊 وضعیت روان‌پنل\n👥 کاربران فعال سرویس: ${active} از ${cUsers.length}\n⚙️ هسته: Running\n🗄️ دیتابیس: Online` });
    return;
  }
  if (cmd === '/users') {
    const users = db.prepare('SELECT username, status FROM config_users LIMIT 10').all() as any[];
    res.json({ reply: `👥 کاربران سرویس:\n` + users.map(u => `• ${u.username} (${u.status})`).join('\n') });
    return;
  }
  res.json({ reply: 'دستور نامعتبر است. جهت مشاهده راهنما /help را ارسال نمایید.' });
});

// Settings Endpoints
app.get('/api/v1/settings', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT key, value FROM system_settings').all() as any[];
  const settings: Record<string, string> = {};
  for (const r of rows) settings[r.key] = r.value;
  res.json({ settings });
});

app.put('/api/v1/settings', requireAuth, requireRole(['Owner', 'Admin']), (req, res) => {
  const { settings } = req.body;
  const now = new Date().toISOString();
  const upsert = db.prepare('INSERT OR REPLACE INTO system_settings (key, value, updated_at) VALUES (?, ?, ?)');
  for (const [k, v] of Object.entries(settings || {})) {
    upsert.run(k, String(v), now);
  }
  recordAudit((req as any).user.username, 'SettingsUpdated', 'SystemSettings', req.ip || '127.0.0.1');
  res.json({ success: true });
});

app.get('/health/live', (req, res) => res.json({ status: 'ok', checks: { api: 'ok' } }));
app.get('/health/ready', (req, res) => {
  res.json({ status: 'ok', checks: { database: 'ok', xray: 'ok', disk: 'ok', memory: 'ok' } });
});
app.get('/api/v1/health', (req, res) => {
  res.json({ status: 'ok', checks: { database: 'ok', xray: 'ok', disk: 'ok', memory: 'ok' } });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve('dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[RavanPanel] Full-Stack Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[RavanPanel] Failed to start server:', err);
  process.exit(1);
});
