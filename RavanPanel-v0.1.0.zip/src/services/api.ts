export interface PanelUser {
  id: number;
  uuid: string;
  username: string;
  email: string;
  role: 'Owner' | 'Admin' | 'Operator' | 'Support' | 'ReadOnly';
  status: 'Active' | 'Disabled';
  permissions: string[];
  two_factor_enabled: number;
  created_at: string;
  last_login_at?: string;
}

export interface ConfigUser {
  id: number;
  uuid: string;
  username: string;
  status: 'Active' | 'Disabled' | 'Expired' | 'QuotaExceeded';
  traffic_quota_bytes: number;
  traffic_used_bytes: number;
  upload_bytes: number;
  download_bytes: number;
  device_limit: number;
  user_group: string;
  notes: string;
  tags: string[];
  expires_at?: string;
  created_at: string;
  updated_at: string;
  subscription?: {
    id: number;
    token: string;
    status: string;
  };
  configs?: Array<{
    id: number;
    name: string;
    protocol: string;
    port: number;
  }>;
}

export interface ApiKeyItem {
  id: number;
  name: string;
  key_prefix: string;
  masked: string;
  permissions: string[];
  last_used_at?: string;
  created_at: string;
  revoked_at?: string;
}

export interface ApiLogItem {
  id: number;
  panel_username?: string;
  key_prefix?: string;
  method: string;
  endpoint: string;
  status_code: number;
  ip_address: string;
  duration_ms: number;
  created_at: string;
}

export interface Subscription {
  id: number;
  config_user_id: number;
  config_username: string;
  user_status: string;
  token: string;
  status: string;
  created_at: string;
  revoked_at?: string;
}

export interface Node {
  id: number;
  name: string;
  address: string;
  port: number;
  status: string;
  version: string;
  cpu_usage: number;
  ram_usage: number;
  disk_usage: number;
  uptime_seconds: number;
  last_seen_at: string;
  is_local: number;
}

export interface BlocklistRule {
  id: number;
  type: string;
  value: string;
  enabled: number;
  comment: string;
  created_at: string;
}

export interface BackupItem {
  name: string;
  size_bytes: number;
  created_at: string;
}

export interface AuditLogItem {
  id: number;
  actor: string;
  action: string;
  target: string;
  ip_address: string;
  metadata: Record<string, any>;
  created_at: string;
}

export interface DashboardData {
  total_panel_users: number;
  total_config_users: number;
  active_users: number;
  expired_users: number;
  disabled_users: number;
  total_traffic: number;
  total_upload: number;
  total_download: number;
  today_traffic: number;
  online_users: number;
  nodes_count: number;
  cpu_usage: number;
  ram_usage: number;
  disk_usage: number;
  uptime_seconds: number;
  xray_status: string;
  database_status: string;
  nodes: Node[];
  traffic_history: { date: string; upload: number; download: number }[];
}

class ApiService {
  private token: string | null = null;

  constructor() {
    this.token = localStorage.getItem('ravan_auth_token');
  }

  setToken(t: string | null) {
    this.token = t;
    if (t) localStorage.setItem('ravan_auth_token', t);
    else localStorage.removeItem('ravan_auth_token');
  }

  getToken(): string | null {
    return this.token;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const headers = new Headers(options.headers || {});
    headers.set('Content-Type', 'application/json');
    if (this.token) {
      headers.set('Authorization', `Bearer ${this.token}`);
    }

    const res = await fetch(endpoint, {
      ...options,
      headers,
    });

    if (res.status === 401) {
      this.setToken(null);
      window.dispatchEvent(new Event('ravan_unauthorized'));
    }

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg = data.error?.message || `Request failed with status ${res.status}`;
      throw new Error(msg);
    }
    return data as T;
  }

  // Setup Wizard & System Status
  async getSetupStatus() {
    return this.request<{ needs_setup: boolean; allow_registration: boolean; panel_user_count: number }>('/api/v1/system/setup-status');
  }

  async setupOwner(data: { username: string; email?: string; password: string }) {
    return this.request<{ success: boolean; message: string }>('/api/v1/system/setup-owner', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  // Auth (Panel Users ONLY)
  async login(username: string, password: string) {
    const data = await this.request<{ token: string; user: PanelUser }>('/api/v1/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });
    this.setToken(data.token);
    return data;
  }

  async register(data: { username: string; email?: string; password: string }) {
    return this.request<{ success: boolean; message: string }>('/api/v1/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async logout() {
    try {
      await this.request('/api/v1/auth/logout', { method: 'POST' });
    } finally {
      this.setToken(null);
    }
  }

  async getMe() {
    return this.request<{ user: PanelUser }>('/api/v1/auth/me');
  }

  // Dashboard
  async getDashboard() {
    return this.request<DashboardData>('/api/v1/dashboard');
  }

  // Panel Users Management
  async getPanelUsers() {
    return this.request<{ panel_users: PanelUser[] }>('/api/v1/panel-users');
  }

  async createPanelUser(data: { username: string; email?: string; password: string; role: string; permissions?: string[] }) {
    return this.request<any>('/api/v1/panel-users', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async updatePanelUser(id: number, data: any) {
    return this.request<{ success: boolean }>(`/api/v1/panel-users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  async deletePanelUser(id: number) {
    return this.request<{ success: boolean }>(`/api/v1/panel-users/${id}`, {
      method: 'DELETE',
    });
  }

  // Config Users Management (Clients)
  async getConfigUsers(params: { page?: number; limit?: number; search?: string; status?: string } = {}) {
    const q = new URLSearchParams();
    if (params.page) q.set('page', String(params.page));
    if (params.limit) q.set('limit', String(params.limit));
    if (params.search) q.set('search', params.search);
    if (params.status) q.set('status', params.status);
    return this.request<{ config_users: ConfigUser[]; pagination: any }>(`/api/v1/config-users?${q.toString()}`);
  }

  async getConfigUser(id: number) {
    return this.request<{ config_user: ConfigUser }>(`/api/v1/config-users/${id}`);
  }

  async createConfigUser(data: any) {
    return this.request<any>('/api/v1/config-users', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async updateConfigUser(id: number, data: any) {
    return this.request<{ success: boolean }>(`/api/v1/config-users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  async deleteConfigUser(id: number) {
    return this.request<{ success: boolean }>(`/api/v1/config-users/${id}`, {
      method: 'DELETE',
    });
  }

  async resetConfigUserTraffic(id: number) {
    return this.request<{ success: boolean }>(`/api/v1/config-users/${id}/traffic/reset`, {
      method: 'POST',
    });
  }

  async addTestTraffic(id: number, upload_mb: number, download_mb: number) {
    return this.request<any>(`/api/v1/config-users/${id}/traffic/add`, {
      method: 'POST',
      body: JSON.stringify({ upload_mb, download_mb }),
    });
  }

  // API Keys
  async getApiKeys() {
    return this.request<{ api_keys: ApiKeyItem[] }>('/api/v1/api-keys');
  }

  async createApiKey(data: { name: string; permissions: string[] }) {
    return this.request<{
      id: number;
      name: string;
      key_prefix: string;
      masked: string;
      secret_key: string;
      permissions: string[];
      created_at: string;
    }>('/api/v1/api-keys', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async revokeApiKey(id: number) {
    return this.request<{ success: boolean }>(`/api/v1/api-keys/${id}/revoke`, {
      method: 'POST',
    });
  }

  async deleteApiKey(id: number) {
    return this.request<{ success: boolean }>(`/api/v1/api-keys/${id}`, {
      method: 'DELETE',
    });
  }

  // API Logs
  async getApiLogs(page = 1, limit = 30) {
    return this.request<{ api_logs: ApiLogItem[]; pagination: any }>(`/api/v1/api-logs?page=${page}&limit=${limit}`);
  }

  // Subscriptions & QR
  async getSubscriptions() {
    return this.request<{ subscriptions: Subscription[] }>('/api/v1/subscriptions');
  }

  async createSubscription(configUserId: number) {
    return this.request<any>('/api/v1/subscriptions', {
      method: 'POST',
      body: JSON.stringify({ config_user_id: configUserId }),
    });
  }

  async revokeSubscription(id: number) {
    return this.request<{ success: boolean }>(`/api/v1/subscriptions/${id}/revoke`, {
      method: 'POST',
    });
  }

  async getSubscriptionQr(id: number) {
    return this.request<{ url: string; qr: string }>(`/api/v1/subscriptions/${id}/qr`);
  }

  // Nodes
  async getNodes() {
    return this.request<{ nodes: Node[] }>('/api/v1/nodes');
  }

  async createNode(data: { name: string; address: string; port: number }) {
    return this.request<any>('/api/v1/nodes', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async restartNode(id: number) {
    return this.request<{ success: boolean; message: string }>(`/api/v1/nodes/${id}/restart`, {
      method: 'POST',
    });
  }

  // Blocklist
  async getBlocklist() {
    return this.request<{ rules: BlocklistRule[] }>('/api/v1/blocklist');
  }

  async addBlocklistRule(data: { type: string; value: string; comment?: string }) {
    return this.request<any>('/api/v1/blocklist', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async deleteBlocklistRule(id: number) {
    return this.request<{ success: boolean }>(`/api/v1/blocklist/${id}`, {
      method: 'DELETE',
    });
  }

  async toggleBlocklistRule(id: number) {
    return this.request<{ success: boolean }>(`/api/v1/blocklist/${id}/toggle`, {
      method: 'PUT',
    });
  }

  // Backups
  async getBackups() {
    return this.request<{ backups: BackupItem[] }>('/api/v1/backups');
  }

  async createBackup() {
    return this.request<any>('/api/v1/backups', { method: 'POST' });
  }

  async restoreBackup(name: string) {
    return this.request<{ success: boolean; message: string }>(`/api/v1/backups/${encodeURIComponent(name)}/restore`, {
      method: 'POST',
    });
  }

  async deleteBackup(name: string) {
    return this.request<{ success: boolean }>(`/api/v1/backups/${encodeURIComponent(name)}`, {
      method: 'DELETE',
    });
  }

  // Audit Logs
  async getAuditLogs(page = 1, limit = 25) {
    return this.request<{ logs: AuditLogItem[]; pagination: any }>(`/api/v1/audit?page=${page}&limit=${limit}`);
  }

  // Telegram
  async sendTelegramCommand(command: string) {
    return this.request<{ reply: string }>('/api/v1/telegram/command', {
      method: 'POST',
      body: JSON.stringify({ command }),
    });
  }

  // Settings
  async getSettings() {
    return this.request<{ settings: Record<string, string> }>('/api/v1/settings');
  }

  async updateSettings(settings: Record<string, string>) {
    return this.request<{ success: boolean }>('/api/v1/settings', {
      method: 'PUT',
      body: JSON.stringify({ settings }),
    });
  }

  // Health
  async getHealth() {
    const res = await fetch('/health/ready');
    return res.json();
  }
}

export const api = new ApiService();
