import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Users as UsersIcon,
  UserCheck,
  UserCog,
  QrCode,
  Server,
  ShieldAlert,
  Send,
  Database,
  History,
  Activity,
  LogOut,
  Moon,
  Sun,
  Globe,
  Plus,
  RefreshCw,
  Search,
  CheckCircle2,
  AlertTriangle,
  Copy,
  Download,
  Trash2,
  Edit,
  ArrowUpRight,
  ArrowDownLeft,
  HardDrive,
  Cpu,
  Layers,
  Terminal,
  Key,
  FileText,
  Sliders,
  ChevronDown,
  ChevronRight,
  Menu,
  X,
  Radio,
  Clock,
  Eye,
  Lock,
} from 'lucide-react';
import { translations, Language } from './i18n/translations';
import { RavanLogo } from './components/RavanLogo';
import {
  api,
  PanelUser,
  ConfigUser,
  ApiKeyItem,
  ApiLogItem,
  Subscription,
  Node as NodeItem,
  BlocklistRule,
  BackupItem,
  AuditLogItem,
  DashboardData,
} from './services/api';

function formatBytes(bytes: number): string {
  if (!bytes || bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(2)} ${sizes[i]}`;
}

function formatDate(isoStr?: string): string {
  if (!isoStr) return '—';
  try {
    const d = new Date(isoStr);
    return d.toLocaleString('fa-IR', {
      month: 'numeric',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return isoStr;
  }
}

export default function App() {
  const [lang, setLang] = useState<Language>(() => {
    return (localStorage.getItem('ravan_lang') as Language) || 'fa';
  });
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [accent, setAccent] = useState<string>('#06b6d4'); // Default cyan
  const [user, setUser] = useState<PanelUser | null>(null);
  const [nav, setNav] = useState<string>('dashboard');
  const [loading, setLoading] = useState<boolean>(true);
  const [needsSetup, setNeedsSetup] = useState<boolean>(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  // Expanded groups in sidebar
  const [expandedMenus, setExpandedMenus] = useState<Record<string, boolean>>({
    users: true,
    configs: false,
    subscriptions: false,
    traffic: false,
    nodes: false,
    logs: true,
    settings: false,
  });

  // Auth & Setup states
  const [isRegisterMode, setIsRegisterMode] = useState<boolean>(false);
  const [loginUser, setLoginUser] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [loginError, setLoginError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Setup Wizard State
  const [setupStep, setSetupStep] = useState(1);
  const [setupOwner, setSetupOwner] = useState({ username: 'owner', email: 'owner@ravanpanel.local', password: '', confirmPassword: '' });

  // Register Form State
  const [regForm, setRegForm] = useState({ username: '', email: '', password: '', confirmPassword: '' });

  // Notifications
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const t = translations[lang];

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 4000);
  };

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    localStorage.setItem('ravan_lang', lang);
  }, [lang]);

  // Initial Boot Check
  useEffect(() => {
    api.getSetupStatus()
      .then((status) => {
        if (status.needs_setup) {
          setNeedsSetup(true);
          setLoading(false);
          return;
        }

        const token = api.getToken();
        if (token) {
          api.getMe()
            .then((res) => {
              setUser(res.user);
              setLoading(false);
            })
            .catch(() => {
              api.setToken(null);
              setUser(null);
              setLoading(false);
            });
        } else {
          setLoading(false);
        }
      })
      .catch(() => setLoading(false));

    const onUnauthorized = () => {
      setUser(null);
      showNotification('error', lang === 'fa' ? 'نشست شما منقضی شد.' : 'Session expired.');
    };
    window.addEventListener('ravan_unauthorized', onUnauthorized);
    return () => window.removeEventListener('ravan_unauthorized', onUnauthorized);
  }, [lang]);

  // Setup Wizard Submit
  const handleSetupOwnerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (setupOwner.password !== setupOwner.confirmPassword) {
      setLoginError(t.setup.passwordsDoNotMatch);
      return;
    }
    setLoginError('');
    setIsSubmitting(true);
    try {
      await api.setupOwner({
        username: setupOwner.username,
        email: setupOwner.email,
        password: setupOwner.password,
      });
      // Auto login owner
      const res = await api.login(setupOwner.username, setupOwner.password);
      setUser(res.user);
      setNeedsSetup(false);
      setNav('dashboard');
      showNotification('success', t.common.success);
    } catch (err: any) {
      setLoginError(err.message || 'Setup error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Login Submit (Panel Users ONLY)
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setIsSubmitting(true);
    try {
      const res = await api.login(loginUser, loginPass);
      setUser(res.user);
      setNav('dashboard');
    } catch (err: any) {
      setLoginError(err.message || t.auth.invalidCredentials);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Register Submit (New Panel User)
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (regForm.password !== regForm.confirmPassword) {
      setLoginError(t.setup.passwordsDoNotMatch);
      return;
    }
    setLoginError('');
    setIsSubmitting(true);
    try {
      await api.register({
        username: regForm.username,
        email: regForm.email,
        password: regForm.password,
      });
      showNotification('success', t.common.success);
      setIsRegisterMode(false);
      setLoginUser(regForm.username);
      setLoginPass(regForm.password);
    } catch (err: any) {
      setLoginError(err.message || 'Registration error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLogout = async () => {
    await api.logout();
    setUser(null);
  };

  const toggleMenu = (key: string) => {
    setExpandedMenus(prev => ({ ...prev, [key]: !prev[key] }));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <RavanLogo size={42} accentColor={accent} />
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
            <RefreshCw className="w-3.5 h-3.5 animate-spin" style={{ color: accent }} />
            <span>{t.common.loading}</span>
          </div>
        </div>
      </div>
    );
  }

  // --- 1. First Launch Setup Wizard ---
  if (needsSetup) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between p-6">
        <div className="max-w-md w-full mx-auto my-auto">
          <div className="text-center mb-6">
            <RavanLogo size={48} accentColor={accent} className="justify-center" />
            <p className="mt-2 text-xs text-slate-400">{t.setup.welcome}</p>
          </div>

          <div className="p-6 rounded-xl border border-slate-800 bg-slate-900/70 backdrop-blur-sm shadow-xl">
            <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
              <span className="text-xs font-semibold uppercase tracking-wider text-cyan-400">
                Setup Wizard · Step {setupStep} of 2
              </span>
              <span className="text-[11px] text-slate-500">{t.version}</span>
            </div>

            {loginError && (
              <div className="mb-4 p-3 rounded-lg text-xs bg-rose-500/10 border border-rose-500/20 text-rose-400 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{loginError}</span>
              </div>
            )}

            {setupStep === 1 ? (
              <form onSubmit={handleSetupOwnerSubmit} className="space-y-3.5 text-xs">
                <div>
                  <h2 className="text-sm font-bold text-slate-100">{t.setup.step1Title}</h2>
                  <p className="text-[11px] text-slate-400 mt-0.5">{t.setup.step1Desc}</p>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">{t.setup.username} *</label>
                  <input
                    type="text"
                    required
                    value={setupOwner.username}
                    onChange={(e) => setSetupOwner({ ...setupOwner, username: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-100 outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">{t.setup.email}</label>
                  <input
                    type="email"
                    value={setupOwner.email}
                    onChange={(e) => setSetupOwner({ ...setupOwner, email: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-100 outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">{t.setup.password} *</label>
                  <input
                    type="password"
                    required
                    value={setupOwner.password}
                    onChange={(e) => setSetupOwner({ ...setupOwner, password: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-100 outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">{t.setup.confirmPassword} *</label>
                  <input
                    type="password"
                    required
                    value={setupOwner.confirmPassword}
                    onChange={(e) => setSetupOwner({ ...setupOwner, confirmPassword: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-100 outline-none focus:border-cyan-500"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full mt-4 py-2.5 px-4 text-xs font-semibold rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isSubmitting && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                  <span>{t.setup.createOwnerBtn}</span>
                </button>
              </form>
            ) : null}
          </div>
        </div>
      </div>
    );
  }

  // --- 2. Login & Registration Views (Panel Users ONLY) ---
  if (!user) {
    return (
      <div className={`min-h-screen flex flex-col justify-between ${theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
        <div className="max-w-md w-full mx-auto my-auto px-6 py-12">
          <div className="text-center mb-8">
            <RavanLogo size={42} accentColor={accent} className="justify-center" />
            <p className="mt-2 text-xs text-slate-400">{t.brandSubtitle}</p>
          </div>

          <div className={`p-6 rounded-xl border ${theme === 'dark' ? 'bg-slate-900/70 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
            <h2 className="text-base font-semibold text-center mb-1">
              {isRegisterMode ? t.auth.registerTitle : t.auth.loginTitle}
            </h2>
            <p className="text-[11px] text-slate-400 text-center mb-5">
              {isRegisterMode ? t.auth.registerSubtitle : t.auth.loginSubtitle}
            </p>

            {loginError && (
              <div className="mb-4 p-3 rounded-lg text-xs bg-rose-500/10 border border-rose-500/20 text-rose-400 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{loginError}</span>
              </div>
            )}

            {!isRegisterMode ? (
              // Login Form
              <form onSubmit={handleLogin} className="space-y-3.5 text-xs">
                <div>
                  <label className="block text-slate-400 mb-1">{t.auth.username}</label>
                  <input
                    type="text"
                    required
                    value={loginUser}
                    onChange={(e) => setLoginUser(e.target.value)}
                    placeholder="owner"
                    className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800/80 text-slate-100 outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">{t.auth.password}</label>
                  <input
                    type="password"
                    required
                    value={loginPass}
                    onChange={(e) => setLoginPass(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800/80 text-slate-100 outline-none focus:border-cyan-500"
                  />
                </div>

                <div className="p-2.5 rounded-lg bg-slate-800/40 border border-slate-800 text-[11px] text-slate-400">
                  <div className="flex items-center gap-1.5 font-medium text-slate-300 mb-0.5">
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Panel User Authentication</span>
                  </div>
                  <span>{t.auth.configUserCannotLogin}</span>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full mt-2 py-2.5 px-4 font-semibold rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isSubmitting && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                  <span>{isSubmitting ? t.auth.loggingIn : t.auth.loginBtn}</span>
                </button>
              </form>
            ) : (
              // Register Form
              <form onSubmit={handleRegister} className="space-y-3.5 text-xs">
                <div>
                  <label className="block text-slate-400 mb-1">{t.auth.username} *</label>
                  <input
                    type="text"
                    required
                    value={regForm.username}
                    onChange={(e) => setRegForm({ ...regForm, username: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800/80 text-slate-100 outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">{t.auth.email}</label>
                  <input
                    type="email"
                    value={regForm.email}
                    onChange={(e) => setRegForm({ ...regForm, email: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800/80 text-slate-100 outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">{t.auth.password} *</label>
                  <input
                    type="password"
                    required
                    value={regForm.password}
                    onChange={(e) => setRegForm({ ...regForm, password: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800/80 text-slate-100 outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">{t.auth.confirmPassword} *</label>
                  <input
                    type="password"
                    required
                    value={regForm.confirmPassword}
                    onChange={(e) => setRegForm({ ...regForm, confirmPassword: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800/80 text-slate-100 outline-none focus:border-cyan-500"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full mt-2 py-2.5 px-4 font-semibold rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isSubmitting && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                  <span>{t.auth.registerBtn}</span>
                </button>
              </form>
            )}

            <div className="mt-5 pt-4 border-t border-slate-800 text-center text-xs text-slate-400">
              {!isRegisterMode ? (
                <div>
                  <span>{t.auth.noAccount} </span>
                  <button
                    onClick={() => { setIsRegisterMode(true); setLoginError(''); }}
                    className="text-cyan-400 hover:underline cursor-pointer"
                  >
                    {t.auth.registerLink}
                  </button>
                </div>
              ) : (
                <div>
                  <span>{t.auth.alreadyHaveAccount} </span>
                  <button
                    onClick={() => { setIsRegisterMode(false); setLoginError(''); }}
                    className="text-cyan-400 hover:underline cursor-pointer"
                  >
                    {t.auth.loginLink}
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="mt-6 flex items-center justify-center gap-4 text-xs text-slate-500">
            <button
              onClick={() => setLang(lang === 'fa' ? 'en' : 'fa')}
              className="flex items-center gap-1 hover:text-slate-300 cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{lang === 'fa' ? 'English (LTR)' : 'فارسی (RTL)'}</span>
            </button>
            <span>·</span>
            <span>{t.version}</span>
          </div>
        </div>
      </div>
    );
  }

  // --- 3. Authenticated Layout with Professional Sidebar ---
  return (
    <div className={`min-h-screen flex ${theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      {/* Sidebar (Desktop) */}
      <aside className={`w-64 border-e hidden md:flex flex-col shrink-0 sticky top-0 h-screen ${
        theme === 'dark' ? 'bg-slate-950 border-slate-800/80' : 'bg-white border-slate-200'
      }`}>
        {/* Brand Header */}
        <div className="h-14 border-b border-slate-800/80 px-4 flex items-center justify-between">
          <RavanLogo size={28} accentColor={accent} />
          <span className="text-[10px] font-mono text-slate-500 tabular-nums">{t.version}</span>
        </div>

        {/* Navigation Tree */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1.5 text-xs">
          {/* Dashboard */}
          <button
            onClick={() => setNav('dashboard')}
            className={`w-full px-3 py-2 rounded-lg font-medium flex items-center gap-2.5 transition-colors cursor-pointer ${
              nav === 'dashboard'
                ? 'bg-cyan-500/10 text-cyan-400 font-semibold border border-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 shrink-0" />
            <span>{t.nav.dashboard}</span>
          </button>

          {/* Users Group */}
          <div>
            <button
              onClick={() => toggleMenu('users')}
              className="w-full px-3 py-2 rounded-lg text-slate-300 font-medium flex items-center justify-between hover:bg-slate-900/60 cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <UsersIcon className="w-4 h-4 text-slate-400 shrink-0" />
                <span>{t.nav.users}</span>
              </div>
              {expandedMenus.users ? <ChevronDown className="w-3.5 h-3.5 text-slate-500" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-500" />}
            </button>
            {expandedMenus.users && (
              <div className="ms-6 mt-1 space-y-1 border-s border-slate-800 ps-2">
                <button
                  onClick={() => setNav('config-users')}
                  className={`w-full px-2.5 py-1.5 rounded-md text-start transition-colors flex items-center gap-2 cursor-pointer ${
                    nav === 'config-users' ? 'text-cyan-400 font-semibold bg-cyan-500/10' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>{t.nav.configUsers}</span>
                </button>
                <button
                  onClick={() => setNav('panel-users')}
                  className={`w-full px-2.5 py-1.5 rounded-md text-start transition-colors flex items-center gap-2 cursor-pointer ${
                    nav === 'panel-users' ? 'text-cyan-400 font-semibold bg-cyan-500/10' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <UserCog className="w-3.5 h-3.5" />
                  <span>{t.nav.panelUsers}</span>
                </button>
              </div>
            )}
          </div>

          {/* Subscriptions */}
          <button
            onClick={() => setNav('subscriptions')}
            className={`w-full px-3 py-2 rounded-lg font-medium flex items-center gap-2.5 transition-colors cursor-pointer ${
              nav === 'subscriptions'
                ? 'bg-cyan-500/10 text-cyan-400 font-semibold border border-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <QrCode className="w-4 h-4 shrink-0" />
            <span>{t.nav.subscriptions}</span>
          </button>

          {/* Nodes */}
          <button
            onClick={() => setNav('nodes')}
            className={`w-full px-3 py-2 rounded-lg font-medium flex items-center gap-2.5 transition-colors cursor-pointer ${
              nav === 'nodes'
                ? 'bg-cyan-500/10 text-cyan-400 font-semibold border border-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Server className="w-4 h-4 shrink-0" />
            <span>{t.nav.nodes}</span>
          </button>

          {/* Blocklist */}
          <button
            onClick={() => setNav('blocklist')}
            className={`w-full px-3 py-2 rounded-lg font-medium flex items-center gap-2.5 transition-colors cursor-pointer ${
              nav === 'blocklist'
                ? 'bg-cyan-500/10 text-cyan-400 font-semibold border border-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <ShieldAlert className="w-4 h-4 shrink-0" />
            <span>{t.nav.blocklist}</span>
          </button>

          {/* Telegram Bot */}
          <button
            onClick={() => setNav('telegram')}
            className={`w-full px-3 py-2 rounded-lg font-medium flex items-center gap-2.5 transition-colors cursor-pointer ${
              nav === 'telegram'
                ? 'bg-cyan-500/10 text-cyan-400 font-semibold border border-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Send className="w-4 h-4 shrink-0" />
            <span>{t.nav.bots}</span>
          </button>

          {/* Logs Group */}
          <div>
            <button
              onClick={() => toggleMenu('logs')}
              className="w-full px-3 py-2 rounded-lg text-slate-300 font-medium flex items-center justify-between hover:bg-slate-900/60 cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <FileText className="w-4 h-4 text-slate-400 shrink-0" />
                <span>{t.nav.logs}</span>
              </div>
              {expandedMenus.logs ? <ChevronDown className="w-3.5 h-3.5 text-slate-500" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-500" />}
            </button>
            {expandedMenus.logs && (
              <div className="ms-6 mt-1 space-y-1 border-s border-slate-800 ps-2">
                <button
                  onClick={() => setNav('api-logs')}
                  className={`w-full px-2.5 py-1.5 rounded-md text-start transition-colors flex items-center gap-2 cursor-pointer ${
                    nav === 'api-logs' ? 'text-cyan-400 font-semibold bg-cyan-500/10' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span>{t.nav.apiLogs}</span>
                </button>
                <button
                  onClick={() => setNav('audit')}
                  className={`w-full px-2.5 py-1.5 rounded-md text-start transition-colors flex items-center gap-2 cursor-pointer ${
                    nav === 'audit' ? 'text-cyan-400 font-semibold bg-cyan-500/10' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span>{t.nav.auditLogs}</span>
                </button>
              </div>
            )}
          </div>

          {/* Backups */}
          <button
            onClick={() => setNav('backups')}
            className={`w-full px-3 py-2 rounded-lg font-medium flex items-center gap-2.5 transition-colors cursor-pointer ${
              nav === 'backups'
                ? 'bg-cyan-500/10 text-cyan-400 font-semibold border border-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Database className="w-4 h-4 shrink-0" />
            <span>{t.nav.backup}</span>
          </button>

          {/* Health Diagnostics */}
          <button
            onClick={() => setNav('health')}
            className={`w-full px-3 py-2 rounded-lg font-medium flex items-center gap-2.5 transition-colors cursor-pointer ${
              nav === 'health'
                ? 'bg-cyan-500/10 text-cyan-400 font-semibold border border-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Activity className="w-4 h-4 shrink-0" />
            <span>{t.nav.nodeHealth}</span>
          </button>

          {/* Settings Group */}
          <div>
            <button
              onClick={() => toggleMenu('settings')}
              className="w-full px-3 py-2 rounded-lg text-slate-300 font-medium flex items-center justify-between hover:bg-slate-900/60 cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <Sliders className="w-4 h-4 text-slate-400 shrink-0" />
                <span>{t.nav.settings}</span>
              </div>
              {expandedMenus.settings ? <ChevronDown className="w-3.5 h-3.5 text-slate-500" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-500" />}
            </button>
            {expandedMenus.settings && (
              <div className="ms-6 mt-1 space-y-1 border-s border-slate-800 ps-2">
                <button
                  onClick={() => setNav('api-keys')}
                  className={`w-full px-2.5 py-1.5 rounded-md text-start transition-colors flex items-center gap-2 cursor-pointer ${
                    nav === 'api-keys' ? 'text-cyan-400 font-semibold bg-cyan-500/10' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Key className="w-3.5 h-3.5" />
                  <span>{t.nav.settingsApi}</span>
                </button>
                <button
                  onClick={() => setNav('settings')}
                  className={`w-full px-2.5 py-1.5 rounded-md text-start transition-colors flex items-center gap-2 cursor-pointer ${
                    nav === 'settings' ? 'text-cyan-400 font-semibold bg-cyan-500/10' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span>{t.nav.settingsAppearance}</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* User Footer Profile */}
        <div className="p-3 border-t border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2 truncate">
            <div className="w-7 h-7 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 font-bold text-xs">
              {user.username.charAt(0).toUpperCase()}
            </div>
            <div className="truncate text-start">
              <div className="text-xs font-semibold text-slate-200 truncate">{user.username}</div>
              <div className="text-[10px] text-slate-500 font-mono">{user.role}</div>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer"
            title={t.nav.logout}
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <header className={`h-14 border-b flex items-center justify-between px-4 sm:px-6 sticky top-0 z-30 ${
          theme === 'dark' ? 'bg-slate-950/80 backdrop-blur-md border-slate-800/80' : 'bg-white/90 backdrop-blur-md border-slate-200'
        }`}>
          {/* Mobile menu trigger */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-1.5 rounded-lg text-slate-400 hover:bg-slate-800"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <h1 className="text-sm font-semibold capitalize text-slate-200">
              {nav.replace('-', ' ')}
            </h1>
          </div>

          {/* Quick Actions (Download Release, Language, Theme) */}
          <div className="flex items-center gap-2">
            <a
              href="/api/v1/release/download"
              download="RavanPanel-v0.1.0.zip"
              className="px-2.5 py-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 text-xs font-medium flex items-center gap-1.5 transition-colors"
              title={lang === 'fa' ? 'دانلود سورس و بسته RavanPanel v0.1.0 (ZIP)' : 'Download RavanPanel v0.1.0 Release (ZIP)'}
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{lang === 'fa' ? 'دانلود بسته v0.1.0' : 'Download v0.1.0'}</span>
            </a>

            <button
              onClick={() => setLang(lang === 'fa' ? 'en' : 'fa')}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 text-xs flex items-center gap-1 cursor-pointer"
              title="Language"
            >
              <Globe className="w-4 h-4" />
              <span className="uppercase text-[10px] font-mono">{lang}</span>
            </button>

            <button
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors cursor-pointer"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </header>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden border-b border-slate-800 bg-slate-900 p-4 space-y-2 text-xs">
            {[
              { id: 'dashboard', label: t.nav.dashboard },
              { id: 'config-users', label: t.nav.configUsers },
              { id: 'panel-users', label: t.nav.panelUsers },
              { id: 'subscriptions', label: t.nav.subscriptions },
              { id: 'nodes', label: t.nav.nodes },
              { id: 'api-keys', label: t.nav.settingsApi },
              { id: 'api-logs', label: t.nav.apiLogs },
              { id: 'backups', label: t.nav.backup },
              { id: 'health', label: t.nav.nodeHealth },
              { id: 'settings', label: t.nav.settings },
            ].map(m => (
              <button
                key={m.id}
                onClick={() => { setNav(m.id); setMobileMenuOpen(false); }}
                className={`w-full py-2 px-3 text-start rounded-md ${
                  nav === m.id ? 'bg-cyan-500/10 text-cyan-400 font-semibold' : 'text-slate-400'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        )}

        {/* Toast Notification */}
        {notification && (
          <div className={`fixed bottom-4 start-4 end-4 sm:start-auto sm:end-4 z-50 px-4 py-2.5 rounded-lg shadow-xl border text-xs flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2 ${
            notification.type === 'success'
              ? 'bg-emerald-950 border-emerald-800 text-emerald-300'
              : 'bg-rose-950 border-rose-800 text-rose-300'
          }`}>
            {notification.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertTriangle className="w-4 h-4 shrink-0" />}
            <span>{notification.message}</span>
          </div>
        )}

        {/* Router View Container */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
          {nav === 'dashboard' && <DashboardView t={t} theme={theme} accent={accent} onNavigate={setNav} showNotification={showNotification} />}
          {nav === 'config-users' && <ConfigUsersView t={t} theme={theme} accent={accent} showNotification={showNotification} />}
          {nav === 'panel-users' && <PanelUsersView t={t} theme={theme} accent={accent} currentUser={user} showNotification={showNotification} />}
          {nav === 'subscriptions' && <SubscriptionsView t={t} theme={theme} accent={accent} showNotification={showNotification} />}
          {nav === 'api-keys' && <ApiKeysView t={t} theme={theme} accent={accent} showNotification={showNotification} />}
          {nav === 'api-logs' && <ApiLogsView t={t} theme={theme} />}
          {nav === 'nodes' && <NodesView t={t} theme={theme} accent={accent} showNotification={showNotification} />}
          {nav === 'blocklist' && <BlocklistView t={t} theme={theme} accent={accent} showNotification={showNotification} />}
          {nav === 'telegram' && <TelegramView t={t} theme={theme} accent={accent} showNotification={showNotification} />}
          {nav === 'backups' && <BackupsView t={t} theme={theme} accent={accent} showNotification={showNotification} />}
          {nav === 'audit' && <AuditView t={t} theme={theme} />}
          {nav === 'health' && <HealthView t={t} theme={theme} accent={accent} />}
          {nav === 'settings' && <SettingsView t={t} theme={theme} accent={accent} onUpdateAccent={setAccent} showNotification={showNotification} />}
        </main>
      </div>
    </div>
  );
}

// ----------------------------------------------------
// 1. Dashboard View
// ----------------------------------------------------
function DashboardView({
  t,
  theme,
  accent,
  onNavigate,
  showNotification,
}: {
  t: any;
  theme: string;
  accent: string;
  onNavigate: (n: string) => void;
  showNotification: (type: 'success' | 'error', msg: string) => void;
}) {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  const loadData = () => {
    setLoading(true);
    api.getDashboard()
      .then((res) => {
        setData(res);
        setLoading(false);
      })
      .catch((err) => {
        showNotification('error', err.message);
        setLoading(false);
      });
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 15000);
    return () => clearInterval(interval);
  }, []);

  const cardClass = theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight">{t.dashboard.title}</h1>
          <p className="text-xs text-slate-400 mt-0.5">{t.dashboard.subtitle}</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('config-users')}
            className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{t.dashboard.addConfigUser}</span>
          </button>
          <button
            onClick={() => onNavigate('api-keys')}
            className="px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-700 hover:bg-slate-800 text-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Key className="w-3.5 h-3.5" />
            <span>{t.dashboard.viewApiKeys}</span>
          </button>
        </div>
      </div>

      {/* 4 Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Panel Admins */}
        <div className={`p-4 rounded-xl border ${cardClass}`}>
          <div className="text-xs text-slate-400 flex items-center justify-between">
            <span>{t.dashboard.totalPanelUsers}</span>
            <UserCog className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="mt-2 text-2xl font-bold tabular-nums text-slate-100">
            {data?.total_panel_users ?? 1}
          </div>
          <div className="mt-2 text-[11px] text-slate-500">
            Administrative staff accounts
          </div>
        </div>

        {/* Config Users */}
        <div className={`p-4 rounded-xl border ${cardClass}`}>
          <div className="text-xs text-slate-400 flex items-center justify-between">
            <span>{t.dashboard.totalConfigUsers}</span>
            <UserCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 text-2xl font-bold tabular-nums text-slate-100">
            {data?.total_config_users ?? 0}
          </div>
          <div className="mt-2 flex items-center gap-2 text-[11px] text-slate-400">
            <span className="text-emerald-400 font-medium tabular-nums">{data?.active_users ?? 0} {t.dashboard.activeUsers}</span>
            <span>·</span>
            <span className="text-rose-400 font-medium tabular-nums">{data?.expired_users ?? 0} {t.dashboard.expiredUsers}</span>
          </div>
        </div>

        {/* Total Traffic */}
        <div className={`p-4 rounded-xl border ${cardClass}`}>
          <div className="text-xs text-slate-400 flex items-center justify-between">
            <span>{t.dashboard.totalTraffic}</span>
            <HardDrive className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-2 text-2xl font-bold tabular-nums text-slate-100">
            {formatBytes(data?.total_traffic ?? 0)}
          </div>
          <div className="mt-2 flex items-center gap-2 text-[11px] text-slate-400">
            <span className="text-cyan-400 tabular-nums">↑ {formatBytes(data?.total_upload ?? 0)}</span>
            <span>·</span>
            <span className="text-emerald-400 tabular-nums">↓ {formatBytes(data?.total_download ?? 0)}</span>
          </div>
        </div>

        {/* Nodes & Core */}
        <div className={`p-4 rounded-xl border ${cardClass}`}>
          <div className="text-xs text-slate-400 flex items-center justify-between">
            <span>{t.dashboard.activeNodes}</span>
            <Server className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="mt-2 text-2xl font-bold tabular-nums text-slate-100">
            {data?.nodes_count ?? 1}
          </div>
          <div className="mt-2 flex items-center gap-2 text-[11px] text-slate-400">
            <span className="text-emerald-400 font-medium">Core: {data?.xray_status}</span>
            <span>·</span>
            <span className="text-cyan-400">DB: {data?.database_status}</span>
          </div>
        </div>
      </div>

      {/* Resource Gauge */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4">
        <div className={`p-4 rounded-xl border ${cardClass}`}>
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span className="flex items-center gap-1.5"><Cpu className="w-3.5 h-3.5 text-cyan-400" /> {t.dashboard.cpuUsage}</span>
            <span className="font-mono tabular-nums font-semibold text-cyan-400">{data?.cpu_usage}%</span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
            <div className="bg-cyan-500 h-1.5 rounded-full" style={{ width: `${Math.min(100, (data?.cpu_usage || 0) * 15)}%` }} />
          </div>
        </div>

        <div className={`p-4 rounded-xl border ${cardClass}`}>
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span className="flex items-center gap-1.5"><Layers className="w-3.5 h-3.5 text-emerald-400" /> {t.dashboard.ramUsage}</span>
            <span className="font-mono tabular-nums font-semibold text-emerald-400">{data?.ram_usage}%</span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
            <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: `${Math.min(100, data?.ram_usage || 28)}%` }} />
          </div>
        </div>

        <div className={`p-4 rounded-xl border ${cardClass}`}>
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span className="flex items-center gap-1.5"><HardDrive className="w-3.5 h-3.5 text-amber-400" /> {t.dashboard.diskUsage}</span>
            <span className="font-mono tabular-nums font-semibold text-amber-400">{data?.disk_usage}%</span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
            <div className="bg-amber-500 h-1.5 rounded-full" style={{ width: `${Math.min(100, data?.disk_usage || 12)}%` }} />
          </div>
        </div>
      </div>

      {/* Traffic History Visualization */}
      <div className={`p-5 rounded-xl border ${cardClass}`}>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-semibold">{t.dashboard.trafficHistory}</h2>
          <div className="flex items-center gap-3 text-xs text-slate-400">
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-cyan-500" /> {t.dashboard.totalUpload}</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-emerald-500" /> {t.dashboard.totalDownload}</span>
          </div>
        </div>

        <div className="grid grid-cols-6 gap-2 sm:gap-4 pt-4 border-t border-slate-800/60">
          {(data?.traffic_history || []).map((h, i) => {
            const maxVal = Math.max(...(data?.traffic_history.map(x => x.upload + x.download) || [1000]));
            const upHeight = Math.max(12, Math.round((h.upload / (maxVal || 1)) * 120));
            const downHeight = Math.max(12, Math.round((h.download / (maxVal || 1)) * 120));

            return (
              <div key={i} className="flex flex-col items-center gap-2">
                <div className="h-32 w-full flex items-end justify-center gap-1">
                  <div className="w-1/2 max-w-4 bg-cyan-500 rounded-t-sm" style={{ height: `${upHeight}px` }} />
                  <div className="w-1/2 max-w-4 bg-emerald-500 rounded-t-sm" style={{ height: `${downHeight}px` }} />
                </div>
                <span className="text-[11px] text-slate-400 truncate text-center">{h.date}</span>
                <span className="text-[10px] font-mono tabular-nums text-slate-500">{formatBytes(h.upload + h.download)}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ----------------------------------------------------
// 2. Config Users View (Client Accounts)
// ----------------------------------------------------
function ConfigUsersView({
  t,
  theme,
  accent,
  showNotification,
}: {
  t: any;
  theme: string;
  accent: string;
  showNotification: (type: 'success' | 'error', msg: string) => void;
}) {
  const [users, setUsers] = useState<ConfigUser[]>([]);
  const [pagination, setPagination] = useState({ page: 1, limit: 20, total: 0, pages: 1 });
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [loading, setLoading] = useState(true);

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<ConfigUser | null>(null);
  const [testTrafficUser, setTestTrafficUser] = useState<ConfigUser | null>(null);
  const [qrModal, setQrModal] = useState<{ url: string; qr: string } | null>(null);

  const [createForm, setCreateForm] = useState({
    username: '',
    traffic_quota_gb: 50,
    device_limit: 2,
    user_group: 'Default',
    notes: '',
    expiry_days: 30,
    protocols: ['vless', 'vmess'],
  });

  const [trafficAddForm, setTrafficAddForm] = useState({ upload_mb: 20, download_mb: 60 });

  const loadUsers = () => {
    setLoading(true);
    api.getConfigUsers({ page: pagination.page, limit: pagination.limit, search, status: statusFilter })
      .then((res) => {
        setUsers(res.config_users);
        setPagination(res.pagination);
        setLoading(false);
      })
      .catch((err) => {
        showNotification('error', err.message);
        setLoading(false);
      });
  };

  useEffect(() => { loadUsers(); }, [pagination.page, statusFilter]);

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const expiresAt = createForm.expiry_days > 0
        ? new Date(Date.now() + createForm.expiry_days * 86400000).toISOString()
        : null;

      await api.createConfigUser({
        username: createForm.username,
        traffic_quota_bytes: createForm.traffic_quota_gb * 1024 * 1024 * 1024,
        device_limit: createForm.device_limit,
        user_group: createForm.user_group,
        notes: createForm.notes,
        expires_at: expiresAt,
        inbound_protocols: createForm.protocols,
      });

      showNotification('success', t.common.success);
      setIsCreateOpen(false);
      setCreateForm({
        username: '',
        traffic_quota_gb: 50,
        device_limit: 2,
        user_group: 'Default',
        notes: '',
        expiry_days: 30,
        protocols: ['vless', 'vmess'],
      });
      loadUsers();
    } catch (err: any) {
      showNotification('error', err.message);
    }
  };

  const handleToggleStatus = async (user: ConfigUser) => {
    const nextStatus = user.status === 'Active' ? 'Disabled' : 'Active';
    try {
      await api.updateConfigUser(user.id, { status: nextStatus });
      showNotification('success', t.common.success);
      loadUsers();
    } catch (err: any) {
      showNotification('error', err.message);
    }
  };

  const handleResetTraffic = async (id: number) => {
    if (!window.confirm(t.users.resetConfirm)) return;
    try {
      await api.resetConfigUserTraffic(id);
      showNotification('success', t.common.success);
      loadUsers();
    } catch (err: any) {
      showNotification('error', err.message);
    }
  };

  const handleAddTraffic = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testTrafficUser) return;
    try {
      await api.addTestTraffic(testTrafficUser.id, trafficAddForm.upload_mb, trafficAddForm.download_mb);
      showNotification('success', t.common.success);
      setTestTrafficUser(null);
      loadUsers();
    } catch (err: any) {
      showNotification('error', err.message);
    }
  };

  const handleOpenQr = async (subId: number) => {
    try {
      const data = await api.getSubscriptionQr(subId);
      setQrModal(data);
    } catch (err: any) {
      showNotification('error', err.message);
    }
  };

  const cardClass = theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight">{t.users.configUsersTitle}</h1>
          <p className="text-xs text-slate-400 mt-0.5">{t.users.configUsersSubtitle}</p>
        </div>
        <button
          onClick={() => setIsCreateOpen(true)}
          className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{t.users.createConfigUser}</span>
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className={`p-3 rounded-xl border flex flex-col md:flex-row items-center justify-between gap-3 ${cardClass}`}>
        <div className="relative w-full md:w-80">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute top-3 start-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && loadUsers()}
            placeholder={t.users.searchPlaceholder}
            className="w-full ps-9 pe-3 py-1.5 text-xs rounded-lg border border-slate-700 bg-slate-800/80 text-slate-100 outline-none"
          />
        </div>

        <div className="flex items-center gap-1 overflow-x-auto w-full md:w-auto p-1 bg-slate-800/40 rounded-lg">
          {['All', 'Active', 'Disabled', 'Expired', 'QuotaExceeded'].map((s) => (
            <button
              key={s}
              onClick={() => { setStatusFilter(s); setPagination(p => ({ ...p, page: 1 })); }}
              className={`px-2.5 py-1 text-xs font-medium rounded-md whitespace-nowrap transition-colors cursor-pointer ${
                statusFilter === s ? 'bg-cyan-500 text-slate-950 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {t.users[`filter${s}`] || s}
            </button>
          ))}
        </div>
      </div>

      {/* Config Users Table */}
      <div className={`rounded-xl border overflow-hidden ${cardClass}`}>
        <div className="overflow-x-auto">
          <table className="w-full text-start text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/40 text-slate-400">
                <th className="py-3 px-4 font-medium text-start">{t.users.username}</th>
                <th className="py-3 px-4 font-medium text-start">{t.users.status}</th>
                <th className="py-3 px-4 font-medium text-start">{t.users.trafficUsed}</th>
                <th className="py-3 px-4 font-medium text-start">{t.users.expiry}</th>
                <th className="py-3 px-4 font-medium text-start">{t.users.group}</th>
                <th className="py-3 px-4 font-medium text-end">{t.users.actions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {users.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    {loading ? t.common.loading : 'No client config users found.'}
                  </td>
                </tr>
              ) : (
                users.map((u) => {
                  const usedGB = (u.traffic_used_bytes / (1024 * 1024 * 1024)).toFixed(2);
                  const quotaGB = u.traffic_quota_bytes > 0
                    ? (u.traffic_quota_bytes / (1024 * 1024 * 1024)).toFixed(0)
                    : t.users.unlimited;

                  const statusColor =
                    u.status === 'Active' ? 'text-emerald-400' :
                    u.status === 'QuotaExceeded' ? 'text-amber-400' : 'text-rose-400';

                  return (
                    <tr key={u.id} className="hover:bg-slate-800/30">
                      <td className="py-3 px-4 font-medium text-slate-200">
                        <div>{u.username}</div>
                        <div className="text-[10px] text-slate-500 font-mono">UUID: {u.uuid.slice(0, 8)}...</div>
                      </td>
                      <td className="py-3 px-4">
                        <button
                          onClick={() => handleToggleStatus(u)}
                          className={`inline-flex items-center gap-1 font-medium cursor-pointer ${statusColor}`}
                        >
                          <span className="w-1.5 h-1.5 rounded-full bg-current" />
                          {u.status}
                        </button>
                      </td>
                      <td className="py-3 px-4 font-mono tabular-nums text-slate-300">
                        <div>{usedGB} / {quotaGB} GB</div>
                        <div className="text-[10px] text-slate-500">
                          ↑ {formatBytes(u.upload_bytes)} · ↓ {formatBytes(u.download_bytes)}
                        </div>
                      </td>
                      <td className="py-3 px-4 tabular-nums text-slate-400">
                        {u.expires_at ? formatDate(u.expires_at) : t.users.never}
                      </td>
                      <td className="py-3 px-4 text-slate-400">
                        {u.user_group}
                      </td>
                      <td className="py-3 px-4 text-end">
                        <div className="flex items-center justify-end gap-1.5">
                          {u.subscription && (
                            <button
                              onClick={() => handleOpenQr(u.subscription!.id)}
                              className="p-1 rounded text-cyan-400 hover:bg-cyan-500/10 cursor-pointer"
                              title="QR Code"
                            >
                              <QrCode className="w-4 h-4" />
                            </button>
                          )}
                          <button
                            onClick={() => setTestTrafficUser(u)}
                            className="p-1 rounded text-amber-400 hover:bg-amber-500/10 cursor-pointer"
                            title={t.users.addTraffic}
                          >
                            <ArrowUpRight className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleResetTraffic(u.id)}
                            className="p-1 rounded text-slate-400 hover:text-cyan-400 hover:bg-slate-800 cursor-pointer"
                            title={t.users.resetTraffic}
                          >
                            <RefreshCw className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingUser(u)}
                            className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 cursor-pointer"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Create Config User */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className={`max-w-md w-full p-6 rounded-xl border ${cardClass}`}>
            <h2 className="text-base font-bold mb-4">{t.users.createConfigUser}</h2>
            <form onSubmit={handleCreateSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">{t.users.username} *</label>
                <input
                  type="text"
                  required
                  placeholder="matin"
                  value={createForm.username}
                  onChange={(e) => setCreateForm({ ...createForm, username: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">{t.users.trafficLimit} (GB)</label>
                  <input
                    type="number"
                    min="0"
                    value={createForm.traffic_quota_gb}
                    onChange={(e) => setCreateForm({ ...createForm, traffic_quota_gb: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">{t.users.expiry} (Days)</label>
                  <input
                    type="number"
                    min="0"
                    value={createForm.expiry_days}
                    onChange={(e) => setCreateForm({ ...createForm, expiry_days: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">{t.users.protocols}</label>
                <div className="flex items-center gap-3">
                  {['vless', 'vmess', 'trojan'].map(p => (
                    <label key={p} className="flex items-center gap-1.5 cursor-pointer uppercase font-mono">
                      <input
                        type="checkbox"
                        checked={createForm.protocols.includes(p)}
                        onChange={(e) => {
                          if (e.target.checked) setCreateForm({ ...createForm, protocols: [...createForm.protocols, p] });
                          else setCreateForm({ ...createForm, protocols: createForm.protocols.filter(x => x !== p) });
                        }}
                      />
                      <span>{p}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800 cursor-pointer"
                >
                  {t.users.cancel}
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold cursor-pointer"
                >
                  {t.common.confirm}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Ingest Test Traffic */}
      {testTrafficUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className={`max-w-md w-full p-6 rounded-xl border ${cardClass}`}>
            <h2 className="text-base font-bold mb-2">{t.users.addTraffic}: {testTrafficUser.username}</h2>
            <form onSubmit={handleAddTraffic} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Upload (MB)</label>
                  <input
                    type="number"
                    min="1"
                    value={trafficAddForm.upload_mb}
                    onChange={(e) => setTrafficAddForm({ ...trafficAddForm, upload_mb: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Download (MB)</label>
                  <input
                    type="number"
                    min="1"
                    value={trafficAddForm.download_mb}
                    onChange={(e) => setTrafficAddForm({ ...trafficAddForm, download_mb: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-100"
                  />
                </div>
              </div>
              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setTestTrafficUser(null)}
                  className="px-3 py-1.5 rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800 cursor-pointer"
                >
                  {t.users.cancel}
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold cursor-pointer"
                >
                  + Add Volume
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* QR Modal */}
      {qrModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className={`max-w-md w-full p-6 rounded-xl border text-center ${cardClass}`}>
            <h2 className="text-base font-bold mb-2">{t.subs.showQr}</h2>
            <div className="bg-white p-4 rounded-xl inline-block mx-auto mb-4 shadow-md">
              <img src={qrModal.qr} alt="Subscription QR" className="w-56 h-56 mx-auto" />
            </div>
            <div className="flex items-center justify-center gap-2 mb-4 text-xs">
              <button
                onClick={() => { navigator.clipboard.writeText(qrModal.url); showNotification('success', t.subs.copied); }}
                className="px-3 py-1.5 rounded-lg border border-slate-700 hover:bg-slate-800 text-slate-200 flex items-center gap-1.5 cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{t.subs.copyUrl}</span>
              </button>
              <a
                href={qrModal.qr}
                download="ravan_subscription_qr.png"
                className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{t.subs.downloadQr}</span>
              </a>
            </div>
            <button onClick={() => setQrModal(null)} className="text-xs text-slate-400 hover:text-slate-200 cursor-pointer">
              {t.common.close}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------
// 3. Panel Users View (Administrative Staff)
// ----------------------------------------------------
function PanelUsersView({
  t,
  theme,
  accent,
  currentUser,
  showNotification,
}: {
  t: any;
  theme: string;
  accent: string;
  currentUser: PanelUser;
  showNotification: (type: 'success' | 'error', msg: string) => void;
}) {
  const [panelUsers, setPanelUsers] = useState<PanelUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [addForm, setAddForm] = useState({ username: '', email: '', password: '', role: 'Operator' });

  const loadPanelUsers = () => {
    setLoading(true);
    api.getPanelUsers()
      .then((res) => {
        setPanelUsers(res.panel_users);
        setLoading(false);
      })
      .catch((err) => {
        showNotification('error', err.message);
        setLoading(false);
      });
  };

  useEffect(() => { loadPanelUsers(); }, []);

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createPanelUser(addForm);
      showNotification('success', t.common.success);
      setIsAddOpen(false);
      setAddForm({ username: '', email: '', password: '', role: 'Operator' });
      loadPanelUsers();
    } catch (err: any) {
      showNotification('error', err.message);
    }
  };

  const handleToggleStatus = async (user: PanelUser) => {
    if (user.role === 'Owner') {
      showNotification('error', 'Cannot disable Owner account.');
      return;
    }
    const nextStatus = user.status === 'Active' ? 'Disabled' : 'Active';
    try {
      await api.updatePanelUser(user.id, { status: nextStatus });
      showNotification('success', t.common.success);
      loadPanelUsers();
    } catch (err: any) {
      showNotification('error', err.message);
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm(t.users.deleteConfirm)) return;
    try {
      await api.deletePanelUser(id);
      showNotification('success', t.common.success);
      loadPanelUsers();
    } catch (err: any) {
      showNotification('error', err.message);
    }
  };

  const cardClass = theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight">{t.users.panelUsersTitle}</h1>
          <p className="text-xs text-slate-400 mt-0.5">{t.users.panelUsersSubtitle}</p>
        </div>
        <button
          onClick={() => setIsAddOpen(true)}
          className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{t.users.createPanelUser}</span>
        </button>
      </div>

      <div className={`rounded-xl border overflow-hidden ${cardClass}`}>
        <table className="w-full text-start text-xs">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/40 text-slate-400">
              <th className="py-3 px-4 font-medium text-start">{t.users.username}</th>
              <th className="py-3 px-4 font-medium text-start">{t.users.role}</th>
              <th className="py-3 px-4 font-medium text-start">{t.users.status}</th>
              <th className="py-3 px-4 font-medium text-start">{t.users.lastLogin}</th>
              <th className="py-3 px-4 font-medium text-start">{t.users.createdAt}</th>
              <th className="py-3 px-4 font-medium text-end">{t.users.actions}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {panelUsers.map((u) => (
              <tr key={u.id} className="hover:bg-slate-800/30">
                <td className="py-3 px-4 font-medium text-slate-200">
                  <div>{u.username}</div>
                  <div className="text-[10px] text-slate-500">{u.email || '—'}</div>
                </td>
                <td className="py-3 px-4">
                  <span className="font-mono text-cyan-400 font-semibold">{u.role}</span>
                </td>
                <td className="py-3 px-4">
                  <button
                    onClick={() => handleToggleStatus(u)}
                    className={`inline-flex items-center gap-1 font-medium cursor-pointer ${
                      u.status === 'Active' ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-current" />
                    {u.status}
                  </button>
                </td>
                <td className="py-3 px-4 text-slate-400 tabular-nums">
                  {formatDate(u.last_login_at)}
                </td>
                <td className="py-3 px-4 text-slate-400 tabular-nums">
                  {formatDate(u.created_at)}
                </td>
                <td className="py-3 px-4 text-end">
                  {u.role !== 'Owner' && (
                    <button
                      onClick={() => handleDelete(u.id)}
                      className="p-1 rounded text-slate-400 hover:text-rose-400 cursor-pointer"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className={`max-w-md w-full p-6 rounded-xl border ${cardClass}`}>
            <h2 className="text-base font-bold mb-4">{t.users.createPanelUser}</h2>
            <form onSubmit={handleAddSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">{t.users.username} *</label>
                <input
                  type="text"
                  required
                  value={addForm.username}
                  onChange={(e) => setAddForm({ ...addForm, username: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-100"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Email</label>
                <input
                  type="email"
                  value={addForm.email}
                  onChange={(e) => setAddForm({ ...addForm, email: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-100"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Password *</label>
                <input
                  type="password"
                  required
                  value={addForm.password}
                  onChange={(e) => setAddForm({ ...addForm, password: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-100"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">{t.users.role}</label>
                <select
                  value={addForm.role}
                  onChange={(e) => setAddForm({ ...addForm, role: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-100"
                >
                  <option value="Admin">Admin</option>
                  <option value="Operator">Operator</option>
                  <option value="Support">Support</option>
                  <option value="ReadOnly">ReadOnly</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800 cursor-pointer"
                >
                  {t.users.cancel}
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold cursor-pointer"
                >
                  {t.common.confirm}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------
// 4. API Keys View (Sections 9, 10, 11)
// ----------------------------------------------------
function ApiKeysView({
  t,
  theme,
  accent,
  showNotification,
}: {
  t: any;
  theme: string;
  accent: string;
  showNotification: (type: 'success' | 'error', msg: string) => void;
}) {
  const [keys, setKeys] = useState<ApiKeyItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [keyName, setKeyName] = useState('');
  const [selectedPerms, setSelectedPerms] = useState<string[]>(['dashboard.read', 'users.read', 'traffic.read']);
  const [createdSecret, setCreatedSecret] = useState<string | null>(null);

  const loadKeys = () => {
    setLoading(true);
    api.getApiKeys()
      .then((res) => {
        setKeys(res.api_keys);
        setLoading(false);
      })
      .catch((err) => {
        showNotification('error', err.message);
        setLoading(false);
      });
  };

  useEffect(() => { loadKeys(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.createApiKey({ name: keyName, permissions: selectedPerms });
      setCreatedSecret(res.secret_key);
      showNotification('success', t.common.success);
      setKeyName('');
      loadKeys();
    } catch (err: any) {
      showNotification('error', err.message);
    }
  };

  const handleRevoke = async (id: number) => {
    try {
      await api.revokeApiKey(id);
      showNotification('success', t.common.success);
      loadKeys();
    } catch (err: any) {
      showNotification('error', err.message);
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await api.deleteApiKey(id);
      showNotification('success', t.common.success);
      loadKeys();
    } catch (err: any) {
      showNotification('error', err.message);
    }
  };

  const cardClass = theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight">{t.apiKeys.title}</h1>
          <p className="text-xs text-slate-400 mt-0.5">{t.apiKeys.subtitle}</p>
        </div>
        <button
          onClick={() => { setIsCreateOpen(true); setCreatedSecret(null); }}
          className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{t.apiKeys.createBtn}</span>
        </button>
      </div>

      <div className={`rounded-xl border overflow-hidden ${cardClass}`}>
        <table className="w-full text-start text-xs">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/40 text-slate-400">
              <th className="py-3 px-4 font-medium text-start">{t.apiKeys.name}</th>
              <th className="py-3 px-4 font-medium text-start">{t.apiKeys.keyPrefix}</th>
              <th className="py-3 px-4 font-medium text-start">{t.apiKeys.permissions}</th>
              <th className="py-3 px-4 font-medium text-start">{t.apiKeys.lastUsed}</th>
              <th className="py-3 px-4 font-medium text-end">{t.apiKeys.actions}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {keys.length === 0 ? (
              <tr>
                <td colSpan={5} className="py-8 text-center text-slate-500">
                  {loading ? t.common.loading : t.apiKeys.noKeys}
                </td>
              </tr>
            ) : (
              keys.map((k) => (
                <tr key={k.id} className="hover:bg-slate-800/30">
                  <td className="py-3 px-4 font-medium text-slate-200">{k.name}</td>
                  <td className="py-3 px-4 font-mono tabular-nums text-cyan-400">{k.masked}</td>
                  <td className="py-3 px-4 text-slate-400 font-mono text-[10px]">
                    {k.permissions.join(', ')}
                  </td>
                  <td className="py-3 px-4 text-slate-400 tabular-nums">
                    {k.last_used_at ? formatDate(k.last_used_at) : 'Never'}
                  </td>
                  <td className="py-3 px-4 text-end">
                    <div className="flex items-center justify-end gap-2">
                      {!k.revoked_at ? (
                        <button
                          onClick={() => handleRevoke(k.id)}
                          className="px-2 py-1 rounded text-amber-400 hover:bg-amber-500/10 cursor-pointer"
                        >
                          {t.apiKeys.revoke}
                        </button>
                      ) : (
                        <span className="text-slate-500 text-[10px]">Revoked</span>
                      )}
                      <button
                        onClick={() => handleDelete(k.id)}
                        className="p-1 rounded text-slate-400 hover:text-rose-400 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Modal: Create API Key */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className={`max-w-md w-full p-6 rounded-xl border ${cardClass}`}>
            <h2 className="text-base font-bold mb-4">{t.apiKeys.createBtn}</h2>

            {createdSecret ? (
              <div className="space-y-4 text-xs">
                <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-300">
                  {t.apiKeys.oneTimeWarning}
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">{t.apiKeys.secretKeyLabel}</label>
                  <div className="p-2.5 rounded-lg bg-slate-950 font-mono text-cyan-400 break-all select-all border border-slate-800">
                    {createdSecret}
                  </div>
                </div>
                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(createdSecret);
                      showNotification('success', t.apiKeys.copied);
                    }}
                    className="px-3.5 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{t.apiKeys.copyKey}</span>
                  </button>
                  <button
                    onClick={() => setIsCreateOpen(false)}
                    className="px-3 py-1.5 rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800 cursor-pointer"
                  >
                    {t.common.close}
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleCreate} className="space-y-3.5 text-xs">
                <div>
                  <label className="block text-slate-400 mb-1">{t.apiKeys.name} *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Monitoring Bot Key"
                    value={keyName}
                    onChange={(e) => setKeyName(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-2">{t.apiKeys.permissions}</label>
                  <div className="space-y-2">
                    {[
                      { id: 'dashboard.read', label: 'Read Dashboard' },
                      { id: 'users.read', label: 'Read Users' },
                      { id: 'users.manage', label: 'Manage Users' },
                      { id: 'traffic.read', label: 'Read Traffic' },
                      { id: 'nodes.manage', label: 'Manage Nodes' },
                      { id: 'subscriptions.manage', label: 'Manage Subscriptions' },
                      { id: 'logs.read', label: 'Read Logs' },
                    ].map(p => (
                      <label key={p.id} className="flex items-center gap-2 cursor-pointer text-slate-300">
                        <input
                          type="checkbox"
                          checked={selectedPerms.includes(p.id)}
                          onChange={(e) => {
                            if (e.target.checked) setSelectedPerms([...selectedPerms, p.id]);
                            else setSelectedPerms(selectedPerms.filter(x => x !== p.id));
                          }}
                        />
                        <span>{p.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-3">
                  <button
                    type="button"
                    onClick={() => setIsCreateOpen(false)}
                    className="px-3 py-1.5 rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800 cursor-pointer"
                  >
                    {t.users.cancel}
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold cursor-pointer"
                  >
                    {t.common.confirm}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------
// 5. API Logs View (Section 12)
// ----------------------------------------------------
function ApiLogsView({
  t,
  theme,
}: {
  t: any;
  theme: string;
}) {
  const [logs, setLogs] = useState<ApiLogItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getApiLogs(1, 40)
      .then((res) => {
        setLogs(res.api_logs);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const cardClass = theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs';

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold tracking-tight">{t.apiLogs.title}</h1>
        <p className="text-xs text-slate-400 mt-0.5">{t.apiLogs.subtitle}</p>
      </div>

      <div className={`rounded-xl border overflow-hidden ${cardClass}`}>
        <table className="w-full text-start text-xs">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/40 text-slate-400">
              <th className="py-3 px-4 font-medium text-start">{t.apiLogs.method}</th>
              <th className="py-3 px-4 font-medium text-start">{t.apiLogs.endpoint}</th>
              <th className="py-3 px-4 font-medium text-start">{t.apiLogs.status}</th>
              <th className="py-3 px-4 font-medium text-start">{t.apiLogs.user}</th>
              <th className="py-3 px-4 font-medium text-start">{t.apiLogs.ip}</th>
              <th className="py-3 px-4 font-medium text-end">{t.apiLogs.duration}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {logs.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-slate-500">
                  {loading ? t.common.loading : t.apiLogs.noLogs}
                </td>
              </tr>
            ) : (
              logs.map((l) => (
                <tr key={l.id} className="hover:bg-slate-800/30">
                  <td className="py-3 px-4">
                    <span className={`font-mono font-bold text-[10px] px-1.5 py-0.5 rounded ${
                      l.method === 'GET' ? 'bg-cyan-500/10 text-cyan-400' :
                      l.method === 'POST' ? 'bg-emerald-500/10 text-emerald-400' :
                      l.method === 'DELETE' ? 'bg-rose-500/10 text-rose-400' : 'bg-amber-500/10 text-amber-400'
                    }`}>
                      {l.method}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-200">{l.endpoint}</td>
                  <td className="py-3 px-4">
                    <span className={`font-mono tabular-nums font-semibold ${
                      l.status_code < 300 ? 'text-emerald-400' :
                      l.status_code < 400 ? 'text-cyan-400' : 'text-rose-400'
                    }`}>
                      {l.status_code}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-400">
                    {l.panel_username || (l.key_prefix ? `${l.key_prefix}****` : 'Public/Anon')}
                  </td>
                  <td className="py-3 px-4 font-mono tabular-nums text-slate-500">{l.ip_address}</td>
                  <td className="py-3 px-4 text-end font-mono tabular-nums text-slate-400">{l.duration_ms} ms</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ----------------------------------------------------
// 6. Subscriptions View
// ----------------------------------------------------
function SubscriptionsView({
  t,
  theme,
  accent,
  showNotification,
}: {
  t: any;
  theme: string;
  accent: string;
  showNotification: (type: 'success' | 'error', msg: string) => void;
}) {
  const [subs, setSubs] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [qrModal, setQrModal] = useState<{ url: string; qr: string } | null>(null);

  const loadSubs = () => {
    setLoading(true);
    api.getSubscriptions()
      .then((res) => {
        setSubs(res.subscriptions);
        setLoading(false);
      })
      .catch((err) => {
        showNotification('error', err.message);
        setLoading(false);
      });
  };

  useEffect(() => { loadSubs(); }, []);

  const handleOpenQr = async (id: number) => {
    try {
      const data = await api.getSubscriptionQr(id);
      setQrModal(data);
    } catch (err: any) {
      showNotification('error', err.message);
    }
  };

  const handleRevoke = async (id: number) => {
    try {
      await api.revokeSubscription(id);
      showNotification('success', t.common.success);
      loadSubs();
    } catch (err: any) {
      showNotification('error', err.message);
    }
  };

  const cardClass = theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight">{t.subs.title}</h1>
          <p className="text-xs text-slate-400 mt-0.5">{t.subs.subtitle}</p>
        </div>
      </div>

      <div className={`rounded-xl border overflow-hidden ${cardClass}`}>
        <table className="w-full text-start text-xs">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/40 text-slate-400">
              <th className="py-3 px-4 font-medium text-start">{t.subs.user}</th>
              <th className="py-3 px-4 font-medium text-start">{t.subs.token}</th>
              <th className="py-3 px-4 font-medium text-start">{t.subs.status}</th>
              <th className="py-3 px-4 font-medium text-start">{t.subs.created}</th>
              <th className="py-3 px-4 font-medium text-end">{t.subs.actions}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {subs.map((s) => (
              <tr key={s.id} className="hover:bg-slate-800/30">
                <td className="py-3 px-4 font-medium text-slate-200">{s.config_username}</td>
                <td className="py-3 px-4 font-mono text-slate-400">{s.token.slice(0, 16)}...</td>
                <td className="py-3 px-4">
                  <span className={`inline-flex items-center gap-1 font-medium ${s.status === 'Active' ? 'text-emerald-400' : 'text-rose-400'}`}>
                    <span className="w-1.5 h-1.5 rounded-full bg-current" />
                    {s.status}
                  </span>
                </td>
                <td className="py-3 px-4 tabular-nums text-slate-400">{formatDate(s.created_at)}</td>
                <td className="py-3 px-4 text-end">
                  <div className="flex items-center justify-end gap-2">
                    {s.status === 'Active' && (
                      <button
                        onClick={() => handleOpenQr(s.id)}
                        className="px-2.5 py-1 text-xs rounded-md bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 flex items-center gap-1 cursor-pointer"
                      >
                        <QrCode className="w-3.5 h-3.5" />
                        <span>{t.subs.showQr}</span>
                      </button>
                    )}
                    {s.status === 'Active' && (
                      <button
                        onClick={() => handleRevoke(s.id)}
                        className="px-2 py-1 text-xs rounded text-rose-400 hover:bg-rose-500/10 cursor-pointer"
                      >
                        {t.subs.revoke}
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {qrModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className={`max-w-md w-full p-6 rounded-xl border text-center ${cardClass}`}>
            <h2 className="text-base font-bold mb-1">{t.subs.qrModalTitle}</h2>
            <div className="bg-white p-4 rounded-xl inline-block mx-auto my-4 shadow-md">
              <img src={qrModal.qr} alt="Subscription QR" className="w-56 h-56 mx-auto" />
            </div>
            <div className="flex items-center justify-center gap-2 mb-4 text-xs">
              <button
                onClick={() => { navigator.clipboard.writeText(qrModal.url); showNotification('success', t.subs.copied); }}
                className="px-3 py-1.5 rounded-lg border border-slate-700 hover:bg-slate-800 text-slate-200 flex items-center gap-1.5 cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{t.subs.copyUrl}</span>
              </button>
              <a
                href={qrModal.qr}
                download="ravan_qr.png"
                className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{t.subs.downloadQr}</span>
              </a>
            </div>
            <button onClick={() => setQrModal(null)} className="text-xs text-slate-400 hover:text-slate-200 cursor-pointer">
              {t.common.close}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------
// 7. Appearance & Settings View
// ----------------------------------------------------
function SettingsView({
  t,
  theme,
  accent,
  onUpdateAccent,
  showNotification,
}: {
  t: any;
  theme: string;
  accent: string;
  onUpdateAccent: (c: string) => void;
  showNotification: (type: 'success' | 'error', msg: string) => void;
}) {
  const [allowRegistration, setAllowRegistration] = useState(true);

  const colors = [
    { name: 'Cyan', hex: '#06b6d4' },
    { name: 'Emerald', hex: '#10b981' },
    { name: 'Violet', hex: '#8b5cf6' },
    { name: 'Indigo', hex: '#6366f1' },
    { name: 'Amber', hex: '#f59e0b' },
    { name: 'Rose', hex: '#f43f5e' },
  ];

  const handleSave = async () => {
    try {
      await api.updateSettings({
        allow_registration: String(allowRegistration),
        brand_accent: accent,
      });
      showNotification('success', t.settings.savedSuccess);
    } catch (err: any) {
      showNotification('error', err.message);
    }
  };

  const cardClass = theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs';

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-xl font-bold tracking-tight">{t.settings.title}</h1>
        <p className="text-xs text-slate-400 mt-0.5">{t.settings.subtitle}</p>
      </div>

      <div className={`p-5 rounded-xl border space-y-6 ${cardClass}`}>
        <div>
          <h2 className="text-sm font-semibold mb-3">{t.settings.appearance}</h2>
          <label className="block text-xs text-slate-400 mb-2">{t.settings.brandAccent}</label>
          <div className="flex items-center gap-3">
            {colors.map((c) => (
              <button
                key={c.name}
                type="button"
                onClick={() => onUpdateAccent(c.hex)}
                className={`w-8 h-8 rounded-lg flex items-center justify-center transition-transform cursor-pointer ${
                  accent === c.hex ? 'scale-110 ring-2 ring-white/50' : 'hover:scale-105'
                }`}
                style={{ backgroundColor: c.hex }}
                title={c.name}
              />
            ))}
          </div>
        </div>

        <div className="pt-4 border-t border-slate-800">
          <label className="flex items-center gap-2.5 text-xs text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={allowRegistration}
              onChange={(e) => setAllowRegistration(e.target.checked)}
              className="rounded"
            />
            <span>{t.settings.allowRegistration}</span>
          </label>
        </div>

        <div className="pt-2">
          <button
            onClick={handleSave}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer"
          >
            {t.settings.saveSettings}
          </button>
        </div>
      </div>
    </div>
  );
}

// ----------------------------------------------------
// 8. Nodes, Blocklist, Telegram, Backups, Audit, Health Views
// ----------------------------------------------------
function NodesView({ t, theme, accent, showNotification }: any) {
  const [nodes, setNodes] = useState<NodeItem[]>([]);
  useEffect(() => { api.getNodes().then(r => setNodes(r.nodes)).catch(() => {}); }, []);
  const cardClass = theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs';
  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold tracking-tight">{t.nodes.title}</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {nodes.map(n => (
          <div key={n.id} className={`p-4 rounded-xl border ${cardClass}`}>
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-sm font-semibold">{n.name}</h3>
                <div className="text-xs font-mono text-slate-400">{n.address}:{n.port}</div>
              </div>
              <span className="text-xs text-emerald-400 font-medium">● {n.status}</span>
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2 bg-slate-800/40 rounded">CPU: {n.cpu_usage}%</div>
              <div className="p-2 bg-slate-800/40 rounded">RAM: {n.ram_usage}%</div>
              <div className="p-2 bg-slate-800/40 rounded">Disk: {n.disk_usage}%</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function BlocklistView({ t, theme, accent, showNotification }: any) {
  const [rules, setRules] = useState<BlocklistRule[]>([]);
  useEffect(() => { api.getBlocklist().then(r => setRules(r.rules)).catch(() => {}); }, []);
  const cardClass = theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs';
  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold tracking-tight">{t.blocklist.title}</h1>
      <div className={`rounded-xl border overflow-hidden ${cardClass}`}>
        <table className="w-full text-start text-xs">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400">
              <th className="py-2.5 px-4 text-start">{t.blocklist.type}</th>
              <th className="py-2.5 px-4 text-start">{t.blocklist.value}</th>
              <th className="py-2.5 px-4 text-start">{t.blocklist.status}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {rules.map(r => (
              <tr key={r.id}>
                <td className="py-2.5 px-4 font-semibold text-cyan-400">{r.type}</td>
                <td className="py-2.5 px-4 font-mono text-slate-200">{r.value}</td>
                <td className="py-2.5 px-4 text-emerald-400">{r.enabled ? 'Enabled' : 'Disabled'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function TelegramView({ t, theme, accent, showNotification }: any) {
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'bot'; text: string }>>([
    { sender: 'bot', text: '🤖 RavanPanel Telegram Bot Online. Send /status or /users.' }
  ]);
  const [inputCmd, setInputCmd] = useState('/status');
  const cardClass = theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs';

  const handleSend = async () => {
    if (!inputCmd.trim()) return;
    const cmd = inputCmd.trim();
    setMessages(prev => [...prev, { sender: 'user', text: cmd }]);
    setInputCmd('');
    try {
      const res = await api.sendTelegramCommand(cmd);
      setMessages(prev => [...prev, { sender: 'bot', text: res.reply }]);
    } catch (err: any) {
      setMessages(prev => [...prev, { sender: 'bot', text: `Error: ${err.message}` }]);
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold tracking-tight">{t.telegram.title}</h1>
      <div className={`rounded-xl border flex flex-col h-[440px] overflow-hidden ${cardClass}`}>
        <div className="flex-1 p-4 overflow-y-auto space-y-2 font-mono text-xs">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`p-2.5 rounded-lg max-w-[80%] whitespace-pre-wrap ${m.sender === 'user' ? 'bg-cyan-600 text-slate-950 font-medium' : 'bg-slate-800 text-slate-200'}`}>
                {m.text}
              </div>
            </div>
          ))}
        </div>
        <div className="p-3 border-t border-slate-800 flex gap-2">
          <input
            type="text"
            value={inputCmd}
            onChange={(e) => setInputCmd(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="/status"
            className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-slate-700 bg-slate-800 font-mono text-slate-100"
          />
          <button onClick={handleSend} className="px-4 py-1.5 text-xs rounded-lg bg-cyan-500 text-slate-950 font-semibold cursor-pointer">
            Send
          </button>
        </div>
      </div>
    </div>
  );
}

function BackupsView({ t, theme, accent, showNotification }: any) {
  const [backups, setBackups] = useState<BackupItem[]>([]);
  useEffect(() => { api.getBackups().then(r => setBackups(r.backups)).catch(() => {}); }, []);
  const cardClass = theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs';

  const handleCreate = async () => {
    try {
      await api.createBackup();
      showNotification('success', t.common.success);
      api.getBackups().then(r => setBackups(r.backups));
    } catch (err: any) {
      showNotification('error', err.message);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-xl font-bold tracking-tight">{t.backups.title}</h1>
        <button onClick={handleCreate} className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-cyan-500 text-slate-950 cursor-pointer">
          + {t.backups.createBtn}
        </button>
      </div>
      <div className={`rounded-xl border overflow-hidden ${cardClass}`}>
        <table className="w-full text-start text-xs">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400">
              <th className="py-2.5 px-4 text-start">{t.backups.fileName}</th>
              <th className="py-2.5 px-4 text-start">{t.backups.fileSize}</th>
              <th className="py-2.5 px-4 text-start">{t.backups.createdAt}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {backups.map(b => (
              <tr key={b.name}>
                <td className="py-2.5 px-4 font-mono text-slate-200">{b.name}</td>
                <td className="py-2.5 px-4 tabular-nums text-slate-400">{formatBytes(b.size_bytes)}</td>
                <td className="py-2.5 px-4 tabular-nums text-slate-400">{formatDate(b.created_at)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AuditView({ t, theme }: any) {
  const [logs, setLogs] = useState<AuditLogItem[]>([]);
  useEffect(() => { api.getAuditLogs(1, 30).then(r => setLogs(r.logs)).catch(() => {}); }, []);
  const cardClass = theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs';
  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold tracking-tight">{t.audit.title}</h1>
      <div className={`rounded-xl border overflow-hidden ${cardClass}`}>
        <table className="w-full text-start text-xs">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400">
              <th className="py-2.5 px-4 text-start">{t.audit.actor}</th>
              <th className="py-2.5 px-4 text-start">{t.audit.action}</th>
              <th className="py-2.5 px-4 text-start">{t.audit.target}</th>
              <th className="py-2.5 px-4 text-end">{t.audit.timestamp}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {logs.map(l => (
              <tr key={l.id}>
                <td className="py-2.5 px-4 font-semibold text-cyan-400">{l.actor}</td>
                <td className="py-2.5 px-4 text-slate-200">{l.action}</td>
                <td className="py-2.5 px-4 font-mono text-slate-400">{l.target}</td>
                <td className="py-2.5 px-4 text-end tabular-nums text-slate-500">{formatDate(l.created_at)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function HealthView({ t, theme, accent }: any) {
  const [health, setHealth] = useState<any>(null);
  useEffect(() => { api.getHealth().then(setHealth).catch(() => {}); }, []);
  const cardClass = theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs';
  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold tracking-tight">{t.health.title}</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {['database', 'xray', 'disk', 'memory'].map(k => (
          <div key={k} className={`p-4 rounded-xl border flex items-center justify-between ${cardClass}`}>
            <span className="text-xs uppercase font-mono text-slate-400">{k}</span>
            <span className="text-xs text-emerald-400 font-medium">● {health?.checks?.[k] || 'ok'}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
