import React from 'react';

interface RavanLogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
  accentColor?: string;
}

export const RavanLogo: React.FC<RavanLogoProps> = ({
  className = '',
  size = 28,
  showText = true,
  accentColor = 'currentColor',
}) => {
  return (
    <div className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      {/* Custom Geometric Flowing Vector Emblem for RavanPanel */}
      <svg
        width={size}
        height={size}
        viewBox="0 0 36 36"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0"
      >
        <rect width="36" height="36" rx="9" fill="#090E17" stroke="#1E293B" strokeWidth="1.5" />
        {/* Core Node */}
        <circle cx="18" cy="18" r="3.2" fill={accentColor} />
        {/* Upper Flowing Wing */}
        <path
          d="M9 14C12 9 24 9 27 14"
          stroke={accentColor}
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeOpacity="0.85"
        />
        {/* Lower Dynamic Flowing Wing */}
        <path
          d="M7 22C11 27 25 27 29 22"
          stroke={accentColor}
          strokeWidth="2.2"
          strokeLinecap="round"
        />
        {/* Interconnected data pulse */}
        <path
          d="M18 10V14.8M18 21.2V26"
          stroke={accentColor}
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeDasharray="2 2"
        />
      </svg>

      {showText && (
        <span className="font-bold tracking-tight text-base sm:text-lg text-slate-100 flex items-center">
          Ravan<span style={{ color: accentColor }}>Panel</span>
        </span>
      )}
    </div>
  );
};
