# Changelog

All notable changes to the RavanPanel project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [v0.1.0] - 2026-09-30

### Initial P0 Production Release

#### Added
- **Core Architecture**:
  - Clean modular architecture supporting both SQLite (default lightweight for VPS) and PostgreSQL.
  - CoreProvider abstraction with `XrayProvider` implementation.
  - NodeProvider abstraction with `LocalNodeProvider` and extensible multi-node ready interface.
- **Security & Authentication**:
  - Robust password hashing with PBKDF2/Argon2id and cryptographically secure salt.
  - Granular RBAC (`Owner`, `Admin`, `Operator`, `Support`, `ReadOnly`) with fine-grained capability checks.
  - Secure session management with session revocation, rate-limiting, and brute-force protection.
- **User Management**:
  - Full CRUD operations: User creation, editing, disable/enable, traffic reset, quota extension, expiry management.
  - User status machine: `Active`, `Disabled`, `Expired`, `QuotaExceeded`.
  - Comprehensive metadata: UUID, Username, Data Quotas, Device Limits, Notes, Tags, Groups.
- **Traffic Accounting**:
  - Accurate upload, download, and total traffic accounting with persistent state across server restarts.
  - Strict double-counting prevention with idempotent counter delta ingestion.
  - Periodic aggregation: Today, Yesterday, This Week, This Month, and Historical logs.
- **Subscription & QR**:
  - Cryptographically secure, unguessable subscription tokens with revocation and regeneration.
  - Dynamic QR code generation for subscription URLs with canvas download and clipboard copy.
- **Telegram Bot**:
  - Full command set: `/start`, `/help`, `/status`, `/users`, `/user <username>`, `/traffic <username>`, `/disable <username>`, `/enable <username>`.
  - Permission and authorization enforcement per command.
- **Rubika Module**:
  - Independent stub interface ready for P2 integration.
- **Blocklist & Rules**:
  - Domain, IP, and CIDR blocklist management (Add, Remove, Toggle, Export, Import).
- **Backup & Safe Restore**:
  - Full JSON/tar archive backups (Database, Configs, Users, Subscriptions, Blocklists, RBAC).
  - Pre-restore validation, pre-flight safety snapshots, rollback on error.
- **Observability & Health**:
  - `/health/live` and `/health/ready` endpoints with system metrics (CPU, RAM, Disk, DB, Core).
  - Comprehensive Audit Logging capturing Actor, Action, Target, IP, and Metadata (secrets sanitized).
- **CLI & DevOps**:
  - `ravanctl` command-line tool with subcommands: `install`, `update`, `uninstall`, `status`, `restart`, `logs`, `backup`, `restore`, `doctor`, `migrate`.
  - Docker Compose & standalone Dockerfile with persistent volumes.
  - Native Linux systemd unit (`ravanpanel.service`) and installer scripts.
- **Frontend Web UI**:
  - React 19 + TypeScript + Vite + Tailwind CSS v4.
  - Dual-language support: Persian (RTL) & English (LTR) with dynamic switching.
  - Dark mode and light mode support with high-density data tables and real charts.
