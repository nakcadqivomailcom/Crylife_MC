-- Migration 003: Distinct Panel Users, Config Users, API Keys, and Inbounds
-- Separates administrative Panel Users from end-user Config Users.

CREATE TABLE IF NOT EXISTS panel_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid VARCHAR(36) UNIQUE NOT NULL,
    username VARCHAR(64) UNIQUE NOT NULL,
    email VARCHAR(128) UNIQUE DEFAULT '',
    password_hash TEXT NOT NULL,
    role VARCHAR(32) NOT NULL DEFAULT 'Admin', -- Owner, Admin, Operator, Support, ReadOnly
    status VARCHAR(32) NOT NULL DEFAULT 'Active', -- Active, Disabled
    permissions TEXT DEFAULT '[]',
    two_factor_enabled BOOLEAN NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_login_at TIMESTAMP NULL
);

CREATE TABLE IF NOT EXISTS config_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid VARCHAR(36) UNIQUE NOT NULL,
    username VARCHAR(64) UNIQUE NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'Active', -- Active, Disabled, Expired, QuotaExceeded
    traffic_quota_bytes BIGINT NOT NULL DEFAULT 0,
    traffic_used_bytes BIGINT NOT NULL DEFAULT 0,
    upload_bytes BIGINT NOT NULL DEFAULT 0,
    download_bytes BIGINT NOT NULL DEFAULT 0,
    device_limit INTEGER NOT NULL DEFAULT 2,
    user_group VARCHAR(64) DEFAULT 'Default',
    notes TEXT DEFAULT '',
    tags TEXT DEFAULT '[]',
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS api_keys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    panel_user_id INTEGER NOT NULL REFERENCES panel_users(id) ON DELETE CASCADE,
    name VARCHAR(64) NOT NULL,
    key_prefix VARCHAR(16) NOT NULL, -- e.g. rpn_7a2b
    key_hash VARCHAR(64) NOT NULL,   -- SHA-256 of full secret
    permissions TEXT NOT NULL DEFAULT '[]',
    last_used_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    revoked_at TIMESTAMP NULL
);

CREATE TABLE IF NOT EXISTS api_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    panel_user_id INTEGER NULL,
    key_prefix VARCHAR(16) DEFAULT '',
    method VARCHAR(10) NOT NULL,
    endpoint VARCHAR(255) NOT NULL,
    status_code INTEGER NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    duration_ms INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS config_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    config_user_id INTEGER NOT NULL REFERENCES config_users(id) ON DELETE CASCADE,
    name VARCHAR(64) NOT NULL,
    protocol VARCHAR(32) NOT NULL DEFAULT 'vless', -- vless, vmess, trojan, reality
    port INTEGER NOT NULL DEFAULT 443,
    settings TEXT DEFAULT '{}',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_panel_users_username ON panel_users(username);
CREATE INDEX IF NOT EXISTS idx_config_users_username ON config_users(username);
CREATE INDEX IF NOT EXISTS idx_api_keys_hash ON api_keys(key_hash);
CREATE INDEX IF NOT EXISTS idx_api_logs_created ON api_logs(created_at);
