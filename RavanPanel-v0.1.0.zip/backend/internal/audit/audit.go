package audit

import (
	"context"
	"encoding/json"
	"regexp"
	"strings"
	"sync"
	"time"

	"github.com/ravanpanel/ravanpanel/backend/internal/domain"
)

var sensitiveKeyRegex = regexp.MustCompile(`(?i)(password|token|secret|key|authorization|bearer)`)

type AuditStore interface {
	InsertAuditLog(ctx context.Context, log *domain.AuditLog) error
	GetAuditLogs(ctx context.Context, limit, offset int) ([]domain.AuditLog, int64, error)
}

type AuditService struct {
	mu    sync.Mutex
	store AuditStore
}

func NewAuditService(store AuditStore) *AuditService {
	return &AuditService{store: store}
}

// Log records an audit entry with strict secret sanitization
func (s *AuditService) Log(ctx context.Context, actor, action, target, ip string, metadata map[string]interface{}) error {
	sanitizedMeta := sanitizeMetadata(metadata)
	metaJSON, _ := json.Marshal(sanitizedMeta)

	logEntry := &domain.AuditLog{
		Actor:     actor,
		Action:    action,
		Target:    target,
		IPAddress: ip,
		Metadata:  string(metaJSON),
		CreatedAt: time.Now(),
	}

	if s.store != nil {
		return s.store.InsertAuditLog(ctx, logEntry)
	}
	return nil
}

func sanitizeMetadata(m map[string]interface{}) map[string]interface{} {
	if m == nil {
		return map[string]interface{}{}
	}
	clean := make(map[string]interface{})
	for k, v := range m {
		if sensitiveKeyRegex.MatchString(k) {
			clean[k] = "[REDACTED]"
			continue
		}
		if str, ok := v.(string); ok && strings.HasPrefix(strings.ToLower(str), "bearer ") {
			clean[k] = "[REDACTED_BEARER_TOKEN]"
			continue
		}
		clean[k] = v
	}
	return clean
}
