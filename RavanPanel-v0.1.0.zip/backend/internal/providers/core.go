package providers

import (
	"context"
)

type CoreStatus string

const (
	CoreStatusRunning CoreStatus = "Running"
	CoreStatusStopped CoreStatus = "Stopped"
	CoreStatusError   CoreStatus = "Error"
)

type CoreStats struct {
	UptimeSeconds   int64 `json:"uptime_seconds"`
	ActiveInbounds  int   `json:"active_inbounds"`
	ActiveOutbounds int   `json:"active_outbounds"`
	TotalUpload     int64 `json:"total_upload"`
	TotalDownload   int64 `json:"total_download"`
}

type CoreConfig struct {
	RawJSON string `json:"raw_json"`
	Version string `json:"version"`
}

type CoreProvider interface {
	Start(ctx context.Context) error
	Stop(ctx context.Context) error
	Restart(ctx context.Context) error
	Status(ctx context.Context) (CoreStatus, error)
	GetStats(ctx context.Context) (CoreStats, error)
	ApplyConfig(ctx context.Context, config CoreConfig) error
	ValidateConfig(ctx context.Context, config CoreConfig) error
}
