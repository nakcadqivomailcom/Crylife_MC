package providers

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"sync"
	"time"
)

type XrayProvider struct {
	mu           sync.RWMutex
	binPath      string
	configPath   string
	version      string
	status       CoreStatus
	startTime    time.Time
	cmd          *exec.Cmd
	stats        CoreStats
}

func NewXrayProvider(binPath, configPath, defaultVersion string) *XrayProvider {
	if defaultVersion == "" {
		defaultVersion = "v1.8.24"
	}
	return &XrayProvider{
		binPath:    binPath,
		configPath: configPath,
		version:    defaultVersion,
		status:     CoreStatusStopped,
	}
}

func (p *XrayProvider) SetVersion(version string) {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.version = version
}

func (p *XrayProvider) GetVersion() string {
	p.mu.RLock()
	defer p.mu.RUnlock()
	return p.version
}

func (p *XrayProvider) ValidateConfig(ctx context.Context, config CoreConfig) error {
	var js map[string]interface{}
	if err := json.Unmarshal([]byte(config.RawJSON), &js); err != nil {
		return fmt.Errorf("invalid Xray JSON syntax: %w", err)
	}

	// Validate required top-level Xray sections
	if _, hasInbounds := js["inbounds"]; !hasInbounds {
		return errors.New("invalid Xray config: missing 'inbounds' array")
	}

	// If binary exists on host, perform native test: xray run -test -c <file>
	if _, err := os.Stat(p.binPath); err == nil {
		tmpFile, err := os.CreateTemp("", "xray-test-*.json")
		if err != nil {
			return err
		}
		defer os.Remove(tmpFile.Name())
		if _, err := tmpFile.WriteString(config.RawJSON); err != nil {
			return err
		}
		tmpFile.Close()

		cmd := exec.CommandContext(ctx, p.binPath, "run", "-test", "-c", tmpFile.Name())
		if out, err := cmd.CombinedOutput(); err != nil {
			return fmt.Errorf("xray core test validation failed: %s (%w)", string(out), err)
		}
	}

	return nil
}

func (p *XrayProvider) Start(ctx context.Context) error {
	p.mu.Lock()
	defer p.mu.Unlock()

	if p.status == CoreStatusRunning {
		return nil
	}

	p.status = CoreStatusRunning
	p.startTime = time.Now()
	p.stats.ActiveInbounds = 1
	p.stats.ActiveOutbounds = 1
	return nil
}

func (p *XrayProvider) Stop(ctx context.Context) error {
	p.mu.Lock()
	defer p.mu.Unlock()

	if p.cmd != nil && p.cmd.Process != nil {
		_ = p.cmd.Process.Kill()
	}
	p.status = CoreStatusStopped
	return nil
}

func (p *XrayProvider) Restart(ctx context.Context) error {
	if err := p.Stop(ctx); err != nil {
		return err
	}
	time.Sleep(50 * time.Millisecond)
	return p.Start(ctx)
}

func (p *XrayProvider) Status(ctx context.Context) (CoreStatus, error) {
	p.mu.RLock()
	defer p.mu.RUnlock()
	return p.status, nil
}

func (p *XrayProvider) GetStats(ctx context.Context) (CoreStats, error) {
	p.mu.RLock()
	defer p.mu.RUnlock()

	res := p.stats
	if p.status == CoreStatusRunning && !p.startTime.IsZero() {
		res.UptimeSeconds = int64(time.Since(p.startTime).Seconds())
	}
	return res, nil
}

func (p *XrayProvider) ApplyConfig(ctx context.Context, config CoreConfig) error {
	if err := p.ValidateConfig(ctx, config); err != nil {
		return err
	}

	p.mu.Lock()
	p.version = config.Version
	p.mu.Unlock()

	return p.Restart(ctx)
}
