package health

import (
	"context"
)

type CheckStatus string

const (
	StatusOk   CheckStatus = "ok"
	StatusFail CheckStatus = "fail"
	StatusWarn CheckStatus = "warn"
)

type HealthResponse struct {
	Status string                 `json:"status"` // "ok" or "degraded"
	Checks map[string]CheckStatus `json:"checks"`
}

type Checker interface {
	CheckDatabase(ctx context.Context) error
	CheckCore(ctx context.Context) error
	CheckDisk(ctx context.Context) error
	CheckMemory(ctx context.Context) error
}

type HealthService struct {
	checker Checker
}

func NewHealthService(checker Checker) *HealthService {
	return &HealthService{checker: checker}
}

func (h *HealthService) CheckLiveness(ctx context.Context) HealthResponse {
	return HealthResponse{
		Status: "ok",
		Checks: map[string]CheckStatus{
			"api": StatusOk,
		},
	}
}

func (h *HealthService) CheckReadiness(ctx context.Context) HealthResponse {
	checks := make(map[string]CheckStatus)
	allOk := true

	if err := h.checker.CheckDatabase(ctx); err != nil {
		checks["database"] = StatusFail
		allOk = false
	} else {
		checks["database"] = StatusOk
	}

	if err := h.checker.CheckCore(ctx); err != nil {
		checks["xray"] = StatusWarn
	} else {
		checks["xray"] = StatusOk
	}

	if err := h.checker.CheckDisk(ctx); err != nil {
		checks["disk"] = StatusFail
		allOk = false
	} else {
		checks["disk"] = StatusOk
	}

	if err := h.checker.CheckMemory(ctx); err != nil {
		checks["memory"] = StatusFail
		allOk = false
	} else {
		checks["memory"] = StatusOk
	}

	status := "ok"
	if !allOk {
		status = "degraded"
	}

	return HealthResponse{
		Status: status,
		Checks: checks,
	}
}
