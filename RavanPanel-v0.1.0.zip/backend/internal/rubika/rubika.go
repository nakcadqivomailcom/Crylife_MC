package rubika

import (
	"context"
	"errors"
)

var (
	ErrNotConfigured = errors.New("rubika messaging module is planned for P2 release and is currently unconfigured")
)

type BotMessage struct {
	ChatID  string `json:"chat_id"`
	Content string `json:"content"`
}

type RubikaService interface {
	SendMessage(ctx context.Context, msg BotMessage) error
	IsConfigured() bool
}

// StubModule provides clean architectural isolation without misleading production claims
type StubModule struct {
	token string
}

func NewStubModule(token string) *StubModule {
	return &StubModule{token: token}
}

func (s *StubModule) SendMessage(ctx context.Context, msg BotMessage) error {
	if !s.IsConfigured() {
		return ErrNotConfigured
	}
	return nil
}

func (s *StubModule) IsConfigured() bool {
	return s.token != ""
}
