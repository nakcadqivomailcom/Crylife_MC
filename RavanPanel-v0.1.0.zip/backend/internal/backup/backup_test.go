package backup

import (
	"context"
	"errors"
	"os"
	"testing"
	"time"

	"github.com/ravanpanel/ravanpanel/backend/internal/domain"
)

type MockStateProvider struct {
	panelUsers  []domain.PanelUser
	configUsers []domain.ConfigUser
	subs        []domain.Subscription
	blocklists  []domain.BlocklistRule
	settings    map[string]string
	shouldFail  bool
}

func (m *MockStateProvider) ExportAll(ctx context.Context) (*BackupPayload, error) {
	return &BackupPayload{
		PanelUsers:  m.panelUsers,
		ConfigUsers: m.configUsers,
		Subs:        m.subs,
		Blocklists:  m.blocklists,
		Settings:    m.settings,
	}, nil
}

func (m *MockStateProvider) ImportAll(ctx context.Context, p *BackupPayload) error {
	if m.shouldFail {
		return errors.New("simulated database disk failure during import")
	}
	m.panelUsers = p.PanelUsers
	m.configUsers = p.ConfigUsers
	m.subs = p.Subs
	m.blocklists = p.Blocklists
	m.settings = p.Settings
	return nil
}

func (m *MockStateProvider) HealthCheck(ctx context.Context) (bool, error) {
	return !m.shouldFail, nil
}

func TestBackup_LifecycleValidationAndRollback(t *testing.T) {
	ctx := context.Background()
	tmpDir, err := os.MkdirTemp("", "ravan_backup_test_*")
	if err != nil {
		t.Fatalf("Failed to create temp dir: %v", err)
	}
	defer os.RemoveAll(tmpDir)

	mock := &MockStateProvider{
		panelUsers: []domain.PanelUser{
			{ID: 1, Username: "owner_a", Role: domain.RoleOwner, CreatedAt: time.Now()},
		},
		configUsers: []domain.ConfigUser{
			{ID: 1, Username: "client_user_a", Status: domain.ConfigStatusActive, CreatedAt: time.Now()},
		},
		subs: []domain.Subscription{
			{ID: 1, ConfigUserID: 1, Token: "token_abc_123", Status: "Active"},
		},
		blocklists: []domain.BlocklistRule{
			{ID: 1, Type: "Domain", Value: "malware.example", Enabled: true},
		},
		settings: map[string]string{"theme": "dark"},
	}

	service, err := NewBackupService(tmpDir, mock)
	if err != nil {
		t.Fatalf("NewBackupService failed: %v", err)
	}

	backupPath, manifest, err := service.CreateBackup(ctx, "test_snapshot")
	if err != nil {
		t.Fatalf("CreateBackup failed: %v", err)
	}
	if manifest.PanelUserCount != 1 || manifest.ConfigUserCount != 1 || manifest.Checksum == "" {
		t.Errorf("Invalid manifest: %+v", manifest)
	}

	payload, err := service.ValidateBackup(backupPath)
	if err != nil {
		t.Fatalf("ValidateBackup failed: %v", err)
	}
	if len(payload.PanelUsers) != 1 || payload.PanelUsers[0].Username != "owner_a" {
		t.Errorf("Payload mismatch")
	}

	mock.panelUsers = append(mock.panelUsers, domain.PanelUser{ID: 2, Username: "operator_b", Role: domain.RoleOperator})

	err = service.SafeRestore(ctx, backupPath)
	if err != nil {
		t.Fatalf("SafeRestore failed: %v", err)
	}
	if len(mock.panelUsers) != 1 {
		t.Errorf("Expected 1 panel user after restore, got %d", len(mock.panelUsers))
	}

	mock.shouldFail = true
	err = service.SafeRestore(ctx, backupPath)
	if err == nil {
		t.Fatalf("Expected SafeRestore to fail when import errors occur")
	}

	mock.shouldFail = false
	if len(mock.panelUsers) != 1 {
		t.Errorf("Rollback failed! Expected state to be restored, got %d", len(mock.panelUsers))
	}
}
