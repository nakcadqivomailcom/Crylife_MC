package backup

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/ravanpanel/ravanpanel/backend/internal/domain"
)

var (
	ErrInvalidBackup    = errors.New("invalid backup archive structure or corrupt checksum")
	ErrPreRestoreFailed = errors.New("pre-restore safety checkpoint snapshot failed")
	ErrRestoreFailed    = errors.New("restoration validation error")
)

type BackupManifest struct {
	Version         string    `json:"version"`
	CreatedAt       time.Time `json:"created_at"`
	PanelUserCount  int       `json:"panel_user_count"`
	ConfigUserCount int       `json:"config_user_count"`
	SubCount        int       `json:"sub_count"`
	BlocklistLen    int       `json:"blocklist_len"`
	Checksum        string    `json:"checksum"`
}

type BackupPayload struct {
	Manifest    BackupManifest         `json:"manifest"`
	PanelUsers  []domain.PanelUser     `json:"panel_users"`
	ConfigUsers []domain.ConfigUser    `json:"config_users"`
	Subs        []domain.Subscription  `json:"subscriptions"`
	Blocklists  []domain.BlocklistRule `json:"blocklists"`
	Settings    map[string]string      `json:"settings"`
	XrayConfig  string                 `json:"xray_config"`
}

type StateProvider interface {
	ExportAll(ctx context.Context) (*BackupPayload, error)
	ImportAll(ctx context.Context, payload *BackupPayload) error
	HealthCheck(ctx context.Context) (bool, error)
}

type BackupService struct {
	mu        sync.Mutex
	backupDir string
	provider  StateProvider
}

func NewBackupService(backupDir string, provider StateProvider) (*BackupService, error) {
	if err := os.MkdirAll(backupDir, 0755); err != nil {
		return nil, err
	}
	return &BackupService{
		backupDir: backupDir,
		provider:  provider,
	}, nil
}

func (s *BackupService) CreateBackup(ctx context.Context, namePrefix string) (string, *BackupManifest, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	payload, err := s.provider.ExportAll(ctx)
	if err != nil {
		return "", nil, fmt.Errorf("failed to export system state: %w", err)
	}

	payload.Manifest.Version = "v0.1.0"
	payload.Manifest.CreatedAt = time.Now()
	payload.Manifest.PanelUserCount = len(payload.PanelUsers)
	payload.Manifest.ConfigUserCount = len(payload.ConfigUsers)
	payload.Manifest.SubCount = len(payload.Subs)
	payload.Manifest.BlocklistLen = len(payload.Blocklists)

	dataWithoutChecksum, _ := json.Marshal(struct {
		P []domain.PanelUser     `json:"p"`
		C []domain.ConfigUser    `json:"c"`
		S []domain.Subscription  `json:"s"`
		B []domain.BlocklistRule `json:"b"`
	}{
		P: payload.PanelUsers,
		C: payload.ConfigUsers,
		S: payload.Subs,
		B: payload.Blocklists,
	})
	hash := sha256.Sum256(dataWithoutChecksum)
	payload.Manifest.Checksum = hex.EncodeToString(hash[:])

	if namePrefix == "" {
		namePrefix = "backup"
	}
	fileName := fmt.Sprintf("%s_%s.json", namePrefix, time.Now().Format("20060102_150405"))
	fullPath := filepath.Join(s.backupDir, fileName)

	fileData, err := json.MarshalIndent(payload, "", "  ")
	if err != nil {
		return "", nil, err
	}

	if err := os.WriteFile(fullPath, fileData, 0600); err != nil {
		return "", nil, err
	}

	return fullPath, &payload.Manifest, nil
}

func (s *BackupService) ValidateBackup(filePath string) (*BackupPayload, error) {
	data, err := os.ReadFile(filePath)
	if err != nil {
		return nil, err
	}

	var payload BackupPayload
	if err := json.Unmarshal(data, &payload); err != nil {
		return nil, ErrInvalidBackup
	}

	if payload.Manifest.Version == "" || payload.Manifest.Checksum == "" {
		return nil, ErrInvalidBackup
	}

	dataWithoutChecksum, _ := json.Marshal(struct {
		P []domain.PanelUser     `json:"p"`
		C []domain.ConfigUser    `json:"c"`
		S []domain.Subscription  `json:"s"`
		B []domain.BlocklistRule `json:"b"`
	}{
		P: payload.PanelUsers,
		C: payload.ConfigUsers,
		S: payload.Subs,
		B: payload.Blocklists,
	})
	hash := sha256.Sum256(dataWithoutChecksum)
	computedChecksum := hex.EncodeToString(hash[:])

	if computedChecksum != payload.Manifest.Checksum {
		return nil, fmt.Errorf("%w: checksum mismatch", ErrInvalidBackup)
	}

	return &payload, nil
}

func (s *BackupService) SafeRestore(ctx context.Context, filePath string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	targetPayload, err := s.ValidateBackup(filePath)
	if err != nil {
		return fmt.Errorf("validation failed: %w", err)
	}

	safetyFile, _, err := s.createSafetySnapshotInternal(ctx)
	if err != nil {
		return fmt.Errorf("%w: %v", ErrPreRestoreFailed, err)
	}

	if err := s.provider.ImportAll(ctx, targetPayload); err != nil {
		_ = s.rollbackInternal(ctx, safetyFile)
		return fmt.Errorf("restore error during import, rolled back successfully: %w", err)
	}

	healthy, err := s.provider.HealthCheck(ctx)
	if !healthy || err != nil {
		_ = s.rollbackInternal(ctx, safetyFile)
		return fmt.Errorf("system healthcheck failed after restore, rolled back to pre-restore state: %v", err)
	}

	return nil
}

func (s *BackupService) createSafetySnapshotInternal(ctx context.Context) (string, *BackupManifest, error) {
	payload, err := s.provider.ExportAll(ctx)
	if err != nil {
		return "", nil, err
	}
	payload.Manifest.Version = "v0.1.0"
	payload.Manifest.CreatedAt = time.Now()

	dataWithoutChecksum, _ := json.Marshal(struct {
		P []domain.PanelUser     `json:"p"`
		C []domain.ConfigUser    `json:"c"`
		S []domain.Subscription  `json:"s"`
		B []domain.BlocklistRule `json:"b"`
	}{
		P: payload.PanelUsers,
		C: payload.ConfigUsers,
		S: payload.Subs,
		B: payload.Blocklists,
	})
	hash := sha256.Sum256(dataWithoutChecksum)
	payload.Manifest.Checksum = hex.EncodeToString(hash[:])

	fileName := fmt.Sprintf("pre_restore_safety_%s.json", time.Now().Format("20060102_150405_000"))
	fullPath := filepath.Join(s.backupDir, fileName)

	fileData, err := json.MarshalIndent(payload, "", "  ")
	if err != nil {
		return "", nil, err
	}

	if err := os.WriteFile(fullPath, fileData, 0600); err != nil {
		return "", nil, err
	}

	return fullPath, &payload.Manifest, nil
}

func (s *BackupService) rollbackInternal(ctx context.Context, safetyFilePath string) error {
	payload, err := s.ValidateBackup(safetyFilePath)
	if err != nil {
		return err
	}
	return s.provider.ImportAll(ctx, payload)
}
