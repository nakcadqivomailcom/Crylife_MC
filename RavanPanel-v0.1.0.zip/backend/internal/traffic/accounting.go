package traffic

import (
	"context"
	"fmt"
	"sync"
	"time"

	"github.com/ravanpanel/ravanpanel/backend/internal/domain"
)

type CoreCounter struct {
	UploadBytes   int64
	DownloadBytes int64
}

type TrafficStore interface {
	GetConfigUser(ctx context.Context, userID int64) (*domain.ConfigUser, error)
	UpdateTraffic(ctx context.Context, userID int64, deltaUpload, deltaDownload int64, dateStr string) error
}

type MemoryStore struct {
	mu           sync.RWMutex
	users        map[int64]*domain.ConfigUser
	dailyTraffic map[string]map[int64]*domain.DailyTraffic // dateStr -> userID -> record
}

func NewMemoryStore() *MemoryStore {
	return &MemoryStore{
		users:        make(map[int64]*domain.ConfigUser),
		dailyTraffic: make(map[string]map[int64]*domain.DailyTraffic),
	}
}

func (m *MemoryStore) SetConfigUser(u *domain.ConfigUser) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.users[u.ID] = u
}

func (m *MemoryStore) GetConfigUser(ctx context.Context, userID int64) (*domain.ConfigUser, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	u, ok := m.users[userID]
	if !ok {
		return nil, fmt.Errorf("config user %d not found", userID)
	}
	cp := *u
	return &cp, nil
}

func (m *MemoryStore) UpdateTraffic(ctx context.Context, userID int64, deltaUpload, deltaDownload int64, dateStr string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	u, ok := m.users[userID]
	if !ok {
		return fmt.Errorf("config user %d not found", userID)
	}
	u.UploadBytes += deltaUpload
	u.DownloadBytes += deltaDownload
	u.TrafficUsedBytes += (deltaUpload + deltaDownload)

	if u.TrafficQuotaBytes > 0 && u.TrafficUsedBytes >= u.TrafficQuotaBytes {
		u.Status = domain.ConfigStatusQuotaExceeded
	}

	if _, ok := m.dailyTraffic[dateStr]; !ok {
		m.dailyTraffic[dateStr] = make(map[int64]*domain.DailyTraffic)
	}
	daily, ok := m.dailyTraffic[dateStr][userID]
	if !ok {
		daily = &domain.DailyTraffic{
			ConfigUserID: userID,
			DateStr:      dateStr,
		}
		m.dailyTraffic[dateStr][userID] = daily
	}
	daily.UploadBytes += deltaUpload
	daily.DownloadBytes += deltaDownload
	daily.TotalBytes += (deltaUpload + deltaDownload)
	daily.UpdatedAt = time.Now()

	return nil
}

type AccountingEngine struct {
	mu           sync.Mutex
	store        TrafficStore
	lastReported map[int64]CoreCounter
}

func NewAccountingEngine(store TrafficStore) *AccountingEngine {
	return &AccountingEngine{
		store:        store,
		lastReported: make(map[int64]CoreCounter),
	}
}

func (e *AccountingEngine) IngestCoreStats(ctx context.Context, userID int64, rawUpload, rawDownload int64, dateStr string) error {
	e.mu.Lock()
	defer e.mu.Unlock()

	last, exists := e.lastReported[userID]

	var deltaUpload int64 = 0
	var deltaDownload int64 = 0

	if !exists {
		deltaUpload = rawUpload
		deltaDownload = rawDownload
	} else {
		if rawUpload >= last.UploadBytes {
			deltaUpload = rawUpload - last.UploadBytes
		} else {
			deltaUpload = rawUpload
		}

		if rawDownload >= last.DownloadBytes {
			deltaDownload = rawDownload - last.DownloadBytes
		} else {
			deltaDownload = rawDownload
		}
	}

	e.lastReported[userID] = CoreCounter{
		UploadBytes:   rawUpload,
		DownloadBytes: rawDownload,
	}

	if deltaUpload == 0 && deltaDownload == 0 {
		return nil
	}

	return e.store.UpdateTraffic(ctx, userID, deltaUpload, deltaDownload, dateStr)
}
