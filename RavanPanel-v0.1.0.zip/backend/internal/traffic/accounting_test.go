package traffic

import (
	"context"
	"testing"
	"time"

	"github.com/ravanpanel/ravanpanel/backend/internal/domain"
)

func TestTrafficAccounting_DoubleCountingPreventionAndRestart(t *testing.T) {
	ctx := context.Background()
	store := NewMemoryStore()

	initialUser := &domain.ConfigUser{
		ID:                1,
		UUID:              "test-uuid-001",
		Username:          "traffic_tester",
		Status:            domain.ConfigStatusActive,
		TrafficQuotaBytes: 10 * 1024 * 1024 * 1024, // 10 GB
		TrafficUsedBytes:  0,
		UploadBytes:       0,
		DownloadBytes:     0,
		CreatedAt:         time.Now(),
		UpdatedAt:         time.Now(),
	}
	store.SetConfigUser(initialUser)

	engine1 := NewAccountingEngine(store)
	dateStr := "2026-09-30"

	const uploadX int64 = 50 * 1024 * 1024
	const downloadY int64 = 150 * 1024 * 1024
	const totalExpected int64 = uploadX + downloadY

	err := engine1.IngestCoreStats(ctx, 1, uploadX, downloadY, dateStr)
	if err != nil {
		t.Fatalf("IngestCoreStats failed: %v", err)
	}

	u1, err := store.GetConfigUser(ctx, 1)
	if err != nil {
		t.Fatalf("GetConfigUser failed: %v", err)
	}

	if u1.UploadBytes != uploadX {
		t.Errorf("Expected upload %d, got %d", uploadX, u1.UploadBytes)
	}
	if u1.DownloadBytes != downloadY {
		t.Errorf("Expected download %d, got %d", downloadY, u1.DownloadBytes)
	}
	if u1.TrafficUsedBytes != totalExpected {
		t.Errorf("Expected total %d, got %d", totalExpected, u1.TrafficUsedBytes)
	}

	// Double counting test
	err = engine1.IngestCoreStats(ctx, 1, uploadX, downloadY, dateStr)
	if err != nil {
		t.Fatalf("Second IngestCoreStats failed: %v", err)
	}

	u2, _ := store.GetConfigUser(ctx, 1)
	if u2.TrafficUsedBytes != totalExpected {
		t.Fatalf("DOUBLE COUNTING DETECTED! Expected total %d, got %d", totalExpected, u2.TrafficUsedBytes)
	}

	// Restart
	engineAfterRestart := NewAccountingEngine(store)
	uRestart, _ := store.GetConfigUser(ctx, 1)
	if uRestart.TrafficUsedBytes != totalExpected {
		t.Fatalf("Traffic lost after restart! Expected %d, got %d", totalExpected, uRestart.TrafficUsedBytes)
	}

	const newCoreUpload int64 = 70 * 1024 * 1024
	const newCoreDownload int64 = 200 * 1024 * 1024
	engineAfterRestart.lastReported[1] = CoreCounter{
		UploadBytes:   uploadX,
		DownloadBytes: downloadY,
	}

	err = engineAfterRestart.IngestCoreStats(ctx, 1, newCoreUpload, newCoreDownload, dateStr)
	if err != nil {
		t.Fatalf("Post-restart IngestCoreStats failed: %v", err)
	}

	u3, _ := store.GetConfigUser(ctx, 1)
	expectedNewTotal := newCoreUpload + newCoreDownload
	if u3.TrafficUsedBytes != expectedNewTotal {
		t.Errorf("Expected post-restart total %d, got %d", expectedNewTotal, u3.TrafficUsedBytes)
	}

	// Quota Exceeded Trigger
	userLimited := &domain.ConfigUser{
		ID:                2,
		UUID:              "test-uuid-002",
		Username:          "limited_user",
		Status:            domain.ConfigStatusActive,
		TrafficQuotaBytes: 100 * 1024 * 1024,
		TrafficUsedBytes:  0,
	}
	store.SetConfigUser(userLimited)

	err = engineAfterRestart.IngestCoreStats(ctx, 2, 50*1024*1024, 60*1024*1024, dateStr)
	if err != nil {
		t.Fatalf("Ingest for user 2 failed: %v", err)
	}

	uLimited, _ := store.GetConfigUser(ctx, 2)
	if uLimited.Status != domain.ConfigStatusQuotaExceeded {
		t.Errorf("Expected status %s, got %s", domain.ConfigStatusQuotaExceeded, uLimited.Status)
	}
}
