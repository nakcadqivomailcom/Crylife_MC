package telegram

import (
	"context"
	"fmt"
	"strings"
	"sync"

	"github.com/ravanpanel/ravanpanel/backend/internal/domain"
)

type BotDataProvider interface {
	GetDashboard(ctx context.Context) (*domain.DashboardStats, error)
	GetConfigUsers(ctx context.Context) ([]domain.ConfigUser, error)
	GetConfigUserByUsername(ctx context.Context, username string) (*domain.ConfigUser, error)
	SetConfigUserStatus(ctx context.Context, username string, status domain.ConfigUserStatus) error
}

type TelegramBot struct {
	mu           sync.RWMutex
	token        string
	allowedUsers map[int64]bool
	provider     BotDataProvider
	enabled      bool
}

func NewTelegramBot(token string, adminIDs []int64, provider BotDataProvider) *TelegramBot {
	allowed := make(map[int64]bool)
	for _, id := range adminIDs {
		allowed[id] = true
	}
	return &TelegramBot{
		token:        token,
		allowedUsers: allowed,
		provider:     provider,
		enabled:      token != "",
	}
}

func (b *TelegramBot) IsAuthorized(senderID int64) bool {
	b.mu.RLock()
	defer b.mu.RUnlock()
	if len(b.allowedUsers) == 0 {
		return false
	}
	return b.allowedUsers[senderID]
}

func (b *TelegramBot) HandleCommand(ctx context.Context, senderID int64, text string) string {
	if !b.IsAuthorized(senderID) {
		return "⛔ دسترسی غیرمجاز. شناسه کاربری شما در سیستم ثبت نشده است.\nUnauthorized. Your Telegram ID is not authorized."
	}

	parts := strings.Fields(text)
	if len(parts) == 0 {
		return ""
	}

	cmd := strings.ToLower(parts[0])

	switch cmd {
	case "/start", "/help":
		return "🤖 *RavanPanel Telegram Bot*\n\n" +
			"دستورات موجود:\n" +
			"📊 `/status` - مشاهده وضعیت کلی سرور و نودها\n" +
			"👥 `/users` - فهرست کاربران فعال\n" +
			"🔍 `/user <username>` - مشاهده جزئیات کاربر\n" +
			"📈 `/traffic <username>` - مشاهده ترافیک کاربر\n" +
			"🚫 `/disable <username>` - غیرفعال کردن کاربر\n" +
			"✅ `/enable <username>` - فعال کردن کاربر\n" +
			"❓ `/help` - راهنمای دستورات"

	case "/status":
		stats, err := b.provider.GetDashboard(ctx)
		if err != nil {
			return fmt.Sprintf("⚠️ خطا در دریافت وضعیت: %v", err)
		}
		return fmt.Sprintf("📊 *وضعیت سرور روان‌پنل*\n\n"+
			"👥 کاربران فعال: %d از %d\n"+
			"📈 ترافیک امروز: %.2f GB\n"+
			"🌐 ترافیک کل: %.2f GB\n"+
			"💻 مصرف CPU: %.1f%%\n"+
			"🧠 مصرف RAM: %.1f%%\n"+
			"💾 مصرف دیسک: %.1f%%\n"+
			"⚙️ هسته Xray: %s\n"+
			"🗄️ وضعیت دیتابیس: %s",
			stats.ActiveUsers, stats.TotalConfigUsers,
			float64(stats.TodayTraffic)/(1024*1024*1024),
			float64(stats.TotalTraffic)/(1024*1024*1024),
			stats.CPUUsage, stats.RAMUsage, stats.DiskUsage,
			stats.XrayStatus, stats.DatabaseStatus)

	case "/users":
		users, err := b.provider.GetConfigUsers(ctx)
		if err != nil {
			return fmt.Sprintf("⚠️ خطا در دریافت کاربران: %v", err)
		}
		if len(users) == 0 {
			return "هیچ کاربر سرویسی یافت نشد."
		}
		var sb strings.Builder
		sb.WriteString(fmt.Sprintf("👥 *فهرست کاربران کانفیگ (%d کاربر):*\n\n", len(users)))
		for i, u := range users {
			if i >= 15 {
				sb.WriteString(fmt.Sprintf("... و %d کاربر دیگر", len(users)-15))
				break
			}
			usedGB := float64(u.TrafficUsedBytes) / (1024 * 1024 * 1024)
			quotaGB := float64(u.TrafficQuotaBytes) / (1024 * 1024 * 1024)
			sb.WriteString(fmt.Sprintf("• `%s` | وضعیت: %s | مصرف: %.1f/%.1f GB\n", u.Username, u.Status, usedGB, quotaGB))
		}
		return sb.String()

	case "/user":
		if len(parts) < 2 {
			return "لطفاً نام کاربری را وارد کنید: `/user <username>`"
		}
		username := parts[1]
		u, err := b.provider.GetConfigUserByUsername(ctx, username)
		if err != nil {
			return fmt.Sprintf("کاربر `%s` یافت نشد.", username)
		}
		usedGB := float64(u.TrafficUsedBytes) / (1024 * 1024 * 1024)
		quotaGB := float64(u.TrafficQuotaBytes) / (1024 * 1024 * 1024)
		upGB := float64(u.UploadBytes) / (1024 * 1024 * 1024)
		downGB := float64(u.DownloadBytes) / (1024 * 1024 * 1024)

		return fmt.Sprintf("👤 *اطلاعات کاربر کانفیگ `%s`:*\n\n"+
			"• وضعیت: %s\n"+
			"• سهمیه کل: %.2f GB\n"+
			"• مصرف کل: %.2f GB\n"+
			"• آپلود: %.2f GB\n"+
			"• دانلود: %.2f GB\n"+
			"• گروه: %s\n"+
			"• یادداشت: %s",
			u.Username, u.Status, quotaGB, usedGB, upGB, downGB, u.UserGroup, u.Notes)

	case "/traffic":
		if len(parts) < 2 {
			return "لطفاً نام کاربری را وارد کنید: `/traffic <username>`"
		}
		username := parts[1]
		u, err := b.provider.GetConfigUserByUsername(ctx, username)
		if err != nil {
			return fmt.Sprintf("کاربر `%s` یافت نشد.", username)
		}
		return fmt.Sprintf("📈 *ترافیک کاربر `%s`:*\n\n"+
			"• مصرف کل: %.2f GB\n"+
			"• آپلود: %.2f GB\n"+
			"• دانلود: %.2f GB",
			u.Username,
			float64(u.TrafficUsedBytes)/(1024*1024*1024),
			float64(u.UploadBytes)/(1024*1024*1024),
			float64(u.DownloadBytes)/(1024*1024*1024))

	case "/disable":
		if len(parts) < 2 {
			return "فرمت دستور: `/disable <username>`"
		}
		username := parts[1]
		err := b.provider.SetConfigUserStatus(ctx, username, domain.ConfigStatusDisabled)
		if err != nil {
			return fmt.Sprintf("خطا در غیرفعال‌سازی کاربر: %v", err)
		}
		return fmt.Sprintf("✅ کاربر `%s` با موفقیت غیرفعال شد.", username)

	case "/enable":
		if len(parts) < 2 {
			return "فرمت دستور: `/enable <username>`"
		}
		username := parts[1]
		err := b.provider.SetConfigUserStatus(ctx, username, domain.ConfigStatusActive)
		if err != nil {
			return fmt.Sprintf("خطا در فعال‌سازی کاربر: %v", err)
		}
		return fmt.Sprintf("✅ کاربر `%s` با موفقیت فعال شد.", username)

	default:
		return "دستور نامعتبر است. جهت مشاهده راهنما `/help` را بفرستید."
	}
}
