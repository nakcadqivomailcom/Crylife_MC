package domain

type Permission string

const (
	PermUsersRead          Permission = "users.read"
	PermUsersCreate        Permission = "users.create"
	PermUsersUpdate        Permission = "users.update"
	PermUsersDelete        Permission = "users.delete"
	PermTrafficRead        Permission = "traffic.read"
	PermTrafficReset       Permission = "traffic.reset"
	PermNodesRead          Permission = "nodes.read"
	PermNodesManage        Permission = "nodes.manage"
	PermSubscriptionsRead  Permission = "subscriptions.read"
	PermSubscriptionsCreate Permission = "subscriptions.create"
	PermSubscriptionsRevoke Permission = "subscriptions.revoke"
	PermSettingsRead       Permission = "settings.read"
	PermSettingsUpdate     Permission = "settings.update"
	PermBackupCreate       Permission = "backup.create"
	PermBackupRestore      Permission = "backup.restore"
	PermAuditRead          Permission = "audit.read"
	PermTelegramManage     Permission = "telegram.manage"
	PermRubikaManage       Permission = "rubika.manage"
	PermXrayRead           Permission = "xray.read"
	PermXrayManage         Permission = "xray.manage"
)

var rolePermissions = map[Role][]Permission{
	RoleOwner: {
		PermUsersRead, PermUsersCreate, PermUsersUpdate, PermUsersDelete,
		PermTrafficRead, PermTrafficReset,
		PermNodesRead, PermNodesManage,
		PermSubscriptionsRead, PermSubscriptionsCreate, PermSubscriptionsRevoke,
		PermSettingsRead, PermSettingsUpdate,
		PermBackupCreate, PermBackupRestore,
		PermAuditRead,
		PermTelegramManage, PermRubikaManage,
		PermXrayRead, PermXrayManage,
	},
	RoleAdmin: {
		PermUsersRead, PermUsersCreate, PermUsersUpdate, PermUsersDelete,
		PermTrafficRead, PermTrafficReset,
		PermNodesRead, PermNodesManage,
		PermSubscriptionsRead, PermSubscriptionsCreate, PermSubscriptionsRevoke,
		PermSettingsRead, PermSettingsUpdate,
		PermBackupCreate,
		PermAuditRead,
		PermTelegramManage,
		PermXrayRead, PermXrayManage,
	},
	RoleOperator: {
		PermUsersRead, PermUsersUpdate,
		PermTrafficRead, PermTrafficReset,
		PermNodesRead,
		PermSubscriptionsRead, PermSubscriptionsCreate,
		PermXrayRead, PermXrayManage,
		PermAuditRead,
	},
	RoleSupport: {
		PermUsersRead,
		PermTrafficRead,
		PermSubscriptionsRead, PermSubscriptionsCreate,
	},
	RoleReadOnly: {
		PermUsersRead,
		PermTrafficRead,
		PermNodesRead,
		PermSubscriptionsRead,
		PermAuditRead,
	},
}

func HasPermission(role Role, perm Permission) bool {
	perms, ok := rolePermissions[role]
	if !ok {
		return false
	}
	for _, p := range perms {
		if p == perm {
			return true
		}
	}
	return false
}

func GetRolePermissions(role Role) []Permission {
	if perms, ok := rolePermissions[role]; ok {
		cp := make([]Permission, len(perms))
		copy(cp, perms)
		return cp
	}
	return []Permission{}
}
