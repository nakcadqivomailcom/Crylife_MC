package domain

import "time"

type Role string

const (
	RoleOwner    Role = "Owner"
	RoleAdmin    Role = "Admin"
	RoleOperator Role = "Operator"
	RoleSupport  Role = "Support"
	RoleReadOnly Role = "ReadOnly"
)

type ConfigUserStatus string

const (
	ConfigStatusActive        ConfigUserStatus = "Active"
	ConfigStatusDisabled      ConfigUserStatus = "Disabled"
	ConfigStatusExpired       ConfigUserStatus = "Expired"
	ConfigStatusQuotaExceeded ConfigUserStatus = "QuotaExceeded"
)

// PanelUser is an administrative operator who logs into the RavanPanel Dashboard
type PanelUser struct {
	ID                int64      `json:"id"`
	UUID              string     `json:"uuid"`
	Username          string     `json:"username"`
	Email             string     `json:"email"`
	PasswordHash      string     `json:"-"`
	Role              Role       `json:"role"`
	Status            string     `json:"status"` // Active, Disabled
	Permissions       []string   `json:"permissions"`
	TwoFactorEnabled  bool       `json:"two_factor_enabled"`
	CreatedAt         time.Time  `json:"created_at"`
	UpdatedAt         time.Time  `json:"updated_at"`
	LastLoginAt       *time.Time `json:"last_login_at"`
}

// ConfigUser is a client receiving network configurations, traffic quota, and subscriptions.
// Config Users CANNOT log into the RavanPanel Dashboard.
type ConfigUser struct {
	ID                 int64            `json:"id"`
	UUID               string           `json:"uuid"`
	Username           string           `json:"username"`
	Status             ConfigUserStatus `json:"status"`
	TrafficQuotaBytes  int64            `json:"traffic_quota_bytes"`
	TrafficUsedBytes   int64            `json:"traffic_used_bytes"`
	UploadBytes        int64            `json:"upload_bytes"`
	DownloadBytes      int64            `json:"download_bytes"`
	DeviceLimit        int              `json:"device_limit"`
	UserGroup          string           `json:"user_group"`
	Notes              string           `json:"notes"`
	Tags               []string         `json:"tags"`
	ExpiresAt          *time.Time       `json:"expires_at"`
	CreatedAt          time.Time        `json:"created_at"`
	UpdatedAt          time.Time        `json:"updated_at"`
}

// APIKey allows programmatic REST access bound to a PanelUser's permission scope
type APIKey struct {
	ID          int64      `json:"id"`
	PanelUserID int64      `json:"panel_user_id"`
	Name        string     `json:"name"`
	KeyPrefix   string     `json:"key_prefix"` // e.g. rpn_a1b2...
	KeyHash     string     `json:"-"`          // SHA-256 of full secret
	Permissions []string   `json:"permissions"`
	LastUsedAt  *time.Time `json:"last_used_at"`
	CreatedAt   time.Time  `json:"created_at"`
	RevokedAt   *time.Time `json:"revoked_at"`
}

type APILog struct {
	ID          int64     `json:"id"`
	PanelUserID *int64    `json:"panel_user_id"`
	KeyPrefix   string    `json:"key_prefix"`
	Method      string    `json:"method"`
	Endpoint    string    `json:"endpoint"`
	StatusCode  int       `json:"status_code"`
	IPAddress   string    `json:"ip_address"`
	DurationMs  int       `json:"duration_ms"`
	CreatedAt   time.Time `json:"created_at"`
}

type ConfigItem struct {
	ID           int64     `json:"id"`
	ConfigUserID int64     `json:"config_user_id"`
	Name         string    `json:"name"`
	Protocol     string    `json:"protocol"` // vless, vmess, trojan, reality
	Port         int       `json:"port"`
	Settings     string    `json:"settings"`
	CreatedAt    time.Time `json:"created_at"`
}

type Subscription struct {
	ID           int64      `json:"id"`
	ConfigUserID int64      `json:"config_user_id"`
	Token        string     `json:"token"`
	Status       string     `json:"status"` // Active, Revoked, Expired
	CreatedAt    time.Time  `json:"created_at"`
	RevokedAt    *time.Time `json:"revoked_at"`
}

type DailyTraffic struct {
	ID            int64     `json:"id"`
	ConfigUserID  int64     `json:"config_user_id"`
	DateStr       string    `json:"date_str"` // YYYY-MM-DD
	UploadBytes   int64     `json:"upload_bytes"`
	DownloadBytes int64     `json:"download_bytes"`
	TotalBytes    int64     `json:"total_bytes"`
	UpdatedAt     time.Time `json:"updated_at"`
}

type Node struct {
	ID            int64     `json:"id"`
	Name          string    `json:"name"`
	Address       string    `json:"address"`
	Port          int       `json:"port"`
	Status        string    `json:"status"` // Online, Offline, Degraded
	Version       string    `json:"version"`
	CPUUsage      float64   `json:"cpu_usage"`
	RAMUsage      float64   `json:"ram_usage"`
	DiskUsage     float64   `json:"disk_usage"`
	UptimeSeconds int64     `json:"uptime_seconds"`
	LastSeenAt    time.Time `json:"last_seen_at"`
	IsLocal       bool      `json:"is_local"`
}

type AuditLog struct {
	ID        int64     `json:"id"`
	Actor     string    `json:"actor"`
	Action    string    `json:"action"`
	Target    string    `json:"target"`
	IPAddress string    `json:"ip_address"`
	Metadata  string    `json:"metadata"`
	CreatedAt time.Time `json:"created_at"`
}

type BlocklistRule struct {
	ID        int64     `json:"id"`
	Type      string    `json:"type"` // Domain, IP, CIDR
	Value     string    `json:"value"`
	Enabled   bool      `json:"enabled"`
	Comment   string    `json:"comment"`
	CreatedAt time.Time `json:"created_at"`
}

type DashboardStats struct {
	TotalPanelUsers  int64   `json:"total_panel_users"`
	TotalConfigUsers int64   `json:"total_config_users"`
	ActiveUsers      int64   `json:"active_users"`
	ExpiredUsers     int64   `json:"expired_users"`
	DisabledUsers    int64   `json:"disabled_users"`
	TotalTraffic     int64   `json:"total_traffic"`
	TodayTraffic     int64   `json:"today_traffic"`
	OnlineUsers      int64   `json:"online_users"`
	NodesCount       int64   `json:"nodes_count"`
	CPUUsage         float64 `json:"cpu_usage"`
	RAMUsage         float64 `json:"ram_usage"`
	DiskUsage        float64 `json:"disk_usage"`
	UptimeSeconds    int64   `json:"uptime_seconds"`
	XrayStatus       string  `json:"xray_status"`
	DatabaseStatus   string  `json:"database_status"`
}
