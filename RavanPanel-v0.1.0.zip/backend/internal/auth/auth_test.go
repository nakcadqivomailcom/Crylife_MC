package auth

import (
	"testing"
	"time"

	"github.com/ravanpanel/ravanpanel/backend/internal/domain"
)

func TestAuth_PasswordHashingAndVerification(t *testing.T) {
	password := "SecureAdminPass#2026"
	hash, err := HashPassword(password)
	if err != nil {
		t.Fatalf("Failed to hash password: %v", err)
	}

	if !VerifyPassword(password, hash) {
		t.Errorf("Password verification failed for correct password")
	}

	if VerifyPassword("WrongPassword", hash) {
		t.Errorf("Password verification succeeded for incorrect password")
	}
}

func TestAuth_SessionLifecycleAndBruteForceLockout(t *testing.T) {
	service := NewAuthService()
	panelUser := &domain.PanelUser{
		ID:       42,
		Username: "admin_tester",
		Role:     domain.RoleOwner,
	}

	sess, err := service.CreateSession(panelUser, 1*time.Hour)
	if err != nil {
		t.Fatalf("CreateSession failed: %v", err)
	}

	validSess, err := service.ValidateSession(sess.Token)
	if err != nil || validSess.UserID != panelUser.ID {
		t.Fatalf("ValidateSession failed")
	}

	service.RevokeSession(sess.Token)
	_, err = service.ValidateSession(sess.Token)
	if err != ErrUnauthorized {
		t.Fatalf("Expected ErrUnauthorized after revoke, got %v", err)
	}

	ident := "bad_actor_ip"
	for i := 0; i < 5; i++ {
		if err := service.CheckLoginAllowed(ident); err != nil {
			t.Fatalf("Unexpected lock before 5 attempts: %v", err)
		}
		service.RecordLoginFailure(ident)
	}

	if err := service.CheckLoginAllowed(ident); err != ErrAccountLocked {
		t.Fatalf("Expected ErrAccountLocked, got %v", err)
	}

	service.RecordLoginSuccess(ident)
	if err := service.CheckLoginAllowed(ident); err != nil {
		t.Fatalf("Expected success reset, got: %v", err)
	}
}

func TestRBAC_Permissions(t *testing.T) {
	if !domain.HasPermission(domain.RoleOwner, domain.PermUsersCreate) {
		t.Errorf("Owner should have users.create")
	}
	if !domain.HasPermission(domain.RoleOwner, domain.PermBackupRestore) {
		t.Errorf("Owner should have backup.restore")
	}
	if domain.HasPermission(domain.RoleReadOnly, domain.PermUsersCreate) {
		t.Errorf("ReadOnly should not have users.create")
	}
}
