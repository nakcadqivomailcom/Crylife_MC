package auth

import (
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"errors"
	"fmt"
	"sync"
	"time"

	"github.com/ravanpanel/ravanpanel/backend/internal/domain"
)

var (
	ErrInvalidCredentials = errors.New("invalid username or password")
	ErrAccountLocked      = errors.New("account temporarily locked due to excessive failed attempts")
	ErrUnauthorized       = errors.New("unauthorized")
	ErrForbidden          = errors.New("forbidden: insufficient permissions")
)

type Session struct {
	Token     string      `json:"token"`
	UserID    int64       `json:"user_id"`
	Username  string      `json:"username"`
	Role      domain.Role `json:"role"`
	CreatedAt time.Time   `json:"created_at"`
	ExpiresAt time.Time   `json:"expires_at"`
}

type FailedAttempt struct {
	Count       int
	FirstFail   time.Time
	LockedUntil time.Time
}

type AuthService struct {
	mu           sync.RWMutex
	sessions     map[string]*Session
	failedLogins map[string]*FailedAttempt
	maxAttempts  int
	lockDuration time.Duration
}

func NewAuthService() *AuthService {
	return &AuthService{
		sessions:     make(map[string]*Session),
		failedLogins: make(map[string]*FailedAttempt),
		maxAttempts:  5,
		lockDuration: 15 * time.Minute,
	}
}

func HashPassword(password string) (string, error) {
	salt := make([]byte, 16)
	if _, err := rand.Read(salt); err != nil {
		return "", err
	}
	h := sha256.New()
	h.Write(salt)
	h.Write([]byte(password))
	hash := h.Sum(nil)
	return fmt.Sprintf("%s$%s", hex.EncodeToString(salt), hex.EncodeToString(hash)), nil
}

func VerifyPassword(password, storedHash string) bool {
	parts := splitSaltHash(storedHash)
	if len(parts) != 2 {
		return false
	}
	saltHex := parts[0]
	hashHex := parts[1]

	salt, err := hex.DecodeString(saltHex)
	if err != nil {
		return false
	}
	expectedHash, err := hex.DecodeString(hashHex)
	if err != nil {
		return false
	}

	h := sha256.New()
	h.Write(salt)
	h.Write([]byte(password))
	computedHash := h.Sum(nil)

	return subtle.ConstantTimeCompare(expectedHash, computedHash) == 1
}

func splitSaltHash(s string) []string {
	for i := 0; i < len(s); i++ {
		if s[i] == '$' {
			return []string{s[:i], s[i+1:]}
		}
	}
	return nil
}

func (s *AuthService) CheckLoginAllowed(identifier string) error {
	s.mu.RLock()
	defer s.mu.RUnlock()

	attempt, exists := s.failedLogins[identifier]
	if !exists {
		return nil
	}
	if time.Now().Before(attempt.LockedUntil) {
		return ErrAccountLocked
	}
	return nil
}

func (s *AuthService) RecordLoginFailure(identifier string) {
	s.mu.Lock()
	defer s.mu.Unlock()

	now := time.Now()
	attempt, exists := s.failedLogins[identifier]
	if !exists || now.Sub(attempt.FirstFail) > 10*time.Minute {
		s.failedLogins[identifier] = &FailedAttempt{
			Count:     1,
			FirstFail: now,
		}
		return
	}

	attempt.Count++
	if attempt.Count >= s.maxAttempts {
		attempt.LockedUntil = now.Add(s.lockDuration)
	}
}

func (s *AuthService) RecordLoginSuccess(identifier string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	delete(s.failedLogins, identifier)
}

func (s *AuthService) CreateSession(user *domain.PanelUser, duration time.Duration) (*Session, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return nil, err
	}
	token := hex.EncodeToString(b)

	now := time.Now()
	sess := &Session{
		Token:     token,
		UserID:    user.ID,
		Username:  user.Username,
		Role:      user.Role,
		CreatedAt: now,
		ExpiresAt: now.Add(duration),
	}
	s.sessions[token] = sess
	return sess, nil
}

func (s *AuthService) ValidateSession(token string) (*Session, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	sess, exists := s.sessions[token]
	if !exists {
		return nil, ErrUnauthorized
	}
	if time.Now().After(sess.ExpiresAt) {
		return nil, ErrUnauthorized
	}
	return sess, nil
}

func (s *AuthService) RevokeSession(token string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	delete(s.sessions, token)
}
