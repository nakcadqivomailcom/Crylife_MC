package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/ravanpanel/ravanpanel/backend/internal/health"
	"github.com/ravanpanel/ravanpanel/backend/internal/providers"
)

type defaultChecker struct{}

func (d *defaultChecker) CheckDatabase(ctx context.Context) error { return nil }
func (d *defaultChecker) CheckCore(ctx context.Context) error     { return nil }
func (d *defaultChecker) CheckDisk(ctx context.Context) error     { return nil }
func (d *defaultChecker) CheckMemory(ctx context.Context) error   { return nil }

func main() {
	port := os.Getenv("PORT")
	if port == "" {
		port = "3000"
	}

	xrayProvider := providers.NewXrayProvider("/usr/local/bin/xray", "/var/lib/ravanpanel/xray/config.json", "v1.8.24")
	_ = xrayProvider.Start(context.Background())

	healthSvc := health.NewHealthService(&defaultChecker{})

	mux := http.NewServeMux()

	mux.HandleFunc("/health/live", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		resp := healthSvc.CheckLiveness(r.Context())
		w.WriteHeader(http.StatusOK)
		fmt.Fprintf(w, `{"status":"%s"}`, resp.Status)
	})

	mux.HandleFunc("/health/ready", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		resp := healthSvc.CheckReadiness(r.Context())
		w.WriteHeader(http.StatusOK)
		fmt.Fprintf(w, `{"status":"%s","checks":{"database":"ok","xray":"ok","disk":"ok","memory":"ok"}}`, resp.Status)
	})

	server := &http.Server{
		Addr:    ":" + port,
		Handler: mux,
	}

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)

	go func() {
		log.Printf("RavanPanel Core Server v0.1.0 listening on :%s", port)
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Server error: %v", err)
		}
	}()

	<-stop
	log.Println("Shutting down RavanPanel server gracefully...")

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	_ = xrayProvider.Stop(ctx)
	_ = server.Shutdown(ctx)
	log.Println("Server stopped.")
}
