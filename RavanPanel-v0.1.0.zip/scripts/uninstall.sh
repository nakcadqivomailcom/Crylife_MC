#!/usr/bin/env bash
set -euo pipefail

echo "=========================================="
echo "   RavanPanel v0.1.0 Native Uninstaller   "
echo "=========================================="

if [ "$(id -u)" -ne 0 ]; then
    echo "Error: Must be run as root." >&2
    exit 1
fi

read -rp "Are you sure you want to stop and remove RavanPanel? [y/N]: " confirm
if [[ ! "${confirm}" =~ ^[yY]$ ]]; then
    echo "Aborted."
    exit 0
fi

echo "Stopping and disabling systemd service..."
systemctl stop ravanpanel.service 2>/dev/null || true
systemctl disable ravanpanel.service 2>/dev/null || true
rm -f /etc/systemd/system/ravanpanel.service
systemctl daemon-reload

echo "Service removed. Note: Data directory /var/lib/ravanpanel preserved for safety."
echo "To permanently wipe all data, run: rm -rf /var/lib/ravanpanel /etc/ravanpanel"
echo "Uninstallation complete."
