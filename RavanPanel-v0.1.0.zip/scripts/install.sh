#!/usr/bin/env bash
set -euo pipefail

echo "=========================================="
echo "    RavanPanel v0.1.0 Native Installer    "
echo "=========================================="

if [ "$(id -u)" -ne 0 ]; then
    echo "Error: This installer must be executed as root (sudo)." >&2
    exit 1
fi

DATA_DIR="/var/lib/ravanpanel"
CONF_DIR="/etc/ravanpanel"
BIN_DIR="/usr/local/bin"

echo "[1/5] Creating directory layout..."
mkdir -p "${DATA_DIR}"
mkdir -p "${DATA_DIR}/backups"
mkdir -p "${DATA_DIR}/xray"
mkdir -p "${CONF_DIR}"

echo "[2/5] Installing default environment file..."
if [ ! -f "${CONF_DIR}/ravanpanel.env" ]; then
    cat <<EOF > "${CONF_DIR}/ravanpanel.env"
PORT=3000
HOST=0.0.0.0
DATABASE_TYPE=sqlite
DATABASE_PATH=${DATA_DIR}/ravan.db
LOG_LEVEL=INFO
XRAY_ENABLED=true
XRAY_BIN_PATH=/usr/local/bin/xray
XRAY_CONFIG_DIR=${DATA_DIR}/xray
BACKUP_DIR=${DATA_DIR}/backups
MONITORING_INTERVAL=10s
EOF
    chmod 600 "${CONF_DIR}/ravanpanel.env"
fi

echo "[3/5] Installing systemd unit..."
if [ -d "/etc/systemd/system" ]; then
    cp deploy/ravanpanel.service /etc/systemd/system/ravanpanel.service
    systemctl daemon-reload
    systemctl enable --now ravanpanel.service
    echo "Service enabled and started via systemd."
fi

echo "[4/5] Running diagnostic doctor..."
if [ -f "${BIN_DIR}/ravanctl" ]; then
    "${BIN_DIR}/ravanctl" doctor
fi

echo "[5/5] Installation complete!"
echo "Access your panel at: http://YOUR_SERVER_IP:3000"
echo "Use 'ravanctl user create --username owner --role Owner --password <pass>' to initialize owner account."
