# Third-Party Notices & Architecture Audit

## 1. Reference Projects & Inspiration

During the initial design phase of **RavanPanel v0.1.0**, architectural paradigms and UX patterns from existing open-source network management systems were analyzed:

- **PasarGuard**: Analyzed for multi-node connection concepts, token-based subscription distribution, and clean command-line operation.
- **BackPack**: Analyzed for user management lifecycle, traffic accounting strategies, and automated backup handling.

### Independent Implementation (Cleanroom Design)
- **Zero Code Copying**: 100% of RavanPanel backend (Go & Node.js orchestration), frontend (React + TypeScript), CLI (`ravanctl`), database schemas, and documentation are designed and implemented independently.
- **No Anti-Censorship / Bypass Mechanisms**: In accordance with policy, RavanPanel includes strictly general-purpose network service management, node telemetry, user accounting, and Xray core abstraction. No DPI bypass, traffic camouflage, or filtering circumvention algorithms are included.

## 2. Dependencies & Licenses

### Backend / Core (Go)
- Standard Go Library (`net/http`, `crypto`, `database/sql`, `sync`, `os/exec`, `context`): BSD-style license.
- Argon2 (`golang.org/x/crypto/argon2`): BSD-3-Clause license.

### Runtime Server & Full-Stack Engine
- **Node.js**: MIT License.
- **Express**: MIT License.
- **node:sqlite**: Built-in standard SQLite engine (Public Domain / MIT).
- **qrcode**: MIT License.

### Frontend
- **React**: MIT License.
- **Vite**: MIT License.
- **Tailwind CSS**: MIT License.
- **Lucide Icons**: ISC License.
- **Motion**: MIT License.

All dependencies have been audited for permissive open-source compatibility (MIT / Apache 2.0 / BSD / ISC) with zero restrictive GPL obligations.
