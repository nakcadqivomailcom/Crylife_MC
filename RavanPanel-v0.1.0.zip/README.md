# RavanPanel (v0.1.0)

> A modern, lightweight, high-performance, and secure management panel for network services, users, traffic accounting, nodes, and Xray core provider.

[![Go Version](https://img.shields.io/badge/Go-1.19%2B-00ADD8?logo=go)](https://golang.org)
[![React](https://img.shields.io/badge/React-19-61DAFB?logo=react)](https://react.dev)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Status](https://img.shields.io/badge/Status-P0%20Verified-success.svg)]()

---

## Highlights

- **Ultra-Lightweight & Fast**: Tailored for minimal memory and CPU usage, running smoothly on VPS instances with 256MB RAM.
- **Resilient Traffic Accounting**: Accurate upload, download, and total traffic counters with persistence across restarts and mathematical double-counting immunity.
- **Granular RBAC**: Strict role hierarchy (`Owner`, `Admin`, `Operator`, `Support`, `ReadOnly`) with capability-based authorization.
- **Decoupled Architecture**: SQLite default embedded database with drop-in PostgreSQL compatibility.
- **Core Provider Abstraction**: Modular `CoreProvider` interface with a production `XrayProvider` managing process supervision and stats.
- **Node Management**: Multi-node ready design with telemetry probes for CPU, RAM, disk, and status.
- **Telegram Bot Integration**: Standard bot commands (`/start`, `/status`, `/users`, `/user`, `/traffic`, `/disable`, `/enable`) protected by permission rules.
- **Safe Backup & Rollback**: Automatic pre-flight validation, safety snapshots, and automatic rollback on restore failure.
- **Dedicated CLI (`ravanctl`)**: Full command-line management for automated operations and system administration.
- **Bilingual Interface**: Native Persian (RTL) & English (LTR) with dark/light themes.

---

## Quick Start (Docker)

```bash
# Clone repository
git clone https://github.com/ravanpanel/ravanpanel.git
cd ravanpanel

# Setup environment
cp .env.example .env

# Start with Docker Compose
docker compose up -d

# Check status
docker compose ps
```

Visit `http://localhost:3000` in your browser. Default initial credentials can be provisioned via CLI:
```bash
docker compose exec ravanpanel ravanctl user create --username owner --role Owner --password "AdminSecret123!"
```

---

## Quick Start (Native Linux)

```bash
# Automated installer for Ubuntu/Debian/AlmaLinux
curl -sSL https://raw.githubusercontent.com/ravanpanel/ravanpanel/main/scripts/install.sh | sudo bash
```

Check service status:
```bash
sudo systemctl status ravanpanel.service
```

---

## CLI Usage (`ravanctl`)

```bash
ravanctl status        # Display service and daemon health
ravanctl doctor        # Perform automated diagnostics
ravanctl backup        # Create a new verified backup snapshot
ravanctl restore <file># Safely restore from archive with auto-rollback
ravanctl logs -f       # Stream unified server logs
```

---

## Documentation

- [Architecture & Design Principles](docs/architecture.md)
- [Installation Guide](docs/installation.md)
- [Configuration Reference](docs/configuration.md)
- [Database & Schema](docs/database.md)
- [REST API Specifications](docs/api.md)
- [Security & Hardening](docs/security.md)
- [Backup & Safe Restore](docs/backup-restore.md)
- [Troubleshooting & Diagnostics](docs/troubleshooting.md)
- [Third-Party Notices](THIRD_PARTY_NOTICES.md)
- [Changelog](CHANGELOG.md)

---

## License

MIT © 2026 RavanPanel Contributors.
