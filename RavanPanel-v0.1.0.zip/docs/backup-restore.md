# Backup & Safe Restore Protocol

## 1. Safety-First Restoration Philosophy

A corrupted or incompatible backup must never render the production server inoperable. RavanPanel implements an automated two-phase commit protocol with automatic safety checkpoints and rollback:

```
[User triggers Restore]
         |
         v
+-------------------------------+
| Step 1: Backup Validation     |
| - Verify archive integrity    |
| - Check schema version match  |
+-------------------------------+
         |
         +--> [Invalid] --> Abort with error (No state touched)
         |
         v [Valid]
+-------------------------------+
| Step 2: Safety Snapshot       |
| - Generate pre-restore state  |
|   snapshot: pre_restore_*.bak |
+-------------------------------+
         |
         v
+-------------------------------+
| Step 3: Quiesce Services      |
| - Pause traffic accounting    |
| - Acquire exclusive DB lock   |
+-------------------------------+
         |
         v
+-------------------------------+
| Step 4: Atomic Restoration    |
| - Restore database & configs  |
| - Execute pending migrations  |
+-------------------------------+
         |
         +--> [Error / Migration Failure]
         |        |
         |        v
         |   +------------------------------------+
         |   | Rollback:                          |
         |   | Restore from pre_restore_*.bak     |
         |   | Re-quiesce & re-open services      |
         |   | Return detailed failure diagnostics|
         |   +------------------------------------+
         |
         v [Success]
+-------------------------------+
| Step 5: Verification & Health |
| - Run live database healthcheck|
| - Restart core provider       |
| - Log audit record            |
+-------------------------------+
```

## 2. Backup Archive Structure
Backups are packaged as gzip-compressed archives containing:
- `manifest.json`: Snapshot metadata, timestamp, system version (`v0.1.0`), SHA-256 hash.
- `database.sql` / `database.db`: SQLite database snapshot or Postgres SQL dump.
- `config.yaml`: Redacted configuration parameters.
- `xray/`: Core routing configurations.
- `blocklist.json`: Blocklist rules.
