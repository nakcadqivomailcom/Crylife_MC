# REST API Documentation

Base URL: `/api/v1`

All authenticated endpoints require a valid session token either in the `Authorization: Bearer <token>` header or via secure session cookie.

## Error Response Envelope
```json
{
  "error": {
    "code": "USER_NOT_FOUND",
    "message": "The requested user account does not exist"
  }
}
```

---

## 1. Authentication (`/api/v1/auth`)

### `POST /api/v1/auth/login`
- **Request Body**: `{"username": "owner", "password": "password123"}`
- **Response**: `{"token": "jwt_or_session_token", "user": { "id": 1, "username": "owner", "role": "Owner" }}`

### `POST /api/v1/auth/logout`
- Revokes the current session token.

### `GET /api/v1/auth/me`
- Returns current authenticated user and granular permissions list.

---

## 2. User Management (`/api/v1/users`)

### `GET /api/v1/users`
- **Query Params**: `page=1&limit=20&search=john&status=Active&sort=created_at&order=desc`
- **Response**: `{"users": [...], "pagination": {"page": 1, "limit": 20, "total": 45, "pages": 3}}`

### `POST /api/v1/users`
- **Permissions**: `users.create`
- **Request Body**:
```json
{
  "username": "client01",
  "password": "InitialUserPass123!",
  "role": "ReadOnly",
  "traffic_quota_bytes": 107374182400,
  "expires_at": "2026-12-31T23:59:59Z",
  "device_limit": 2,
  "user_group": "VIP",
  "notes": "Direct client account"
}
```

### `GET /api/v1/users/:id`
- Returns detailed user object including quota, used bandwidth, and subscription history.

### `PUT /api/v1/users/:id`
- Updates user parameters (quota, expiry, status, group, notes).

### `DELETE /api/v1/users/:id`
- Cascades deletion of associated subscriptions and non-aggregated records.

### `POST /api/v1/users/:id/traffic/reset`
- Resets user's accumulated upload/download usage counters to zero.

---

## 3. Subscriptions & QR (`/api/v1/subscriptions`)

### `GET /api/v1/subscriptions`
- Lists all active and revoked subscriptions.

### `POST /api/v1/subscriptions`
- Generates a new secure, unguessable subscription token for a given `user_id`.

### `POST /api/v1/subscriptions/:id/revoke`
- Revokes token immediately.

### `GET /sub/:token`
- Public subscription endpoint returning subscription payload (Base64-encoded configuration list) for client software.

### `GET /api/v1/subscriptions/:id/qr`
- Returns dynamic QR code representation (PNG data URI or SVG).

---

## 4. Nodes (`/api/v1/nodes`)

### `GET /api/v1/nodes`
- Lists registered nodes with real-time health, CPU, RAM, Disk, and uptime telemetry.

### `POST /api/v1/nodes`
- Registers a new node endpoint.

### `POST /api/v1/nodes/:id/restart`
- Signals service restart on target node.

---

## 5. Dashboard & Telemetry (`/api/v1/dashboard`)

### `GET /api/v1/dashboard`
- Aggregated real-time metrics:
  - User counts: total, active, expired, disabled.
  - Traffic: total upload/download, today's traffic, monthly volume.
  - System: CPU load, memory utilization, disk space, local node status, Xray core status.
  - Historical traffic timeseries for charting.

---

## 6. System Health (`/health`)

### `GET /health/live`
- Basic liveness probe (returns `200 OK` if HTTP server is responding).

### `GET /health/ready`
- Readiness check verifying database connectivity, core provider responsiveness, and disk availability:
```json
{
  "status": "ok",
  "checks": {
    "database": "ok",
    "xray": "ok",
    "disk": "ok",
    "memory": "ok"
  }
}
```

---

## 7. Backups (`/api/v1/backups`)

### `GET /api/v1/backups`
- List available snapshots.

### `POST /api/v1/backups`
- Trigger creation of a new snapshot.

### `POST /api/v1/backups/:id/restore`
- Executes safe pre-flight validation, creates rollback snapshot, and restores state.

### `DELETE /api/v1/backups/:id`
- Deletes snapshot file.

---

## 8. Audit Logs (`/api/v1/audit`)

### `GET /api/v1/audit`
- Retrieve paginated audit trail of all security-critical modifications.
