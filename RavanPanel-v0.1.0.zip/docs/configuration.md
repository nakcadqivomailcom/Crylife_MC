# Configuration Guide

RavanPanel supports layered configuration via environment variables and an optional `config.yaml` file.

## Environment Variables

| Variable | Description | Default |
| :--- | :--- | :--- |
| `PORT` | Listening port for web server & REST API | `3000` |
| `HOST` | Bind host address | `0.0.0.0` |
| `DATABASE_TYPE` | Database driver (`sqlite` or `postgres`) | `sqlite` |
| `DATABASE_PATH` | Path to SQLite database file | `/var/lib/ravanpanel/ravan.db` |
| `DATABASE_URL` | PostgreSQL connection URL (if postgres) | `""` |
| `JWT_SECRET` | Secret key for session encryption & tokens | Auto-generated |
| `LOG_LEVEL` | Log verbosity (`DEBUG`, `INFO`, `WARN`, `ERROR`) | `INFO` |
| `XRAY_ENABLED` | Enable Xray core supervision | `true` |
| `XRAY_BIN_PATH` | Path to Xray executable binary | `/usr/local/bin/xray` |
| `XRAY_CONFIG_DIR` | Directory containing core configs | `/var/lib/ravanpanel/xray` |
| `TELEGRAM_BOT_TOKEN`| Telegram Bot Token for administrative control | `""` |
| `TELEGRAM_ADMIN_IDS`| Comma-separated list of allowed Telegram user IDs| `""` |
| `MONITORING_INTERVAL`| Server telemetry polling interval (e.g. `10s`)| `10s` |
| `BACKUP_DIR` | Storage path for safety and manual backups | `/var/lib/ravanpanel/backups`|

---

## Configuration File Example (`config.yaml`)

```yaml
server:
  host: "0.0.0.0"
  port: 3000
  log_level: "INFO"

database:
  type: "sqlite"
  path: "/var/lib/ravanpanel/ravan.db"

security:
  session_timeout_hours: 72
  brute_force_lockout_attempts: 5
  brute_force_lockout_duration_mins: 15

xray:
  enabled: true
  bin_path: "/usr/local/bin/xray"
  config_path: "/var/lib/ravanpanel/xray/config.json"

telegram:
  enabled: false
  bot_token: ""
  admin_chat_ids: []

monitoring:
  interval_seconds: 10
  retention_days: 30

backup:
  directory: "/var/lib/ravanpanel/backups"
  auto_daily: true
  max_snapshots: 10
```
