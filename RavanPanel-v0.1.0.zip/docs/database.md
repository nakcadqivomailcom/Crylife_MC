# Database & Migration Architecture

## 1. Storage Philosophy

RavanPanel is designed to operate seamlessly across two distinct scales:
1. **SQLite (Default)**: Embedded, single-binary, zero-configuration storage. Ideal for single-node setups and low-resource VPS (128MB–1GB RAM). Includes WAL (Write-Ahead Logging) and foreign key enforcement enabled by default.
2. **PostgreSQL**: Production-grade relational storage suitable for clustered deployments, multi-node fleets, and high concurrency.

## 2. Relational Schema & Entities

### Users
- `id` (INTEGER PRIMARY KEY AUTOINCREMENT)
- `uuid` (VARCHAR(36) UNIQUE)
- `username` (VARCHAR(64) UNIQUE NOT NULL)
- `password_hash` (TEXT NOT NULL)
- `role` (VARCHAR(32) NOT NULL) - `Owner`, `Admin`, `Operator`, `Support`, `ReadOnly`
- `status` (VARCHAR(32) NOT NULL) - `Active`, `Disabled`, `Expired`, `QuotaExceeded`
- `traffic_quota_bytes` (BIGINT NOT NULL DEFAULT 0)
- `traffic_used_bytes` (BIGINT NOT NULL DEFAULT 0)
- `upload_bytes` (BIGINT NOT NULL DEFAULT 0)
- `download_bytes` (BIGINT NOT NULL DEFAULT 0)
- `device_limit` (INT NOT NULL DEFAULT 0)
- `user_group` (VARCHAR(64) DEFAULT '')
- `notes` (TEXT DEFAULT '')
- `tags` (TEXT DEFAULT '[]')
- `periodic_quota_bytes` (BIGINT DEFAULT 0)
- `periodic_reset_day` (INT DEFAULT 1)
- `last_seen_at` (TIMESTAMP NULL)
- `expires_at` (TIMESTAMP NULL)
- `created_at` (TIMESTAMP NOT NULL)
- `updated_at` (TIMESTAMP NOT NULL)

### Subscriptions
- `id` (INTEGER PRIMARY KEY AUTOINCREMENT)
- `user_id` (INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE)
- `token` (VARCHAR(64) UNIQUE NOT NULL)
- `status` (VARCHAR(32) NOT NULL) - `Active`, `Revoked`, `Expired`
- `created_at` (TIMESTAMP NOT NULL)
- `revoked_at` (TIMESTAMP NULL)

### Traffic Logs (Daily Aggregation)
- `id` (INTEGER PRIMARY KEY AUTOINCREMENT)
- `user_id` (INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE)
- `date` (DATE NOT NULL)
- `upload_bytes` (BIGINT NOT NULL DEFAULT 0)
- `download_bytes` (BIGINT NOT NULL DEFAULT 0)
- `total_bytes` (BIGINT NOT NULL DEFAULT 0)
- UNIQUE (`user_id`, `date`)

### Nodes
- `id` (INTEGER PRIMARY KEY AUTOINCREMENT)
- `name` (VARCHAR(64) NOT NULL)
- `address` (VARCHAR(128) NOT NULL)
- `port` (INT NOT NULL DEFAULT 443)
- `status` (VARCHAR(32) NOT NULL DEFAULT 'Online')
- `version` (VARCHAR(32) DEFAULT 'v0.1.0')
- `cpu_usage` (FLOAT DEFAULT 0.0)
- `ram_usage` (FLOAT DEFAULT 0.0)
- `disk_usage` (FLOAT DEFAULT 0.0)
- `uptime_seconds` (BIGINT DEFAULT 0)
- `last_seen_at` (TIMESTAMP NOT NULL)
- `is_local` (BOOLEAN NOT NULL DEFAULT 0)

### Audit Logs
- `id` (INTEGER PRIMARY KEY AUTOINCREMENT)
- `actor` (VARCHAR(64) NOT NULL)
- `action` (VARCHAR(64) NOT NULL)
- `target` (VARCHAR(128) NOT NULL)
- `ip_address` (VARCHAR(45) NOT NULL)
- `metadata` (TEXT DEFAULT '{}')
- `created_at` (TIMESTAMP NOT NULL)

### Blocklist
- `id` (INTEGER PRIMARY KEY AUTOINCREMENT)
- `type` (VARCHAR(16) NOT NULL) - `Domain`, `IP`, `CIDR`
- `value` (VARCHAR(255) NOT NULL UNIQUE)
- `enabled` (BOOLEAN NOT NULL DEFAULT 1)
- `comment` (TEXT DEFAULT '')
- `created_at` (TIMESTAMP NOT NULL)

## 3. Migration Runner

Migrations are version-tracked in table `schema_migrations`:
- `001_initial_schema.sql`
- `002_traffic_indices.sql`
- `003_blocklist_tables.sql`

The migration runner ensures transactional execution: if a migration script fails, the transaction is rolled back and the previous schema state remains intact.
