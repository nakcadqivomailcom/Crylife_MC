# Installation Guide

RavanPanel supports both **Native Linux Systemd** and **Docker Compose** deployment options.

## System Requirements
- **OS**: Linux (Ubuntu 20.04+, Debian 11+, AlmaLinux 8+, Rocky Linux, Arch)
- **RAM**: Minimum 256 MB (512 MB+ recommended for heavy load)
- **Disk**: 100 MB free space for binaries and SQLite database
- **Architecture**: x86_64 / amd64, arm64

---

## Method 1: Automated Native Installation

```bash
# 1. Download and run the official installer script
curl -sSL https://raw.githubusercontent.com/ravanpanel/ravanpanel/main/scripts/install.sh | sudo bash
```

The script will:
1. Detect architecture and install prerequisites.
2. Install the `ravanpanel` server and `ravanctl` CLI to `/usr/local/bin/`.
3. Create system directory `/var/lib/ravanpanel/` for SQLite database and configurations.
4. Install and enable the systemd service: `systemctl enable --now ravanpanel.service`.
5. Guide you to create your initial `Owner` credentials.

---

## Method 2: Docker & Docker Compose

```bash
# 1. Clone or download release package
git clone https://github.com/ravanpanel/ravanpanel.git
cd ravanpanel

# 2. Configure environment
cp .env.example .env
nano .env

# 3. Start services
docker compose up -d

# 4. Check status and health
docker compose ps
docker compose logs -f
```

---

## Initial Admin Setup
Once installed, create your primary Owner account:
```bash
# Using CLI
ravanctl user create --username owner --role Owner --password "YourStrongPassword123"

# Or access web UI at: http://YOUR_SERVER_IP:3000
```
