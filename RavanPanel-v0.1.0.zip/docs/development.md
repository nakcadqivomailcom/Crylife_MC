# Development & Contribution Guide

## Local Workspace Setup

### Prerequisites
- Node.js 20+
- Go 1.19+ (optional for native binary compilation)
- SQLite3

### Running the Full-Stack Dev Server
```bash
# 1. Install dependencies
npm install

# 2. Start full-stack development server (Express API + Vite HMR on port 3000)
npm run dev
```

### Running Tests
```bash
# Backend unit & integration tests
go test -v ./backend/...

# Frontend TypeScript checking
npm run lint

# Production build test
npm run build
```
