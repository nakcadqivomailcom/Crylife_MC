# Production Deployment Guide

## Production Architecture Recommendations

For production environments managing more than 500 active users:
1. **Reverse Proxy (Nginx / Caddy)**:
   - Terminate TLS certificates via Let's Encrypt / ACME.
   - Proxy WebSocket / HTTP requests to `http://127.0.0.1:3000`.
   - Pass real client IPs (`X-Forwarded-For`, `X-Real-IP`).

2. **Systemd Resource Limits**:
   - Limit file descriptors and memory footprint in `ravanpanel.service`:
   ```ini
   LimitNOFILE=65535
   MemoryMax=512M
   ```

3. **Automated Backups**:
   - Schedule daily snapshots via cron:
   ```cron
   0 3 * * * /usr/local/bin/ravanctl backup create >> /var/log/ravanpanel-backup.log 2>&1
   ```
