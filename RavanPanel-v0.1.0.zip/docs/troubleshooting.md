# Troubleshooting & Diagnostic Guide

## 1. System Doctor (`ravanctl doctor`)

The CLI utility includes an automated health probe to identify misconfigurations:
```bash
ravanctl doctor
```
Checks performed:
- System permissions & write access to `/var/lib/ravanpanel/`
- SQLite WAL integrity or PostgreSQL connection latency
- Core provider executable status (`/usr/local/bin/xray`)
- Port conflicts on port 3000 / 443 / 80
- Memory and swap headroom

---

## 2. Common Issues & Solutions

### A. Port 3000 Already in Use
- **Symptom**: `bind: address already in use`
- **Fix**: Check running processes with `lsof -i :3000` or change `PORT=3001` in `/etc/ravanpanel/ravanpanel.env`.

### B. SQLite Database Locked
- **Symptom**: `database is locked (5)`
- **Fix**: Ensure WAL mode is active (`PRAGMA journal_mode=WAL;`). RavanPanel activates WAL automatically upon startup.

### C. Telegram Bot Commands Not Answering
- **Symptom**: Bot receives message but does nothing.
- **Fix**: Verify your Telegram User ID is included in `TELEGRAM_ADMIN_IDS` and check `ravanctl logs --service telegram`.
