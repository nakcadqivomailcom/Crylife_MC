# Security Architecture & Hardening

## 1. Authentication & Password Security
- **Argon2id / Secure KDF**: Passwords are never stored in plaintext or logged. Password hashes use modern memory-hard key derivation with cryptographically unique salts.
- **Brute-Force Defense**: Repeated failed login attempts trigger an exponential backoff lock (5 attempts within 5 minutes results in a 15-minute freeze).
- **Session Revocation**: User sessions can be terminated instantly by administrators. Changing a user password invalidates all existing active tokens.

## 2. Role-Based Access Control (RBAC)
Role hierarchy:
1. **Owner**: Unrestricted root administrative privileges (settings, backup restore, user management, API keys).
2. **Admin**: Day-to-day administrative functions (node provisioning, user lifecycle, blocklists).
3. **Operator**: Node restarts, user monitoring, traffic resets.
4. **Support**: Read-only user verification, subscription regeneration.
5. **ReadOnly**: View-only access to assigned dashboards.

Permissions are evaluated on every incoming API request:
```
users.read, users.create, users.update, users.delete
traffic.read, traffic.reset
nodes.read, nodes.manage
subscriptions.read, subscriptions.create, subscriptions.revoke
settings.read, settings.update
backup.create, backup.restore
audit.read
telegram.manage, rubika.manage
xray.read, xray.manage
```

## 3. Vulnerability Mitigations
- **SQL Injection**: Exclusively parameterized queries and prepared statements across both SQLite and PostgreSQL adapters.
- **Cross-Site Scripting (XSS)**: Strict JSON APIs; React automatically escapes JSX expressions.
- **Cross-Site Request Forgery (CSRF)**: Custom request headers (`X-Requested-With`, `Authorization: Bearer`), SameSite cookie policies.
- **Path Traversal**: File operations (backups, logs, templates) validate paths strictly within their respective sandboxed directories using normalized absolute paths.
- **Sensitive Data Redaction**: Passwords, bot tokens, and raw subscription secrets are stripped before being recorded to audit logs or system stdout.
