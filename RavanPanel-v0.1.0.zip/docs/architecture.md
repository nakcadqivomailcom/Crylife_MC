# RavanPanel Architecture

## 1. High-Level Overview

RavanPanel is structured around Clean Architecture principles to ensure that high-level business rules (traffic accounting, user lifecycle, subscriptions, and access control) are decoupled from third-party frameworks, proxy cores, and database storage backends.

```
                      +-----------------------------+
                      |  Web UI (React + TS + Vite) |
                      |  CLI Tool (ravanctl)        |
                      |  Telegram Bot & Webhooks    |
                      +--------------+--------------+
                                     |
                                     v
                      +-----------------------------+
                      |    REST API Transport Layer  |
                      |      /api/v1/* (JSON)       |
                      +--------------+--------------+
                                     |
                   +-----------------+-----------------+
                   |                                   |
                   v                                   v
    +------------------------------+   +-------------------------------+
    |       Security Layer         |   |        Service Layer          |
    |  - Argon2id Password Hashing |   |  - UserService                |
    |  - Granular RBAC Permissions |   |  - TrafficAccountingService   |
    |  - Session Revocation Engine |   |  - SubscriptionService        |
    |  - Rate-Limiting & Cooldown  |   |  - Backup & Restore Service   |
    |  - Audit Logging Pipeline    |   |  - Health & Telemetry Engine  |
    +------------------------------+   +---------------+---------------+
                                                       |
                   +-----------------------------------+-----------------------------------+
                   |                                                                       |
                   v                                                                       v
    +-------------------------------+                                       +-------------------------------+
    |      Core Provider Abstr.     |                                       |      Data Storage Abstr.      |
    |  - CoreProvider Interface     |                                       |  - Repository Interface       |
    |  - XrayProvider Implementation|                                       |  - SQLite (Default on VPS)    |
    |  - Config Generator & Stats   |                                       |  - PostgreSQL (Production)    |
    +-------------------------------+                                       +-------------------------------+
                   |
                   v
    +-------------------------------+
    |      Node Provider Abstr.     |
    |  - NodeProvider Interface     |
    |  - LocalNodeProvider (P0)     |
    |  - RemoteNodeProvider (P1)    |
    +-------------------------------+
```

## 2. Abstraction Interfaces

### Core Provider Abstraction
```go
type CoreProvider interface {
    Start(ctx context.Context) error
    Stop(ctx context.Context) error
    Restart(ctx context.Context) error
    Status(ctx context.Context) (Status, error)
    GetStats(ctx context.Context) (Stats, error)
    ApplyConfig(ctx context.Context, config Config) error
    ValidateConfig(ctx context.Context, config Config) error
}
```

The `XrayProvider` implements `CoreProvider`. It validates configuration syntax, oversees process lifecycles via supervisor/systemd/subprocess, and ingests traffic counters via API or internal statistics channels.

### Node Provider Abstraction
```go
type NodeProvider interface {
    GetNodeInfo(ctx context.Context) (NodeInfo, error)
    GetMetrics(ctx context.Context) (NodeMetrics, error)
    ExecuteAction(ctx context.Context, action string) error
}
```

In v0.1.0, `LocalNodeProvider` inspects local system telemetry (CPU load, memory allocation, disk capacity, uptime) without requiring external daemon overhead. The interface is designed to support `RemoteNodeProvider` in subsequent multi-node releases.

### Database Abstraction
All database interactions flow through structured interfaces:
- `UserRepository`
- `TrafficRepository`
- `SubscriptionRepository`
- `NodeRepository`
- `AuditRepository`
- `BlocklistRepository`
- `BackupRepository`

This ensures that business logic is completely agnostic to whether SQLite or PostgreSQL is active.
